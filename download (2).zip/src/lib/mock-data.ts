
import type { Property, Tenant, Payment, TaxRate, PropertyType, NumberOfInstallments, Expense, Owner, OwnerTransaction, Inheritor, InheritorTransaction, BankTransaction, InheritorOperationType } from '@/types';
import { RENT_TYPES, TAX_RATES, PAYMENT_STATUSES, PROPERTY_TYPES, INHERITOR_OPERATION_TYPES } from './constants';

const formatDate = (dateString: string): string => {
  return new Date(dateString).toISOString().split('T')[0];
};

// Static dates for mock data consistency
const tenant1StartDate = "2024-01-15";
const tenant1EndDate = "2025-10-31"; 

const tenant2StartDate = "2023-11-01";
const tenant2EndDate = "2024-10-30"; 

const systemUser = "system"; // For initial mock data
const mockDate = new Date(new Date().setDate(new Date().getDate() - 10)).toISOString(); // A past date

export const mockOwners: Owner[] = [
  { id: 'owner1', name: 'ورثة ابو ناصر', lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'owner2', name: 'ابو نائف', lastModifiedBy: systemUser, lastModifiedAt: mockDate },
];

export const mockProperties: Property[] = [
  { id: 'prop1', name: 'فيلا الأحلام', type: PROPERTY_TYPES[0].value as PropertyType, status: 'rented', address: '123 شارع الملك فهد، الرياض', imageUrl: 'https://picsum.photos/seed/prop1/400/300', ownerId: 'owner1', lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'prop2', name: 'شقة النخيل', type: PROPERTY_TYPES[0].value as PropertyType, status: 'vacant', address: '456 طريق الأمير محمد، جدة', imageUrl: 'https://picsum.photos/seed/prop2/400/300', ownerId: 'owner2', lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'prop3', name: 'مبنى الأندلس', type: PROPERTY_TYPES[1].value as PropertyType, status: 'maintenance', address: '789 شارع التحلية، الدمام', imageUrl: 'https://picsum.photos/seed/prop3/400/300', lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'prop4', name: 'شقة الوادي', type: PROPERTY_TYPES[0].value as PropertyType, status: 'rented', address: '101 واحة السليمانية، الرياض', imageUrl: 'https://picsum.photos/seed/prop4/400/300', ownerId: 'owner1', lastModifiedBy: systemUser, lastModifiedAt: mockDate},
];

export const mockTenants: Tenant[] = [
  {
    tenantId: 'tenant1_sys',
    contractIdentifier: 'C-2024-001',
    propertyId: 'prop1',
    tenantName: 'عبدالله القحطاني',
    contractStartDate: formatDate(tenant1StartDate),
    contractEndDate: formatDate(tenant1EndDate),
    contractValue: 120000,
    rentType: RENT_TYPES[0].value,
    taxRate: TAX_RATES[1].value as TaxRate,
    numberOfInstallments: 1 as NumberOfInstallments,
    contractAttachments: [{ name: 'عقد الإيجار - عبدالله.pdf', url: '#' }],
    tenantPhoneNumber: '0501234567',
    tenantEmail: 'abdullah.q@example.com',
    tenantAddress: 'حي المرسلات، شارع الزهور، الرياض',
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    tenantId: 'tenant2_sys',
    contractIdentifier: 'C-2023-075',
    propertyId: 'prop4',
    tenantName: 'فاطمة الزهراني',
    contractStartDate: formatDate(tenant2StartDate),
    contractEndDate: formatDate(tenant2EndDate),
    contractValue: 5000,
    rentType: RENT_TYPES[1].value,
    taxRate: TAX_RATES[0].value as TaxRate,
    numberOfInstallments: 1 as NumberOfInstallments,
    contractAttachments: [{ name: 'عقد الإيجار - فاطمة.pdf', url: '#' }],
    tenantPhoneNumber: '0559876543',
    tenantEmail: 'fatima.z@example.com',
    tenantAddress: 'حي الروضة، شارع الأمير سلطان، جدة',
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
];

export const mockPayments: Payment[] = [
  {
    paymentId: 'pay1_1',
    tenantId: 'tenant1_sys',
    dueDate: formatDate("2024-02-15"),
    amountDue: 10000,
    amountPaid: 10000,
    description: 'دفعة إيجار شهرية',
    status: PAYMENT_STATUSES[0].value,
    paymentAttachments: [{ name: 'إيصال - دفعة 1.pdf', url: '#' }],
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    paymentId: 'pay1_2',
    tenantId: 'tenant1_sys',
    dueDate: formatDate("2024-03-15"),
    amountDue: 10000,
    amountPaid: 10000,
    description: 'دفعة إيجار شهرية',
    status: PAYMENT_STATUSES[0].value,
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    paymentId: 'pay1_3',
    tenantId: 'tenant1_sys',
    dueDate: formatDate("2024-04-15"),
    amountDue: 10000,
    amountPaid: 5000,
    description: 'دفعة إيجار شهرية',
    status: PAYMENT_STATUSES[1].value,
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    paymentId: 'pay2_1',
    tenantId: 'tenant2_sys',
    dueDate: formatDate("2023-12-01"),
    amountDue: 5000,
    amountPaid: 5000,
    description: 'إيجار الشهر الماضي',
    status: PAYMENT_STATUSES[0].value,
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    paymentId: 'pay2_2',
    tenantId: 'tenant2_sys',
    dueDate: formatDate("2024-01-01"),
    amountDue: 5000,
    amountPaid: 0,
    description: 'إيجار الشهر الحالي',
    status: PAYMENT_STATUSES[2].value,
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
];

export const mockExpenses: Expense[] = [
  {
    id: 'exp1',
    name: 'فاتورة كهرباء مكتب الإدارة',
    amount: 350.75,
    date: formatDate('2024-05-01'),
    description: 'استهلاك كهرباء شهر أبريل لمكتب الإدارة الرئيسي.',
    attachments: [{ name: 'فاتورة كهرباء ابريل.pdf', url: '#' }],
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: 'exp2',
    name: 'صيانة مصعد مبنى الأندلس',
    amount: 1200.00,
    date: formatDate('2024-05-05'),
    description: 'تكلفة الصيانة الدورية لمصعد مبنى الأندلس (العقار prop3).',
    attachments: [],
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: 'exp3',
    name: 'شراء أدوات نظافة',
    amount: 150.00,
    date: formatDate('2024-05-10'),
    description: 'مواد تنظيف للممرات والمناطق المشتركة.',
    attachments: [{ name: 'فاتورة أدوات نظافة.jpg', url: '#' }],
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
];


export const mockOwnerTransactions: OwnerTransaction[] = [
  {
    id: 'own_trans1_1',
    ownerId: 'owner1',
    amount: 50000,
    description: 'تحويل أرباح الربع الأول',
    date: formatDate('2024-04-01'),
    attachments: [{ name: 'إيصال تحويل ق1.pdf', url: '#' }],
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: 'own_trans1_2',
    ownerId: 'owner1',
    amount: -2000,
    description: 'سداد رسوم إدارية',
    date: formatDate('2024-04-15'),
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: 'own_trans2_1',
    ownerId: 'owner2',
    amount: 75000,
    description: 'تحويل أرباح الربع الأول',
    date: formatDate('2024-04-02'),
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: 'own_trans2_2',
    ownerId: 'owner2',
    amount: -1500,
    description: 'رسوم صيانة عامة',
    date: formatDate('2024-05-01'),
    attachments: [{ name: 'تفاصيل صيانة.docx', url: '#' }],
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
];

const deceasedTenant1StartDate = "2023-01-01";
const deceasedTenant1EndDate = "2023-12-31";

export const mockDeceasedProperties: Property[] = [
  { id: 'd_prop1', name: 'عمارة الفقيد صالح', type: 'commercial', status: 'vacant', address: '77 شارع الرحمة، مكة المكرمة', imageUrl: 'https://picsum.photos/seed/d_prop1/400/300', lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'd_prop2', name: 'أرض الوالد الزراعية', type: 'residential', status: 'vacant', address: 'منطقة نجد، طريق القصيم', imageUrl: 'https://picsum.photos/seed/d_prop2/400/300', lastModifiedBy: systemUser, lastModifiedAt: mockDate },
];

export const mockDeceasedTenants: Tenant[] = [
  {
    tenantId: 'd_tenant1_sys',
    contractIdentifier: 'DC-2023-001',
    propertyId: 'd_prop1',
    tenantName: 'شركة الأمانة للتجارة',
    contractStartDate: formatDate(deceasedTenant1StartDate),
    contractEndDate: formatDate(deceasedTenant1EndDate),
    contractValue: 250000,
    rentType: 'annual',
    taxRate: 15 as TaxRate,
    numberOfInstallments: 2 as NumberOfInstallments,
    contractAttachments: [{ name: 'عقد شركة الأمانة.pdf', url: '#' }],
    tenantPhoneNumber: '0512345678',
    tenantEmail: 'amanah.co@example.com',
    tenantAddress: 'مكتب رقم 5، برج الأعمال، مكة',
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
];

export const mockDeceasedPayments: Payment[] = [
  {
    paymentId: 'd_pay1_1',
    tenantId: 'd_tenant1_sys',
    dueDate: formatDate("2023-01-15"),
    amountDue: 143750,
    amountPaid: 143750,
    description: 'الدفعة الأولى من إيجار عمارة الفقيد',
    status: 'paid',
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    paymentId: 'd_pay1_2',
    tenantId: 'd_tenant1_sys',
    dueDate: formatDate("2023-07-15"),
    amountDue: 143750,
    amountPaid: 143750,
    description: 'الدفعة الثانية من إيجار عمارة الفقيد',
    status: 'paid',
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
];

export const mockDeceasedExpenses: Expense[] = [
  {
    id: 'd_exp1',
    name: 'رسوم حصر الإرث',
    amount: 5000,
    date: formatDate('2024-02-10'),
    description: 'تكاليف المحامي لإنهاء إجراءات حصر الإرث.',
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: 'd_exp2',
    name: 'صيانة دورية لعمارة الفقيد',
    amount: 1500,
    date: formatDate('2024-03-05'),
    description: 'أعمال سباكة وكهرباء لعمارة الفقيد صالح (d_prop1).',
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
];

export const mockInheritors: Inheritor[] = [
  { id: 'inheritor_nasser', name: 'ناصر', sharePercentage: 17.50, lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'inheritor_khalifa', name: 'خليفة', sharePercentage: 17.50, lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'inheritor_mohammed', name: 'محمد', sharePercentage: 17.50, lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'inheritor_ahmed', name: 'احمد', sharePercentage: 17.50, lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'inheritor_iman', name: 'ايمان', sharePercentage: 8.75, lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'inheritor_ibtisam', name: 'ابتسام', sharePercentage: 8.75, lastModifiedBy: systemUser, lastModifiedAt: mockDate },
  { id: 'inheritor_um_nasser', name: 'ام ناصر', sharePercentage: 12.50, lastModifiedBy: systemUser, lastModifiedAt: mockDate },
];

export const mockDeceasedInheritorTransactions: InheritorTransaction[] = [
  {
    id: 'd_intrans_nasser_1',
    inheritorId: 'inheritor_nasser',
    amount: 1750,
    description: 'توزيع من إيجارات محصلة (عمارة الفقيد صالح)',
    date: formatDate('2024-03-20'),
    operationType: INHERITOR_OPERATION_TYPES[1].value,
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: 'd_intrans_khalifa_1',
    inheritorId: 'inheritor_khalifa',
    amount: 1750,
    description: 'توزيع من إيجارات محصلة (عمارة الفقيد صالح)',
    date: formatDate('2024-03-20'),
    operationType: INHERITOR_OPERATION_TYPES[1].value,
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: 'd_intrans_um_nasser_1',
    inheritorId: 'inheritor_um_nasser',
    amount: -125,
    description: 'نصيب من مصروفات صيانة التركة',
    date: formatDate('2024-04-05'),
    operationType: INHERITOR_OPERATION_TYPES[0].value,
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
];

export const mockBankTransactions: BankTransaction[] = [
  {
    id: `bank_trans_${Date.now()}_1`,
    date: formatDate('2024-05-01'),
    description: 'إيداع إيجار من محل "عمارة الفقيد صالح"',
    amountIncoming: 143750,
    attachments: [{name: 'إيصال إيداع بنكي.pdf', url: '#'}],
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: `bank_trans_${Date.now()}_2`,
    date: formatDate('2024-05-05'),
    description: 'سداد فاتورة كهرباء رقم 12345 للتركة',
    amountOutgoing: 500,
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
  {
    id: `bank_trans_${Date.now()}_3`,
    date: formatDate('2024-05-10'),
    description: 'مصروفات محامي لحصر الإرث',
    amountOutgoing: 5000,
    attachments: [{name: 'فاتورة المحامي.pdf', url: '#'}],
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
    {
    id: `bank_trans_${Date.now()}_4`,
    date: formatDate('2024-05-15'),
    description: 'تحويل حصة للوريث ناصر',
    amountOutgoing: 1750,
    lastModifiedBy: systemUser,
    lastModifiedAt: mockDate,
  },
];
