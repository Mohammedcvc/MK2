
import type { PropertyStatus, RentType, PaymentStatus, TaxRate, PropertyType, NumberOfInstallments, InheritorOperationType } from '@/types';
import type { BadgeProps } from "@/components/ui/badge";

export const PROPERTY_STATUSES: { value: PropertyStatus; label: string }[] = [
  { value: 'vacant', label: 'شاغر' },
  { value: 'rented', label: 'مؤجر' },
  { value: 'maintenance', label: 'تحت الصيانة' },
];

export const PROPERTY_TYPES: { value: PropertyType; label: string }[] = [
  { value: 'residential', label: 'سكني' },
  { value: 'commercial', label: 'تجاري' },
];

export const RENT_TYPES: { value: RentType; label: string }[] = [
  { value: 'annual', label: 'سنوي' },
  { value: 'monthly', label: 'شهري' },
];

export const PAYMENT_STATUSES: { value: PaymentStatus; label: string }[] = [
  { value: 'paid', label: 'مدفوعة' },
  { value: 'pending', label: 'قيد الانتظار' },
  { value: 'overdue', label: 'متأخرة' },
  { value: 'due', label: 'مستحقة' },
];

export const TAX_RATES: { value: TaxRate; label: string }[] = [
  { value: 0, label: '0%' },
  { value: 5, label: '5%' },
  { value: 10, label: '10%' },
  { value: 15, label: '15%' },
];

export const NUMBER_OF_INSTALLMENTS_OPTIONS: { value: NumberOfInstallments; label: string }[] = [
  { value: 1, label: 'دفعة واحدة' },
  { value: 2, label: 'نصف سنوي' },
  { value: 3, label: 'ثلث سنوي' },
  { value: 4, label: 'ربع سنوي' },
  { value: 5, label: 'خمس دفعات' },
  { value: 6, label: 'ست دفعات' },
  { value: 7, label: 'سبع دفعات' },
  { value: 8, label: 'ثمان دفعات' },
  { value: 9, label: 'تسع دفعات' },
  { value: 10, label: 'عشر دفعات' },
  { value: 11, label: 'إحدى عشرة دفعة' },
  { value: 12, label: 'اثنتا عشرة دفعة' },
  { value: 13, label: 'ثلاث عشرة دفعة' },
  { value: 14, label: 'أربع عشرة دفعة' },
  { value: 15, label: 'خمس عشرة دفعة' },
  { value: 16, label: 'ست عشرة دفعة' },
  { value: 17, label: 'سبع عشرة دفعة' },
  { value: 18, label: 'ثماني عشرة دفعة' },
  { value: 19, label: 'تسع عشرة دفعة' },
  { value: 20, label: 'عشرون دفعة' },
  { value: 21, label: 'إحدى وعشرون دفعة' },
  { value: 22, label: 'اثنتان وعشرون دفعة' },
  { value: 23, label: 'ثلاث وعشرون دفعة' },
  { value: 24, label: 'أربع وعشرون دفعة' },
  { value: 25, label: 'خمس وعشرون دفعة' },
  { value: 26, label: 'ست وعشرون دفعة' },
  { value: 27, label: 'سبع وعشرون دفعة' },
  { value: 28, label: 'ثمان وعشرون دفعة' },
  { value: 29, label: 'تسع وعشرون دفعة' },
  { value: 30, label: 'ثلاثون دفعة' },
];

export const RENT_PAYMENT_CYCLE_OPTIONS: { value: NumberOfInstallments; label: string }[] = [
  { value: 1, label: 'دفعة واحدة' },
  { value: 2, label: 'نصف سنوي' },
  { value: 3, label: 'ثلث سنوي' },
  { value: 4, label: 'ربع سنوي' },
  { value: 12, label: 'شهري' }, // Value 12 to signify monthly cycle
];


export const INHERITOR_OPERATION_TYPES: { value: InheritorOperationType; label: string }[] = [
  { value: 'cashWithdrawal', label: 'سحب نقدي' },
  { value: 'bankTransfer', label: 'تحويل بنكي' },
  { value: 'commissionExpense', label: 'مصروف عمولات' },
];


export const PROPERTY_STATUS_COLORS: Record<PropertyStatus, string> = {
  vacant: 'text-destructive', // Uses soft red from theme
  rented: 'text-accent', // Uses muted green from theme
  maintenance: 'text-yellow-500', // This will need to be re-evaluated if strictly sticking to theme colors. For now, it's a direct Tailwind class.
};

// Configuration for property status badges
export const PROPERTY_STATUS_BADGE_CONFIG: Record<PropertyStatus, { variant: BadgeProps['variant'], className?: string }> = {
  vacant: { variant: "destructive" }, // Red, themed
  rented: { variant: "default", className: "bg-accent text-accent-foreground hover:bg-accent/90 border-transparent" }, // Green, themed accent
  maintenance: { variant: "default" }, // Blue, themed primary (Badge 'default' variant uses primary color)
};


export const PAYMENT_STATUS_BADGE_VARIANT: Record<PaymentStatus, "default" | "secondary" | "destructive" | "outline"> = {
  paid: 'default',
  pending: 'secondary',
  overdue: 'destructive',
  due: 'outline',
};

export const getLabelForValue = <T extends string | number>(options: {value: T, label: string}[], value: T | undefined): string => {
  if (value === undefined) return '-';
  return options.find(opt => opt.value === value)?.label || String(value);
};

export const getNumberOfInstallmentsLabel = (value: NumberOfInstallments): string => {
  if (value === 12) return 'شهري'; // Special case for monthly from RENT_PAYMENT_CYCLE_OPTIONS
  const option = RENT_PAYMENT_CYCLE_OPTIONS.find(opt => opt.value === value);
  if (option) return option.label;
  // Fallback for numbers not in RENT_PAYMENT_CYCLE_OPTIONS but potentially in NUMBER_OF_INSTALLMENTS_OPTIONS
  const generalOption = NUMBER_OF_INSTALLMENTS_OPTIONS.find(opt => opt.value === value);
  return generalOption ? generalOption.label : `${value} دفعات`;
};

