
'use client';

import type { Property, Tenant, Payment, Expense, Owner, OwnerTransaction, Inheritor, InheritorTransaction, BankTransaction, User, UserPermissions } from '@/types';
import {
    mockProperties as initialMockProperties,
    mockTenants as initialMockTenants,
    mockPayments as initialMockPayments,
    mockExpenses as initialMockExpenses,
    mockOwners as initialMockOwners,
    mockOwnerTransactions as initialMockOwnerTransactions,
    mockDeceasedProperties as initialMockDeceasedProperties,
    mockDeceasedTenants as initialMockDeceasedTenants,
    mockDeceasedPayments as initialMockDeceasedPayments,
    mockDeceasedExpenses as initialMockDeceasedExpenses,
    mockInheritors as initialMockInheritors,
    mockDeceasedInheritorTransactions as initialMockDeceasedInheritorTransactions,
    mockBankTransactions as initialMockBankTransactions
} from '@/lib/mock-data';
import type { Dispatch, SetStateAction } from 'react';
import { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';

interface AppContextType {
  // Main properties
  properties: Property[];
  setProperties: Dispatch<SetStateAction<Property[]>>;
  tenants: Tenant[];
  setTenants: Dispatch<SetStateAction<Tenant[]>>;
  payments: Payment[];
  setPayments: Dispatch<SetStateAction<Payment[]>>;
  expenses: Expense[];
  setExpenses: Dispatch<SetStateAction<Expense[]>>;
  owners: Owner[];
  setOwners: Dispatch<SetStateAction<Owner[]>>;
  ownerTransactions: OwnerTransaction[];
  setOwnerTransactions: Dispatch<SetStateAction<OwnerTransaction[]>>;

  // Deceased properties
  deceasedProperties: Property[];
  setDeceasedProperties: Dispatch<SetStateAction<Property[]>>;
  deceasedTenants: Tenant[];
  setDeceasedTenants: Dispatch<SetStateAction<Tenant[]>>;
  deceasedPayments: Payment[];
  setDeceasedPayments: Dispatch<SetStateAction<Payment[]>>;
  deceasedExpenses: Expense[];
  setDeceasedExpenses: Dispatch<SetStateAction<Expense[]>>;
  deceasedInheritors: Inheritor[];
  setDeceasedInheritors: Dispatch<SetStateAction<Inheritor[]>>;
  deceasedInheritorTransactions: InheritorTransaction[];
  setDeceasedInheritorTransactions: Dispatch<SetStateAction<InheritorTransaction[]>>;
  bankTransactions: BankTransaction[];
  setBankTransactions: Dispatch<SetStateAction<BankTransaction[]>>;

  // Authentication & User Management
  currentUser: User | null;
  setCurrentUser: Dispatch<SetStateAction<User | null>>;
  allUsers: User[];
  setAllUsers: Dispatch<SetStateAction<User[]>>;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => void;
  isContextLoading: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Universal full permissions for all logged-in users
const universalFullPermissions: UserPermissions = {
  canDelete: true,
  canEdit: true,
  canAdd: true,
  canPrint: true,
};

// Specific permissions for the 'admin' role
const initialAdminPermissions: UserPermissions = {
  canDelete: true,
  canEdit: true,
  canAdd: true,
  canPrint: true,
};

// Default permissions for non-admin users
const defaultUserPermissions: UserPermissions = {
  canDelete: true,
  canEdit: true,
  canAdd: true,
  canPrint: true,
};


const initialAdminUser: User = {
  id: 'admin_user_001',
  username: 'admin',
  password: 'password',
  roles: ['admin'],
  permissions: { ...initialAdminPermissions }
};

const initialUserMohammed: User = {
  id: 'user_mohammed_258',
  username: 'محمد',
  password: 'password258258',
  roles: [],
  permissions: { ...defaultUserPermissions }
};

const initialUserMohammedAbdo: User = {
  id: 'user_mohammed_abdo',
  username: 'محمد عبده',
  password: 'password123',
  roles: ['admin'],
  permissions: { ...initialAdminPermissions }
};

const initialUserMohmmdNew: User = {
  id: 'user_mohmmd_new',
  username: 'mohmmd',
  password: '258258',
  roles: [],
  permissions: { ...defaultUserPermissions }
};


// Helper to load data from localStorage or use initial data
function loadState<T>(key: string, initialData: T): T {
  if (typeof window !== 'undefined') {
    const storedValue = localStorage.getItem(key);
    if (storedValue) {
      try {
        return JSON.parse(storedValue);
      } catch (error) {
        console.error(`Error parsing localStorage key "${key}":`, error);
        localStorage.removeItem(key); // Remove corrupted data
      }
    }
  }
  return initialData;
}

// Helper to save data to localStorage
function saveState<T>(key: string, data: T) {
  if (typeof window !== 'undefined') {
    localStorage.setItem(key, JSON.stringify(data));
  }
}


export function AppProvider({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const router = useRouter();

  // State for Main properties
  const [properties, setPropertiesState] = useState<Property[]>(() =>
    loadState<Property[]>('mockPropertiesData', initialMockProperties)
  );
  const [tenants, setTenantsState] = useState<Tenant[]>(() =>
    loadState<Tenant[]>('mockTenantsData', initialMockTenants)
  );
  const [payments, setPaymentsState] = useState<Payment[]>(() =>
    loadState<Payment[]>('mockPaymentsData', initialMockPayments)
  );
  const [expenses, setExpensesState] = useState<Expense[]>(() =>
    loadState<Expense[]>('mockExpensesData', initialMockExpenses)
  );
  const [owners, setOwnersState] = useState<Owner[]>(() =>
    loadState<Owner[]>('mockOwnersData', initialMockOwners)
  );
  const [ownerTransactions, setOwnerTransactionsState] = useState<OwnerTransaction[]>(() =>
    loadState<OwnerTransaction[]>('mockOwnerTransactionsData', initialMockOwnerTransactions)
  );

  // State for Deceased properties
  const [deceasedProperties, setDeceasedPropertiesState] = useState<Property[]>(() =>
    loadState<Property[]>('mockDeceasedPropertiesData', initialMockDeceasedProperties)
  );
  const [deceasedTenants, setDeceasedTenantsState] = useState<Tenant[]>(() =>
    loadState<Tenant[]>('mockDeceasedTenantsData', initialMockDeceasedTenants)
  );
  const [deceasedPayments, setDeceasedPaymentsState] = useState<Payment[]>(() =>
    loadState<Payment[]>('mockDeceasedPaymentsData', initialMockDeceasedPayments)
  );
  const [deceasedExpenses, setDeceasedExpensesState] = useState<Expense[]>(() =>
    loadState<Expense[]>('mockDeceasedExpensesData', initialMockDeceasedExpenses)
  );
  const [deceasedInheritors, setDeceasedInheritorsState] = useState<Inheritor[]>(() =>
    loadState<Inheritor[]>('mockInheritorsData', initialMockInheritors)
  );
  const [deceasedInheritorTransactions, setDeceasedInheritorTransactionsState] = useState<InheritorTransaction[]>(() =>
    loadState<InheritorTransaction[]>('mockDeceasedInheritorTransactionsData', initialMockDeceasedInheritorTransactions)
  );
  const [bankTransactions, setBankTransactionsState] = useState<BankTransaction[]>(() =>
    loadState<BankTransaction[]>('mockBankTransactionsData', initialMockBankTransactions)
  );

  // Authentication state
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [allUsers, setAllUsersState] = useState<User[]>(() =>
    loadState<User[]>('allUsersData', [
      { ...initialAdminUser, permissions: { ...initialAdminPermissions } },
      { ...initialUserMohammed, permissions: { ...defaultUserPermissions } },
      { ...initialUserMohammedAbdo, permissions: { ...initialAdminPermissions } },
      { ...initialUserMohmmdNew, permissions: { ...defaultUserPermissions } },
    ])
  );
  const [isContextLoading, setIsContextLoading] = useState(true);

  // Wrapped state setters to include localStorage saving
  const setProperties: Dispatch<SetStateAction<Property[]>> = (data) => {
    setPropertiesState(data);
    saveState('mockPropertiesData', typeof data === 'function' ? data(properties) : data);
  };
  const setTenants: Dispatch<SetStateAction<Tenant[]>> = (data) => {
    setTenantsState(data);
    saveState('mockTenantsData', typeof data === 'function' ? data(tenants) : data);
  };
  const setPayments: Dispatch<SetStateAction<Payment[]>> = (data) => {
    setPaymentsState(data);
    saveState('mockPaymentsData', typeof data === 'function' ? data(payments) : data);
  };
  const setExpenses: Dispatch<SetStateAction<Expense[]>> = (data) => {
    setExpensesState(data);
    saveState('mockExpensesData', typeof data === 'function' ? data(expenses) : data);
  };
  const setOwners: Dispatch<SetStateAction<Owner[]>> = (data) => {
    setOwnersState(data);
    saveState('mockOwnersData', typeof data === 'function' ? data(owners) : data);
  };
  const setOwnerTransactions: Dispatch<SetStateAction<OwnerTransaction[]>> = (data) => {
    setOwnerTransactionsState(data);
    saveState('mockOwnerTransactionsData', typeof data === 'function' ? data(ownerTransactions) : data);
  };
  const setDeceasedProperties: Dispatch<SetStateAction<Property[]>> = (data) => {
    setDeceasedPropertiesState(data);
    saveState('mockDeceasedPropertiesData', typeof data === 'function' ? data(deceasedProperties) : data);
  };
  const setDeceasedTenants: Dispatch<SetStateAction<Tenant[]>> = (data) => {
    setDeceasedTenantsState(data);
    saveState('mockDeceasedTenantsData', typeof data === 'function' ? data(deceasedTenants) : data);
  };
  const setDeceasedPayments: Dispatch<SetStateAction<Payment[]>> = (data) => {
    setDeceasedPaymentsState(data);
    saveState('mockDeceasedPaymentsData', typeof data === 'function' ? data(deceasedPayments) : data);
  };
  const setDeceasedExpenses: Dispatch<SetStateAction<Expense[]>> = (data) => {
    setDeceasedExpensesState(data);
    saveState('mockDeceasedExpensesData', typeof data === 'function' ? data(deceasedExpenses) : data);
  };
  const setDeceasedInheritors: Dispatch<SetStateAction<Inheritor[]>> = (data) => {
    setDeceasedInheritorsState(data);
    saveState('mockInheritorsData', typeof data === 'function' ? data(deceasedInheritors) : data);
  };
  const setDeceasedInheritorTransactions: Dispatch<SetStateAction<InheritorTransaction[]>> = (data) => {
    setDeceasedInheritorTransactionsState(data);
    saveState('mockDeceasedInheritorTransactionsData', typeof data === 'function' ? data(deceasedInheritorTransactions) : data);
  };
  const setBankTransactions: Dispatch<SetStateAction<BankTransaction[]>> = (data) => {
    setBankTransactionsState(data);
    saveState('mockBankTransactionsData', typeof data === 'function' ? data(bankTransactions) : data);
  };
   const setAllUsers: Dispatch<SetStateAction<User[]>> = (data) => {
    const newUsers = typeof data === 'function' ? data(allUsers) : data;
    setAllUsersState(newUsers);
    saveState('allUsersData', newUsers);
  };


  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      try {
        const parsedUser: User = JSON.parse(storedUser);
        // Ensure permissions are correctly applied on load
        const roles = parsedUser.roles || [];
        const effectivePermissions = roles.includes('admin') ? { ...initialAdminPermissions } : { ...defaultUserPermissions };
        setCurrentUser({ ...parsedUser, permissions: effectivePermissions });
      } catch (e) {
        console.error("Failed to parse stored user:", e);
        localStorage.removeItem('currentUser');
        setCurrentUser(null);
      }
    } else {
        setCurrentUser(null);
    }
    setIsContextLoading(false);
  }, []);

  const login = async (usernameInput: string, passwordInput: string): Promise<boolean> => {
    const userToLogin = allUsers.find(u => u.username === usernameInput);

    if (userToLogin && userToLogin.password === passwordInput) {
      const roles = userToLogin.roles || [];
      // All users get full permissions as per last request
      const effectivePermissions = { ...universalFullPermissions };
      
      const loggedInUser = { ...userToLogin, permissions: effectivePermissions };

      setCurrentUser(loggedInUser);
      localStorage.setItem('currentUser', JSON.stringify(loggedInUser));
      toast({ title: 'تم تسجيل الدخول بنجاح', description: `مرحباً بك ${loggedInUser.username}!` });
      return true;
    }
    toast({ title: 'فشل تسجيل الدخول', description: 'اسم المستخدم أو كلمة المرور غير صحيحة.', variant: 'destructive' });
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
    toast({ title: 'تم تسجيل الخروج' });
    router.push('/login');
  };

  return (
    <AppContext.Provider value={{
        properties, setProperties,
        tenants, setTenants,
        payments, setPayments,
        expenses, setExpenses,
        owners, setOwners,
        ownerTransactions, setOwnerTransactions,

        deceasedProperties, setDeceasedProperties,
        deceasedTenants, setDeceasedTenants,
        deceasedPayments, setDeceasedPayments,
        deceasedExpenses, setDeceasedExpenses,
        deceasedInheritors, setDeceasedInheritors,
        deceasedInheritorTransactions, setDeceasedInheritorTransactions,
        bankTransactions, setBankTransactions,

        currentUser, setCurrentUser,
        allUsers, setAllUsers,
        login,
        logout,
        isContextLoading
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext(): AppContextType {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}

    