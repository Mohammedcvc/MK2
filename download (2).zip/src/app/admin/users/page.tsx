
import { UserManagementDashboard } from '@/components/user-management-dashboard';

export default function UserManagementPage() {
  return <UserManagementDashboard />;
}
