
'use client';

import { useAppContext } from '@/contexts/app-context';
import { useRouter, usePathname } from 'next/navigation';
import React, { useEffect } from 'react';
import { Loader2 } from 'lucide-react';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { currentUser, isContextLoading } = useAppContext();
  const router = useRouter();
  const pathname = usePathname();
  // Removed: useLanguage

  useEffect(() => {
    if (!isContextLoading && !currentUser) {
      router.replace(`/login?redirect=${pathname}`);
    }
  }, [currentUser, isContextLoading, router, pathname]);

  if (isContextLoading || !currentUser) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-var(--header-height,100px))]">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p className="text-lg text-muted-foreground">يتم التحقق من صلاحيات الدخول...</p>
      </div>
    );
  }

  return <>{children}</>;
}
