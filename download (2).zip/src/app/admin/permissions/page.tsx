
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldCheck, UserCog } from 'lucide-react';

function UserPermissionsContent() {
  // Removed useLanguage hook

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle className="text-sm font-semibold flex items-center"> {/* Changed from text-2xl */}
            <ShieldCheck className="me-3 h-7 w-7 text-primary" />
            {'صلاحيات المستخدمين'}
          </CardTitle>
          <CardDescription className="text-sm font-semibold"> {/* Added text-sm font-semibold */}
            {'نظام صلاحيات مبسط قائم على الأدوار.'}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-6 border border-dashed rounded-md text-center text-muted-foreground bg-muted/20">
            <UserCog className="mx-auto h-12 w-12 text-primary/50 mb-3" />
            <h3 className="text-lg font-medium">{'إدارة الصلاحيات عبر الأدوار'}</h3>
            <p className="text-sm mt-2">
              {'يتم تحديد صلاحيات المستخدمين (الإضافة، التعديل، الحذف، الطباعة) بشكل أساسي من خلال دور "المسؤول".'}
            </p>
            <p className="text-sm mt-1">
              {'المستخدمون الذين لديهم دور "مسؤول" يمتلكون جميع الصلاحيات تلقائيًا.'}
            </p>
            <p className="text-sm mt-1">
              {'بالنسبة للمستخدمين الآخرين، يتم منح صلاحية "الطباعة" بشكل افتراضي، بينما تكون صلاحيات الإضافة والتعديل والحذف معطلة.'}
            </p>
            <p className="text-sm mt-1"
               dangerouslySetInnerHTML={{ __html: 'يمكنك إدارة أدوار المستخدمين الفرديين من خلال صفحة <a href="/admin/users" class="text-primary hover:underline">إدارة المستخدمين</a>.' }}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function UserPermissionsPage() {
  return <UserPermissionsContent />;
}

