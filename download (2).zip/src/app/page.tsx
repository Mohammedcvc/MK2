
'use client';

import { useMemo, useState, useEffect } from 'react';
import { useRouter, useSearchParams, usePathname } from 'next/navigation';
import type { Property, Tenant, Payment, Owner, OwnerTransaction, SmartPropertyActiveView } from '@/types';
import { LayoutGrid, Search, TrendingUp, BadgePercent, Building, FileText as FileTextIcon, Wallet, WalletCards, Home, UserMinus, Receipt, UsersRound, Settings, PanelLeft, Landmark, User, LogIn, Loader2, CalendarClock, AlertTriangle, Users as UsersIconProp, ArrowRight, ListFilter, BarChart3, Sigma as SigmaIcon, ChevronDown, Printer as PrinterIcon, BarChartHorizontalBig } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DashboardSummaryCard } from '@/components/dashboard-summary-card';
import { RentedPropertyCard } from '@/components/rented-property-card';
import { TenantMovementTable } from '@/components/tenant-movement-table';
import { PropertyManagementDashboard } from '@/components/property-management-dashboard';
import { ExpensesDashboard } from '@/components/expenses-dashboard';
import { OwnersDashboard } from '@/components/owners-dashboard';
import { UserManagementDashboard } from '@/components/user-management-dashboard';
import { useAppContext } from '@/contexts/app-context';
import { TenantReportModal } from '@/components/tenant-report-modal';
import { OwnerReportModal } from '@/components/owner-report-modal';
import { SmartTenantMovementReportModal } from '@/components/smart-tenant-movement-report-modal';
import { DeceasedPropertiesDashboard } from '@/components/deceased-properties-dashboard';
import { SmartContractStatusReport } from '@/components/smart-contract-status-report';
import { OverdueAndDuePaymentsReport } from '@/components/overdue-and-due-payments-report';
import { AccountStatementReport } from '@/components/account-statement-report';
import { TaxReport } from '@/components/tax-report';
import { ProfitAndLossReport } from '@/components/profit-and-loss-report';
import { ChartsReport } from '@/components/charts-report';

import { isPast, parseISO, format } from 'date-fns';
import { cn } from '@/lib/utils';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SheetTitle } from '@/components/ui/sheet'; // For mobile sidebar accessibility


type MainView = 'smart' | 'deceased';

interface NavItem {
  id: SmartPropertyActiveView;
  label: string;
  icon: React.ElementType;
  isReport?: boolean;
}

export default function HomePage() {
  const {
    currentUser, isContextLoading,
    properties, setProperties,
    tenants, setTenants,
    payments, setPayments,
    expenses,
    owners, ownerTransactions, // Ensure owners is available for OwnersDashboard
    setOwners // Ensure setOwners is available if OwnersDashboard needs to modify owners
  } = useAppContext();
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { toast } = useToast();

  const [isTenantReportModalOpen, setIsTenantReportModalOpen] = useState(false);
  const [isSmartTenantMovementReportModalOpen, setIsSmartTenantMovementReportModalOpen] = useState(false);
  const [selectedTenantForReport, setSelectedTenantForReport] = useState<Tenant | null>(null);
  const [selectedPropertyForReport, setSelectedPropertyForReport] = useState<Property | null>(null);
  const [selectedTenantPaymentsForReport, setSelectedTenantPaymentsForReport] = useState<Payment[]>([]);

  const [isOwnerReportModalOpen, setIsOwnerReportModalOpen] = useState(false);
  const [selectedOwnerForReport, setSelectedOwnerForReport] = useState<Owner | null>(null);
  const [selectedOwnerTransactionsForReport, setSelectedOwnerTransactionsForReport] = useState<OwnerTransaction[]>([]);

  const [currentDateFormatted, setCurrentDateFormatted] = useState('');
  useEffect(() => {
    setCurrentDateFormatted(format(new Date(), 'yyyy-MM-dd'));
  }, []);

  const [mainView, setMainView] = useState<MainView>('smart');
  const [activeSmartPropertyView, setActiveSmartPropertyView] = useState<SmartPropertyActiveView>('dashboard');

  useEffect(() => {
    if (!isContextLoading && !currentUser) {
      router.replace(`/login?redirect=${pathname}${searchParams.toString() ? `&${searchParams.toString()}` : ''}`);
    }
  }, [currentUser, isContextLoading, router, pathname, searchParams]);


  useEffect(() => {
    const viewParam = searchParams.get('view');
    if (viewParam === 'deceased') {
      setMainView('deceased');
    } else {
      setMainView('smart');
    }
  }, [searchParams]);


  const handleSelectProperty = (property: Property) => {
    router.push(`/properties/${property.id}`);
  };

  const handleSelectPropertyForDetails = (property: Property) => {
    router.push(`/properties/${property.id}`);
  };

  const totalRents = useMemo(() => {
    return tenants.filter(tenant => {
      const property = properties.find(p => p.id === tenant.propertyId);
      if (!property || property.status !== 'rented') return false;
      if (!tenant.contractEndDate) return false;
      try {
        return !isPast(parseISO(tenant.contractEndDate));
      } catch {
        return false;
      }
    }).reduce((sum, tenant) => sum + tenant.contractValue, 0);
  }, [tenants, properties]);

  const totalPaid = useMemo(() => {
    return payments.reduce((sum, payment) => sum + payment.amountPaid, 0);
  }, [payments]);

  const totalTax = useMemo(() => {
    return tenants.filter(tenant => {
      const property = properties.find(p => p.id === tenant.propertyId);
      if (!property || property.status !== 'rented') return false;
      if (!tenant.contractEndDate) return false;
      try {
        return !isPast(parseISO(tenant.contractEndDate));
      } catch {
        return false;
      }
    }).reduce((sum, tenant) => {
      return sum + (tenant.contractValue * (tenant.taxRate / 100));
    }, 0);
  }, [tenants, properties]);

  const remainingBalance = useMemo(() => {
    const totalContractValuesWithTax = tenants.filter(tenant => {
      const property = properties.find(p => p.id === tenant.propertyId);
      if (!property || property.status !== 'rented') return false;
      if (!tenant.contractEndDate) return false;
      try {
        return !isPast(parseISO(tenant.contractEndDate));
      } catch {
        return false;
      }
    }).reduce((acc, t) => acc + (t.contractValue * (1 + t.taxRate / 100)), 0);
    return totalContractValuesWithTax - totalPaid;
  }, [tenants, properties, totalPaid]);

  const activeContractsCount = useMemo(() => tenants.filter(t => {
    const property = properties.find(p => p.id === t.propertyId);
    if (!property || property.status !== 'rented') return false;
    if (!t.contractEndDate) return false;
    try {
      return !isPast(parseISO(t.contractEndDate));
    } catch {
      return false;
    }
  }).length, [tenants, properties]);

  const rentedPropertiesData = useMemo(() => {
    return properties
      .filter(property => property.status === 'rented')
      .map(property => {
        const tenant = tenants.find(t => {
          if (t.propertyId !== property.id) return false;
          if (!t.contractEndDate) return false;
          try {
            return !isPast(parseISO(t.contractEndDate));
          } catch {
            return false;
          }
        });
        if (!tenant) return null;
        const tenantPayments = payments.filter(p => p.tenantId === tenant.tenantId);
        return { property, tenant, payments: tenantPayments };
      })
      .filter(item => item !== null) as { property: Property; tenant: Tenant; payments: Payment[] }[];
  }, [properties, tenants, payments]);

  const departedPropertiesData = useMemo(() => {
    return tenants
      .filter(tenant => {
        if (!tenant.contractEndDate) return true;
        try {
          return isPast(parseISO(tenant.contractEndDate));
        } catch {
          return false;
        }
      })
      .map(tenant => {
        const property = properties.find(p => p.id === tenant.propertyId);
        if (!property) return null;

        const tenantPayments = payments.filter(p => p.tenantId === tenant.tenantId);
        return { property, tenant, payments: tenantPayments };
      })
      .filter(item => item !== null) as { property: Property; tenant: Tenant; payments: Payment[] }[];
  }, [properties, tenants, payments]);

  const [searchTerm, setSearchTerm] = useState('');
  const filteredTenantMovements = useMemo(() => {
    if (!searchTerm) return tenants;
    return tenants.filter(tenant =>
      tenant.tenantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (properties.find(p => p.id === tenant.propertyId)?.name.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [tenants, properties, searchTerm]);

  const handleAddProperty = (newPropertyData: Omit<Property, 'id' | 'imageUrl' | 'lastModifiedBy' | 'lastModifiedAt'> & { ownerId?: string }) => {
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();
    const newProperty: Property = {
        ...newPropertyData,
        id: `prop${Date.now()}`,
        imageUrl: `https://placehold.co/400x300.png`,
        ownerId: newPropertyData.ownerId || undefined, // Ensure ownerId is handled
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
    }
    setProperties(prev => [...prev, newProperty]);
    toast({ title: 'تم إضافة العقار', description: `تم إضافة ${newProperty.name} بنجاح.` });
  };

  const handleUpdateProperty = (updatedProperty: Property) => {
    setProperties(prev => prev.map(p => p.id === updatedProperty.id ? updatedProperty : p));
    toast({ title: 'تم تحديث العقار', description: `تم تحديث ${updatedProperty.name} بنجاح.` });
  };

  const handleDeleteProperty = (propertyId: string) => {
    const propertyToDelete = properties.find(p => p.id === propertyId);
    if (!propertyToDelete) return;
    const propertyName = propertyToDelete.name;
    setProperties(prevProperties => prevProperties.filter(p => p.id !== propertyId));
    const relatedTenantIds = tenants.filter(t => t.propertyId === propertyId).map(t => t.tenantId);
    setTenants(prevTenants => prevTenants.filter(t => t.propertyId !== propertyId));
    setPayments(prevPayments => prevPayments.filter(p => !relatedTenantIds.includes(p.tenantId)));
    toast({
      title: 'تم حذف العقار',
      description: `تم حذف العقار "${propertyName}" وجميع بيانات المستأجرين والدفعات المرتبطة به.`,
      variant: "destructive"
    });
  };

  const handleSelectTenantForReport = (tenant: Tenant) => {
    const property = properties.find(p => p.id === tenant.propertyId);
    const tenantPayments = payments.filter(p => p.tenantId === tenant.tenantId);
    setSelectedTenantForReport(tenant);
    setSelectedPropertyForReport(property || null);
    setSelectedTenantPaymentsForReport(tenantPayments);
    setIsTenantReportModalOpen(true);
  };

  const handleOpenSmartTenantMovementReport = () => {
    if (tenants.length === 0) {
        toast({
            title: "لا توجد بيانات",
            description: "لا يوجد مستأجرين لعرضهم في تقرير حركة المستأجرين.",
            variant: "default",
        });
        return;
    }
    setIsSmartTenantMovementReportModalOpen(true);
  };

  const ownerBalances = useMemo(() => {
    return owners.map(owner => {
      const transactions = ownerTransactions.filter(t => t.ownerId === owner.id);
      const netBalance = transactions.reduce((sum, t) => sum + t.amount, 0);
      return {
        ...owner,
        netBalance,
      };
    });
  }, [owners, ownerTransactions]);

  const handleOpenOwnerReport = (owner: Owner) => {
    const transactions = ownerTransactions.filter(t => t.ownerId === owner.id);
    setSelectedOwnerForReport(owner);
    setSelectedOwnerTransactionsForReport(transactions);
    setIsOwnerReportModalOpen(true);
  };


  const allNavItems: NavItem[] = [
    { id: 'dashboard', label: 'لوحة التحكم', icon: LayoutGrid },
    { id: 'propertyManagement', label: 'إدارة العقارات', icon: Building },
    { id: 'expenses', label: 'المصروفات', icon: Receipt },
    { id: 'owners', label: 'الملاك', icon: UsersRound },
    { id: 'userManagement', label: 'إدارة المستخدمين', icon: UsersIconProp },
    // Reports
    { id: 'contractStatusReport', label: 'تقرير حالات العقود', icon: CalendarClock, isReport: true },
    { id: 'overdueAndDuePaymentsReport', label: 'تقرير الدفعات الهامة', icon: AlertTriangle, isReport: true },
    { id: 'accountStatementReport', label: 'كشف الحساب', icon: ListFilter, isReport: true },
    { id: 'taxReport', label: 'تقرير الضريبة', icon: BarChart3, isReport: true },
    { id: 'profitAndLossReport', label: 'تقرير الأرباح والخسائر', icon: SigmaIcon, isReport: true },
    { id: 'chartsReport', label: 'التقارير البيانية', icon: BarChartHorizontalBig, isReport: true },
  ];

  const mainNavItems = allNavItems.filter(item => !item.isReport);
  const reportNavItems = allNavItems.filter(item => item.isReport);


  if (isContextLoading || !currentUser) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-var(--header-height,100px))]">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p className="text-lg text-muted-foreground">يتم التحقق من صلاحيات الدخول...</p>
      </div>
    );
  }

  const activeNavItem = allNavItems.find(item => item.id === activeSmartPropertyView) || allNavItems[0];

  const accordionDefaultValues = [
    "dashboard-info-accordion",
    "owner-balances-accordion",
    "rented-shops-accordion",
    "departed-shops-accordion",
    "tenant-movements-accordion"
  ];

  const renderSmartPropertyContent = () => {
    switch (activeSmartPropertyView) {
      case 'dashboard':
        return (
          <div className="space-y-8">
            <Accordion type="multiple" defaultValue={accordionDefaultValues} className="space-y-6">
              <AccordionItem value="dashboard-info-accordion" className="border-b-0">
                <Card>
                  <AccordionTrigger className="w-full px-6 py-4 hover:no-underline flex justify-between items-center data-[state=open]:border-b">
                    <CardTitle className="text-lg flex items-center">
                      <LayoutGrid className="me-3 h-7 w-7 text-primary" />
                      {'لوحة المعلومات'}
                    </CardTitle>
                  </AccordionTrigger>
                  <AccordionContent>
                    <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 pt-6">
                      <DashboardSummaryCard
                        title={'إجمالي الإيجارات'}
                        value={totalRents}
                        icon={TrendingUp}
                        description={`${activeContractsCount} عقد نشط`}
                        iconBgColor="bg-accent"
                        iconColor="text-accent-foreground"
                      />
                      <DashboardSummaryCard
                        title={'إجمالي الضريبة'}
                        value={totalTax}
                        icon={BadgePercent}
                        description={`نسبة الضريبة ${tenants.length > 0 && tenants.find(t => t.contractEndDate && !isPast(parseISO(t.contractEndDate))) ? tenants.find(t => t.contractEndDate && !isPast(parseISO(t.contractEndDate)))!.taxRate : 0}% (للعقود النشطة)`}
                        iconBgColor="bg-yellow-100"
                        iconColor="text-yellow-600"
                      />
                      <DashboardSummaryCard
                        title={'إجمالي المدفوعات'}
                        value={totalPaid}
                        icon={Wallet}
                        description={'خلال الفترة'}
                        iconBgColor="bg-green-100"
                        iconColor="text-green-600"
                      />
                      <DashboardSummaryCard
                        title={'الرصيد المتبقي'}
                        value={remainingBalance}
                        icon={WalletCards}
                        description={'رصيد مدين/دائن (للعقود النشطة)'}
                        iconBgColor="bg-red-100"
                        iconColor="text-red-600"
                        valueClassName={remainingBalance < 0 ? "text-green-600" : "text-destructive"}
                      />
                    </CardContent>
                  </AccordionContent>
                </Card>
              </AccordionItem>

              {ownerBalances.length > 0 && (
                <AccordionItem value="owner-balances-accordion" className="border-b-0">
                  <Card>
                    <AccordionTrigger className="w-full px-6 py-4 hover:no-underline flex justify-between items-center data-[state=open]:border-b">
                      <CardTitle className="text-lg">{'ملخص أرصدة الملاك'}</CardTitle>
                    </AccordionTrigger>
                    <AccordionContent>
                      <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-6">
                        {ownerBalances.map(owner => (
                          <div
                            key={owner.id}
                            onClick={() => handleOpenOwnerReport(owner)}
                            className="cursor-pointer rounded-lg overflow-hidden transition-shadow hover:shadow-lg"
                            role="button"
                            tabIndex={0}
                            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleOpenOwnerReport(owner); }}
                          >
                            <DashboardSummaryCard
                              title={`المالك: ${owner.name}`}
                              value={owner.netBalance}
                              icon={User}
                              description={'رصيد الحساب الحالي'}
                              iconBgColor="bg-purple-100"
                              iconColor="text-purple-600"
                              valueClassName={owner.netBalance >= 0 ? 'text-green-600' : 'text-destructive'}
                            />
                          </div>
                        ))}
                      </CardContent>
                    </AccordionContent>
                  </Card>
                </AccordionItem>
              )}

              <AccordionItem value="rented-shops-accordion" className="border-b-0">
                <Card>
                  <AccordionTrigger className="w-full px-6 py-4 hover:no-underline flex justify-between items-center data-[state=open]:border-b">
                    <CardTitle className="text-lg flex items-center"><Home className="me-2 h-5 w-5 text-primary" />{'المتاجر المؤجرة'}</CardTitle>
                  </AccordionTrigger>
                  <AccordionContent>
                    <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-6">
                      {rentedPropertiesData.map(({ property, tenant, payments }) => property && (
                          <RentedPropertyCard
                            key={`${property.id}-${tenant.tenantId}-rented`}
                            property={property}
                            tenant={tenant}
                            payments={payments}
                            dataSource="main"
                            onViewDetails={handleSelectPropertyForDetails}
                          />
                        )
                      )}
                      {rentedPropertiesData.length === 0 && <p className="col-span-full text-center text-muted-foreground py-4">{'لا توجد متاجر مؤجرة حالياً.'}</p>}
                    </CardContent>
                  </AccordionContent>
                </Card>
              </AccordionItem>

              <AccordionItem value="departed-shops-accordion" className="border-b-0">
                <Card>
                  <AccordionTrigger className="w-full px-6 py-4 hover:no-underline flex justify-between items-center data-[state=open]:border-b">
                    <CardTitle className="text-lg flex items-center"><UserMinus className="me-2 h-5 w-5 text-primary" />{'المتاجر المغادرة'}</CardTitle>
                  </AccordionTrigger>
                  <AccordionContent>
                    <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-6">
                      {departedPropertiesData.map(({ property, tenant, payments }) => property && (
                          <RentedPropertyCard
                            key={`${property.id}-${tenant.tenantId}-departed`}
                            property={property}
                            tenant={tenant}
                            payments={payments}
                            dataSource="main"
                            onViewDetails={handleSelectPropertyForDetails}
                          />
                        )
                      )}
                      {departedPropertiesData.length === 0 && <p className="col-span-full text-center text-muted-foreground py-4">{'لا توجد متاجر غادرها مستأجرون مؤخرًا.'}</p>}
                    </CardContent>
                  </AccordionContent>
                </Card>
              </AccordionItem>

              <AccordionItem value="tenant-movements-accordion" className="border-b-0">
                <Card>
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 p-6 data-[state=open]:border-b">
                    <AccordionTrigger className="flex-grow text-right p-0 hover:no-underline [&_svg.lucide-chevron-down]:ms-2">
                      <CardTitle className="text-lg">{'حركة المستأجرين'}</CardTitle>
                    </AccordionTrigger>
                    <div className="flex items-center gap-2">
                      <div className="relative w-full md:w-72">
                        <Search className={cn("absolute top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground", 'right-3')} />
                        <Input
                          placeholder={'بحث...'}
                          className={'pe-10'}
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                        />
                      </div>
                      <Button variant="outline" onClick={handleOpenSmartTenantMovementReport}>
                        <FileTextIcon className="me-2 h-4 w-4" />
                        {'تقرير الحركة'}
                      </Button>
                    </div>
                  </div>
                  <AccordionContent>
                    <CardContent className="pt-0">
                      <TenantMovementTable
                        tenants={filteredTenantMovements}
                        properties={properties}
                        payments={payments}
                        onTenantSelect={handleSelectTenantForReport}
                      />
                    </CardContent>
                  </AccordionContent>
                </Card>
              </AccordionItem>
            </Accordion>
          </div>
        );
      case 'propertyManagement':
        return (
          <PropertyManagementDashboard
            properties={properties}
            onAddProperty={handleAddProperty}
            onUpdateProperty={handleUpdateProperty}
            onDeleteProperty={handleDeleteProperty}
            onSelectProperty={handleSelectProperty}
            owners={owners}
          />
        );
      case 'expenses':
        return <ExpensesDashboard />;
      case 'owners':
        return <OwnersDashboard />; // OwnersDashboard is already designed for this.
      case 'userManagement':
        return <UserManagementDashboard />;
      case 'contractStatusReport':
        return <SmartContractStatusReport onBackToDashboard={() => setActiveSmartPropertyView('dashboard')} />;
      case 'overdueAndDuePaymentsReport':
        return <OverdueAndDuePaymentsReport properties={properties} tenants={tenants} payments={payments} reportTitleKey="smartOverdueAndDuePaymentsReportTitle" onBackToDashboard={() => setActiveSmartPropertyView('dashboard')} />;
      case 'accountStatementReport':
        return <AccountStatementReport tenants={tenants} payments={payments} properties={properties} reportTitleKey="accountStatementReportTitle" onBackToDashboard={() => setActiveSmartPropertyView('dashboard')} />;
      case 'taxReport':
        return <TaxReport tenants={tenants} payments={payments} properties={properties} reportTitle="تقرير الضريبة (العقار الذكي)" onBackToDashboard={() => setActiveSmartPropertyView('dashboard')} />;
      case 'profitAndLossReport':
        return <ProfitAndLossReport payments={payments} expenses={expenses} reportTitle="تقرير الأرباح والخسائر (العقار الذكي)" onBackToDashboard={() => setActiveSmartPropertyView('dashboard')} />;
      case 'chartsReport':
        return <ChartsReport payments={payments} expenses={expenses} tenants={tenants} properties={properties} reportTitle="التقارير البيانية (العقار الذكي)" onBackToDashboard={() => setActiveSmartPropertyView('dashboard')} />;
      default:
        return null;
    }
  };


  if (mainView === 'deceased') {
    return (
      <>
        <DeceasedPropertiesDashboard />
      </>
    );
  }

  return (
    <>
      <nav className="bg-card border-b shadow-sm sticky top-[calc(var(--header-height,60px)+1px)] z-40">
        <div className="container mx-auto px-4 py-2 flex items-center justify-center space-x-1 rtl:space-x-reverse overflow-x-auto">
          {mainNavItems.map((item) => (
            <Button
              key={item.id}
              variant={activeSmartPropertyView === item.id ? 'default' : 'ghost'}
              onClick={() => setActiveSmartPropertyView(item.id)}
              className="flex-shrink-0 px-3 py-2 text-sm font-semibold"
            >
              <item.icon className="me-2 h-4 w-4" />
              {item.label}
            </Button>
          ))}
          {reportNavItems.length > 0 && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex-shrink-0 px-3 py-2 text-sm font-semibold">
                  <FileTextIcon className="me-2 h-4 w-4" />
                  التقارير
                  <ChevronDown className="ms-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {reportNavItems.map((reportItem) => (
                  <DropdownMenuItem
                    key={reportItem.id}
                    onClick={() => setActiveSmartPropertyView(reportItem.id)}
                    className={cn(activeSmartPropertyView === reportItem.id && "bg-accent text-accent-foreground")}
                  >
                    <reportItem.icon className="me-2 h-4 w-4" />
                    {reportItem.label}
                  </DropdownMenuItem>
                ))}
                  <DropdownMenuItem
                    onClick={() => router.push('/smart-consolidated-report')}
                  >
                    <PrinterIcon className="me-2 h-4 w-4" />
                    طباعة تقرير مجمع
                  </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </nav>

      <main className="flex-1 p-4 md:p-6">
        {renderSmartPropertyContent()}
      </main>

      {selectedTenantForReport && selectedPropertyForReport && (
        <TenantReportModal
          isOpen={isTenantReportModalOpen}
          onClose={() => setIsTenantReportModalOpen(false)}
          tenant={selectedTenantForReport}
          property={selectedPropertyForReport}
          payments={selectedTenantPaymentsForReport}
        />
      )}
      {selectedOwnerForReport && (
        <OwnerReportModal
          isOpen={isOwnerReportModalOpen}
          onClose={() => setIsOwnerReportModalOpen(false)}
          owner={selectedOwnerForReport}
          transactions={selectedOwnerTransactionsForReport}
          totalAmount={ownerBalances.find(ob => ob.id === selectedOwnerForReport.id)?.netBalance || 0}
        />
      )}
      <SmartTenantMovementReportModal
        isOpen={isSmartTenantMovementReportModalOpen}
        onClose={() => setIsSmartTenantMovementReportModalOpen(false)}
        tenants={tenants}
        properties={properties}
        payments={payments}
      />
    </>
  );
}
    