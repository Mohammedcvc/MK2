
'use client';

import type { Property, Tenant, Payment, TaxRate, RentType, PropertyStatus, NumberOfInstallments, Attachment, OwnerTransaction, Inheritor, InheritorTransaction, BankTransaction } from '@/types';
import { useAppContext } from '@/contexts/app-context';
import { useParams, useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { PaymentHistoryTable } from '@/components/payment-history-table';
import { AddEditPaymentModal, PaymentFormValues } from '@/components/add-edit-payment-modal';
import { DeletePaymentDialog } from '@/components/delete-payment-dialog';
import { AddEditContractModal, ContractFormValues } from '@/components/add-edit-contract-modal';
import { DeleteContractDialog } from '@/components/delete-contract-dialog';
import { useToast } from '@/hooks/use-toast';
import { format, isPast, parseISO, addMonths, differenceInCalendarMonths, isValid, differenceInDays, intervalToDuration } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { ArrowRight, Home, Briefcase, Tag, Users, TrendingUp, Landmark, WalletCards, Percent, CalendarDays, FileText, Edit, Trash2, PlusCircle, UserPlus, ListChecks, Eye, Printer, FileSpreadsheet, Share2, FileTextIcon as ActualFileTextIcon, Phone, Mail, MapPin, Clock, Save, Minus, Plus, Square, X, User as UserIconLucide } from 'lucide-react';
import { RENT_TYPES, TAX_RATES, getLabelForValue, PROPERTY_STATUSES, getNumberOfInstallmentsLabel, NUMBER_OF_INSTALLMENTS_OPTIONS, RENT_PAYMENT_CYCLE_OPTIONS } from '@/lib/constants';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { TenantReportModal, DetailItem } from '@/components/tenant-report-modal';

export default function PropertyDetailsPage() {
  const params = useParams();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const propertyId = params.propertyId as string;
  const dataSource = searchParams.get('source') === 'deceased' ? 'deceased' : 'main';

  const {
    currentUser,
    properties, setProperties,
    tenants, setTenants,
    payments, setPayments,
    owners, setOwnerTransactions,
    deceasedProperties, setDeceasedProperties,
    deceasedTenants, setDeceasedTenants,
    deceasedPayments, setDeceasedPayments,
    deceasedInheritors, setDeceasedInheritorTransactions,
    bankTransactions, setBankTransactions
  } = useAppContext();

  const [currentProperty, setCurrentProperty] = useState<Property | null>(null);
  const [currentTenant, setCurrentTenant] = useState<Tenant | null>(null);
  const [currentPayments, setCurrentPayments] = useState<Payment[]>([]);

  const [isTenantInfoMinimized, setIsTenantInfoMinimized] = useState(false);

  useEffect(() => {
    let prop: Property | undefined;
    if (dataSource === 'main') {
      prop = properties.find(p => p.id === propertyId);
    } else {
      prop = deceasedProperties.find(p => p.id === propertyId);
    }
    setCurrentProperty(prop || null);

    if (prop) {
      const tenantList = dataSource === 'main' ? tenants : deceasedTenants;
      const activeTenantsForProperty = tenantList.filter(t => t.propertyId === propertyId && (t.contractEndDate ? !isPast(parseISO(t.contractEndDate)) : true));
      const sortedActiveTenants = activeTenantsForProperty.sort((a, b) => 
        new Date(b.contractStartDate).getTime() - new Date(a.contractStartDate).getTime()
      );
      const foundTenant = sortedActiveTenants[0] || null;
      
      setCurrentTenant(foundTenant);

      if (foundTenant) {
        const paymentList = dataSource === 'main' ? payments : deceasedPayments;
        setCurrentPayments(paymentList.filter(p => p.tenantId === foundTenant.tenantId));
      } else {
        setCurrentPayments([]);
      }
    } else {
      setCurrentTenant(null);
      setCurrentPayments([]);
    }
  }, [propertyId, dataSource, properties, deceasedProperties, tenants, deceasedTenants, payments, deceasedPayments]);

  const annualPreTaxRentForDisplay = useMemo(() => {
    if (!currentTenant) return 0;
    return currentTenant.contractValue;
  }, [currentTenant]);

  const monthlyPreTaxRentForDisplay = useMemo(() => {
    if (!currentTenant || currentTenant.rentType !== 'monthly') return 0;
    return currentTenant.contractValue / 12; 
  }, [currentTenant]);

  const totalWithTaxForDisplay = useMemo(() => {
    if (!currentTenant) return { label: "الإجمالي مع الضريبة", value: 0 };
    const annualContractVal = currentTenant.contractValue;
    const taxRateVal = currentTenant.taxRate;

    if (currentTenant.rentType === 'monthly') {
      const monthlyBase = annualContractVal / 12;
      return {
        label: "الإجمالي الشهري مع الضريبة",
        value: monthlyBase * (1 + taxRateVal / 100)
      };
    } else { 
      return {
        label: "الإجمالي السنوي مع الضريبة",
        value: annualContractVal * (1 + taxRateVal / 100)
      };
    }
  }, [currentTenant]);
  
  const totalPeriodValueForDisplay = useMemo(() => {
    if (!currentTenant || !currentTenant.contractStartDate || !currentTenant.contractEndDate) return 0;
    try {
      const startDate = parseISO(currentTenant.contractStartDate);
      const endDate = parseISO(currentTenant.contractEndDate);
      if (!isValid(startDate) || !isValid(endDate) || endDate < startDate) return 0;

      const duration = intervalToDuration({ start: startDate, end: endDate });
      const years = duration.years || 0;
      const months = duration.months || 0;
      const days = duration.days || 0;

      const annualPreTaxRentLocal = currentTenant.contractValue; 
      const taxRatePercentage = currentTenant.taxRate / 100;
      
      const valueForYears = annualPreTaxRentLocal * years;
      const valueForMonths = (annualPreTaxRentLocal / 12) * months;
      const valueForDays = (annualPreTaxRentLocal / 365.25) * days; 

      const totalPreTaxValueForExactPeriod = valueForYears + valueForMonths + valueForDays;
      return parseFloat(((totalPreTaxValueForExactPeriod) * (1 + taxRatePercentage)).toFixed(2));
    } catch (e) {
      console.error("Error calculating total period value for display:", e);
      return 0;
    }
  }, [currentTenant]);

  const contractDurationDisplay = useMemo(() => {
    if (!currentTenant || !currentTenant.contractStartDate || !currentTenant.contractEndDate) {
      return { years: 0, months: 0, days: 0 };
    }
    try {
      const startDate = parseISO(currentTenant.contractStartDate);
      const endDate = parseISO(currentTenant.contractEndDate);
      if (!isValid(startDate) || !isValid(endDate) || endDate < startDate) {
        return { years: 0, months: 0, days: 0 };
      }
      const duration = intervalToDuration({ start: startDate, end: endDate });
      return {
        years: duration.years || 0,
        months: duration.months || 0,
        days: duration.days || 0,
      };
    } catch (e) {
      console.error("Error calculating contract duration:", e);
      return { years: 0, months: 0, days: 0 };
    }
  }, [currentTenant?.contractStartDate, currentTenant?.contractEndDate]);


  const [isAddEditPaymentModalOpen, setIsAddEditPaymentModalOpen] = useState(false);
  const [currentEditingPayment, setCurrentEditingPayment] = useState<Payment | null>(null);
  const [isDeletePaymentDialogOpen, setIsDeletePaymentDialogOpen] = useState(false);
  const [paymentToDelete, setPaymentToDelete] = useState<Payment | null>(null);

  const [isAddEditContractModalOpen, setIsAddEditContractModalOpen] = useState(false);
  const [isDeleteContractDialogOpen, setIsDeleteContractDialogOpen] = useState(false);

  const [isTenantReportModalOpen, setIsTenantReportModalOpen] = useState(false);

  const canEdit = currentUser?.permissions?.canEdit ?? false;
  const canAdd = currentUser?.permissions?.canAdd ?? false;
  const canDelete = currentUser?.permissions?.canDelete ?? false;


  if (!currentProperty) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold mb-4">العقار غير موجود</h1>
        <p>لم يتم العثور على العقار المطلوب.</p>
        <Button onClick={() => router.back()} className="mt-4">
          <ArrowRight className="ms-2 h-4 w-4" />
          العودة
        </Button>
      </div>
    );
  }

  const openAddPaymentModal = () => {
    if (!canAdd) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية إضافة دفعات.", variant: "destructive"});
      return;
    }
    if (!currentTenant) {
      toast({ title: "خطأ", description: "لا يمكن إضافة دفعة بدون مستأجر حالي.", variant: "destructive"});
      return;
    }
    setCurrentEditingPayment(null);
    setIsAddEditPaymentModalOpen(true);
  };

  const openEditPaymentModal = (payment: Payment) => {
    if (!canEdit) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية تعديل الدفعات.", variant: "destructive"});
      return;
    }
    setCurrentEditingPayment(payment);
    setIsAddEditPaymentModalOpen(true);
  };

  const openDeletePaymentDialog = (payment: Payment) => {
     if (!canDelete) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف الدفعات.", variant: "destructive"});
      return;
    }
    setPaymentToDelete(payment);
    setIsDeletePaymentDialogOpen(true);
  };

  const closePaymentModals = () => {
    setIsAddEditPaymentModalOpen(false);
    setCurrentEditingPayment(null);
    setIsDeletePaymentDialogOpen(false);
    setPaymentToDelete(null);
  };

  const handleSavePayment = async (data: PaymentFormValues, paymentIdToUpdate?: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));

    let updatedTenantPayments: Payment[];
    let paymentJustProcessed: Payment | undefined;
    let amountPaidInThisActualTransaction = 0;

    const originalPaymentForCalculation = paymentIdToUpdate ? currentPayments.find(p => p.paymentId === paymentIdToUpdate) : null;
    const originalAmountPaidValue = originalPaymentForCalculation ? originalPaymentForCalculation.amountPaid : 0;

    const activeSetPayments = dataSource === 'main' ? setPayments : setDeceasedPayments;

    const modificationTimestamp = new Date().toISOString();
    const modifierUsername = currentUser?.username || 'system';


    if (paymentIdToUpdate) {
      updatedTenantPayments = currentPayments.map(p =>
        p.paymentId === paymentIdToUpdate
        ? { ...p, ...data, dueDate: format(data.dueDate, 'yyyy-MM-dd'), lastModifiedBy: modifierUsername, lastModifiedAt: modificationTimestamp }
        : p
      );
      paymentJustProcessed = updatedTenantPayments.find(p => p.paymentId === paymentIdToUpdate);
      if (paymentJustProcessed) {
        amountPaidInThisActualTransaction = paymentJustProcessed.amountPaid - originalAmountPaidValue;
      }
      toast({ title: "تم تعديل الدفعة", description: `تم تحديث بيانات الدفعة "${data.description}".` });
    } else {
      const newPayment: Payment = {
        paymentId: `pay_manual_${Date.now()}`,
        tenantId: currentTenant!.tenantId,
        ...data,
        dueDate: format(data.dueDate, 'yyyy-MM-dd'),
        paymentAttachments: [],
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
      };
      updatedTenantPayments = [...currentPayments, newPayment];
      paymentJustProcessed = newPayment;
      amountPaidInThisActualTransaction = newPayment.amountPaid;
      toast({ title: "تمت إضافة الدفعة", description: `تمت إضافة دفعة جديدة ببيان "${data.description}".` });
    }

    setCurrentPayments(updatedTenantPayments);
    activeSetPayments(prevAllPayments => {
        const otherPayments = prevAllPayments.filter(p => p.tenantId !== currentTenant?.tenantId);
        return [...otherPayments, ...updatedTenantPayments];
    });

    if (dataSource === 'main' && amountPaidInThisActualTransaction > 0) {
      if (owners.length > 0 && currentProperty && paymentJustProcessed) {
        const amountToDistribute = amountPaidInThisActualTransaction;
        const sharePerOwner = parseFloat((amountToDistribute / owners.length).toFixed(2));
        const currentDateStr = format(new Date(), 'yyyy-MM-dd');
        const propertyName = currentProperty.name;

        const newOwnerTransactions: OwnerTransaction[] = owners.map(owner => ({
          id: `owntrans_auto_${Date.now()}_${owner.id}_${paymentJustProcessed!.paymentId}_${Math.random().toString(36).slice(2, 7)}`,
          ownerId: owner.id,
          amount: sharePerOwner,
          description: `لكم من ايجار محل ${propertyName}`,
          date: currentDateStr,
          attachments: [],
          lastModifiedBy: modifierUsername,
          lastModifiedAt: modificationTimestamp,
        }));
        setOwnerTransactions(prevOwnerTransactions => [...prevOwnerTransactions, ...newOwnerTransactions]);
        toast({
          title: "تم توزيع دفعة للملاك",
          description: `تم توزيع مبلغ ${amountToDistribute.toLocaleString()} ريال على ${owners.length} مالك/ملاك.`,
        });
      }
    } else if (dataSource === 'deceased' && amountPaidInThisActualTransaction > 0) {
        if (deceasedInheritors.length > 0 && currentProperty && paymentJustProcessed) {
            const amountToDistributeOverall = amountPaidInThisActualTransaction;
            const currentDateStr = format(new Date(), 'yyyy-MM-dd');
            const propertyName = currentProperty.name;

            const newInheritorTransactionsToAdd: InheritorTransaction[] = [];
            let totalDistributedToInheritors = 0;

            deceasedInheritors.forEach(inheritor => {
                if (inheritor.sharePercentage && inheritor.sharePercentage > 0) {
                    const share = inheritor.sharePercentage / 100;
                    const amountForThisInheritor = parseFloat((amountToDistributeOverall * share).toFixed(2));

                    if(amountForThisInheritor > 0) {
                        newInheritorTransactionsToAdd.push({
                            id: `inh_trans_auto_${Date.now()}_${inheritor.id}_${paymentJustProcessed!.paymentId}_${Math.random().toString(36).slice(2,5)}`,
                            inheritorId: inheritor.id,
                            amount: amountForThisInheritor,
                            description: `حصة من إيجار عقار الورثة: ${propertyName}`,
                            date: currentDateStr,
                            attachments: [],
                            lastModifiedBy: modifierUsername,
                            lastModifiedAt: modificationTimestamp,
                        });
                        totalDistributedToInheritors += amountForThisInheritor;
                    }
                }
            });

            if (newInheritorTransactionsToAdd.length > 0) {
                 setDeceasedInheritorTransactions(prev => [...prev, ...newInheritorTransactionsToAdd]);
                 toast({
                    title: "تم توزيع دفعة للورثة",
                    description: `تم توزيع مبلغ ${totalDistributedToInheritors.toLocaleString()} ريال على ${newInheritorTransactionsToAdd.length} وريث/ورثة بناءً على نسبهم.`,
                });
            } else {
                 toast({
                    title: "تنبيه بشأن توزيع الإيجار",
                    description: `لم يتم توزيع الإيجار على الورثة. يرجى التأكد من تحديد نسب الإرث بشكل صحيح.`,
                    variant: "default"
                });
            }
        }
        if (currentProperty && paymentJustProcessed) {
            const newBankTransaction: BankTransaction = {
                id: `bank_trans_auto_pay_${Date.now()}_${paymentJustProcessed.paymentId}_${Math.random().toString(36).slice(2, 7)}`,
                date: paymentJustProcessed.dueDate, 
                description: `مدفوع من ايجار محل ${currentProperty.name}`,
                amountIncoming: amountPaidInThisActualTransaction,
                amountOutgoing: 0,
                attachments: [],
                lastModifiedBy: modifierUsername,
                lastModifiedAt: modificationTimestamp,
            };
            setBankTransactions(prev => [...prev, newBankTransaction]);
            toast({
                title: "تم تسجيل عملية بنكية",
                description: `تم تسجيل إيداع وارد بمبلغ ${amountPaidInThisActualTransaction.toLocaleString()} ريال من إيجار ${currentProperty.name}.`,
            });
        }
    }
    closePaymentModals();
  };

  const handleConfirmDeletePayment = async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    if (paymentToDelete) {
      const activeSetPayments = dataSource === 'main' ? setPayments : setDeceasedPayments;
      const updatedTenantPayments = currentPayments.filter(p => p.paymentId !== paymentToDelete.paymentId);
      setCurrentPayments(updatedTenantPayments);
      activeSetPayments(prevAllPayments => {
        const otherPayments = prevAllPayments.filter(p => p.tenantId !== currentTenant?.tenantId);
        return [...otherPayments, ...updatedTenantPayments];
      });
      toast({ title: "تم حذف الدفعة", description: `تم حذف الدفعة "${paymentToDelete.description}" بشكل دائم.`, variant: "destructive" });
    }
    closePaymentModals();
  };

  const handleAddAttachment = async (paymentId: string, file: File) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const newAttachment: Attachment = {
      name: file.name,
      url: `#mock-url-for-${file.name}`,
    };
    const activeSetPayments = dataSource === 'main' ? setPayments : setDeceasedPayments;
    const modificationTimestamp = new Date().toISOString();
    const modifierUsername = currentUser?.username || 'system';

    const updatedCurrentPayments = currentPayments.map(p => {
      if (p.paymentId === paymentId) {
        return {
          ...p,
          paymentAttachments: [...(p.paymentAttachments || []), newAttachment],
          lastModifiedBy: modifierUsername,
          lastModifiedAt: modificationTimestamp,
        };
      }
      return p;
    });
    setCurrentPayments(updatedCurrentPayments);

    activeSetPayments(prevAllPayments => {
      return prevAllPayments.map(p => {
        if (p.paymentId === paymentId) {
          return {
            ...p,
            paymentAttachments: [...(p.paymentAttachments || []), newAttachment],
            lastModifiedBy: modifierUsername,
            lastModifiedAt: modificationTimestamp,
          };
        }
        return p;
      });
    });
    toast({ title: "تم إرفاق الملف", description: `تم إرفاق "${file.name}" بنجاح.` });
  };

  const handleDeleteAttachment = async (paymentId: string, attachmentName: string) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const activeSetPayments = dataSource === 'main' ? setPayments : setDeceasedPayments;
    const modificationTimestamp = new Date().toISOString();
    const modifierUsername = currentUser?.username || 'system';

    const updatedCurrentPayments = currentPayments.map(p => {
        if (p.paymentId === paymentId) {
            return {
              ...p,
              paymentAttachments: p.paymentAttachments?.filter(att => att.name !== attachmentName) || [],
              lastModifiedBy: modifierUsername,
              lastModifiedAt: modificationTimestamp,
            };
        }
        return p;
    });
    setCurrentPayments(updatedCurrentPayments);

    activeSetPayments(prevAllPayments => {
        return prevAllPayments.map(p => {
            if (p.paymentId === paymentId) {
                return {
                  ...p,
                  paymentAttachments: p.paymentAttachments?.filter(att => att.name !== attachmentName) || [],
                  lastModifiedBy: modifierUsername,
                  lastModifiedAt: modificationTimestamp,
                };
            }
            return p;
        });
    });
     toast({ title: "تم حذف المرفق", description: `تم حذف المرفق "${attachmentName}".`, variant: "destructive" });
  };

  const openAddContractModal = () => {
    if (!canAdd) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية إضافة عقود.", variant: "destructive"});
      return;
    }
    setIsAddEditContractModalOpen(true);
  };

  const openEditContractModal = () => {
    if (!canEdit) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية تعديل العقود.", variant: "destructive"});
      return;
    }
    if (currentTenant) {
      setIsAddEditContractModalOpen(true);
    }
  };

  const openDeleteContractDialog = () => {
     if (!canDelete) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف العقود.", variant: "destructive"});
      return;
    }
    setIsDeleteContractDialogOpen(true);
  };

  const closeContractModals = () => {
    setIsAddEditContractModalOpen(false);
    setIsDeleteContractDialogOpen(false);
  };

  const generatePaymentsForTenant = (tenant: Tenant): Payment[] => {
    const { contractValue, taxRate, numberOfInstallments, contractStartDate, contractEndDate, tenantId, rentType } = tenant;
    
    if (!contractStartDate || !contractEndDate) return [];

    let initialStartDate: Date;
    let finalContractEndDate: Date;

    try {
        initialStartDate = parseISO(contractStartDate);
        finalContractEndDate = parseISO(contractEndDate);
        if (!isValid(initialStartDate) || !isValid(finalContractEndDate) || finalContractEndDate < initialStartDate) {
            console.error("Invalid contract dates for payment generation:", tenant);
            return [];
        }
    } catch (e) {
        console.error("Error parsing contract dates:", e);
        return [];
    }

    const newPayments: Payment[] = [];
    const modificationTimestamp = new Date().toISOString();
    const modifierUsername = currentUser?.username || 'system_auto_pay';

    if (rentType === 'monthly') {
        const monthlyBaseRent = tenant.contractValue / 12; 
        const monthlyRentWithTax = parseFloat((monthlyBaseRent * (1 + tenant.taxRate / 100)).toFixed(2));
        
        let currentPaymentDate = initialStartDate;
        let paymentIndex = 0;

        while (currentPaymentDate <= finalContractEndDate) {
            paymentIndex++;
            newPayments.push({
                paymentId: `pay_auto_${tenantId}_${Date.now()}_${paymentIndex}`,
                tenantId,
                dueDate: format(currentPaymentDate, 'yyyy-MM-dd'),
                amountDue: monthlyRentWithTax,
                amountPaid: 0,
                description: `دفعة شهرية لشهر ${format(currentPaymentDate, 'MMMM yyyy', { locale: arSA })}`,
                status: 'pending' as PaymentStatus,
                paymentAttachments: [],
                lastModifiedBy: modifierUsername,
                lastModifiedAt: modificationTimestamp,
            });
            currentPaymentDate = addMonths(currentPaymentDate, 1);
        }
        
        if (newPayments.length > 0) {
            const totalContractMonths = differenceInCalendarMonths(finalContractEndDate, initialStartDate) + 1;
            const expectedTotalContractValueWithTax = parseFloat((monthlyRentWithTax * totalContractMonths).toFixed(2));
            const sumOfGenerated = newPayments.reduce((sum, p) => sum + p.amountDue, 0);
            const difference = expectedTotalContractValueWithTax - sumOfGenerated;
            if (Math.abs(difference) > 0.001) { 
                 newPayments[newPayments.length - 1].amountDue = parseFloat((newPayments[newPayments.length - 1].amountDue + difference).toFixed(2));
            }
        }

    } else { // annual
        const annualRentWithTax = tenant.contractValue * (1 + tenant.taxRate / 100);
        const installmentsPerFullYear = tenant.numberOfInstallments; 
        const baseAmountPerInstallment = parseFloat((annualRentWithTax / installmentsPerFullYear).toFixed(2));
        const monthsPerCycle = 12 / installmentsPerFullYear;

        let currentProcessDate = initialStartDate;
        let overallPaymentIndex = 0;

        while(currentProcessDate <= finalContractEndDate) {
            overallPaymentIndex++;
            const currentContractYearNum = Math.floor(differenceInCalendarMonths(currentProcessDate, initialStartDate) / 12) + 1;
            const installmentNumInYear = (overallPaymentIndex -1) % installmentsPerFullYear + 1;
            
            newPayments.push({
                paymentId: `pay_auto_${tenantId}_${Date.now()}_${overallPaymentIndex}`,
                tenantId,
                dueDate: format(currentProcessDate, 'yyyy-MM-dd'),
                amountDue: baseAmountPerInstallment,
                amountPaid: 0,
                description: `الدفعة ${installmentNumInYear} من ${installmentsPerFullYear} (السنة ${currentContractYearNum})`,
                status: 'pending' as PaymentStatus,
                paymentAttachments: [],
                lastModifiedBy: modifierUsername,
                lastModifiedAt: modificationTimestamp,
            });
            currentProcessDate = addMonths(currentProcessDate, monthsPerCycle);
        }

        if (newPayments.length > 0) {
            const duration = intervalToDuration({ start: initialStartDate, end: finalContractEndDate });
            const years = duration.years || 0;
            const months = duration.months || 0;
            const days = duration.days || 0;
            const valueForYears = tenant.contractValue * years;
            const valueForMonths = (tenant.contractValue / 12) * months;
            const valueForDays = (tenant.contractValue / 365.25) * days;
            const totalPreTaxValueForExactPeriod = valueForYears + valueForMonths + valueForDays;
            const expectedTotalRevenueForContract = parseFloat(((totalPreTaxValueForExactPeriod) * (1 + tenant.taxRate / 100)).toFixed(2));
            
            let generatedTotal = newPayments.reduce((sum, p) => sum + p.amountDue, 0);
            
            const difference = expectedTotalRevenueForContract - generatedTotal;
            if (Math.abs(difference) > 0.001) { 
                 newPayments[newPayments.length - 1].amountDue = parseFloat((newPayments[newPayments.length - 1].amountDue + difference).toFixed(2));
            }
            if (newPayments.length > 1 && newPayments[newPayments.length-1].amountDue <=0) {
                 newPayments[newPayments.length-1].amountDue = 0.01; 
            } else if (newPayments.length === 1 && newPayments[0].amountDue <=0) {
                newPayments[0].amountDue = expectedTotalRevenueForContract > 0 ? expectedTotalRevenueForContract : 0.01;
            }
        }
    }
    return newPayments;
  };

  const handleSaveContract = async (data: ContractFormValues) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    let tenantForPayments: Tenant;
    const activeSetTenants = dataSource === 'main' ? setTenants : setDeceasedTenants;
    const activeSetProperties = dataSource === 'main' ? setProperties : setDeceasedProperties;
    const activeSetPayments = dataSource === 'main' ? setPayments : setDeceasedPayments;
    const activePaymentsList = dataSource === 'main' ? payments : deceasedPayments;
    const modificationTimestamp = new Date().toISOString();
    const modifierUsername = currentUser?.username || 'system';


    if (currentTenant) {
      const updatedTenant: Tenant = {
        ...currentTenant, ...data, contractIdentifier: data.contractIdentifier,
        tenantPhoneNumber: data.tenantPhoneNumber,
        tenantEmail: data.tenantEmail,
        tenantAddress: data.tenantAddress,
        contractStartDate: format(data.contractStartDate, 'yyyy-MM-dd'),
        contractEndDate: format(data.contractEndDate, 'yyyy-MM-dd'),
        numberOfInstallments: data.numberOfInstallments,
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
      };
      activeSetTenants(prev => prev.map(t => t.tenantId === currentTenant.tenantId ? updatedTenant : t));
      setCurrentTenant(updatedTenant);
      tenantForPayments = updatedTenant;
      toast({ title: "تم تحديث العقد", description: `تم تحديث بيانات عقد المستأجر ${data.tenantName}. تم إعادة إنشاء جدول الدفعات.` });
    } else {
      const newTenantId = `tenant_${dataSource}_${Date.now()}`;
      const newTenant: Tenant = {
        tenantId: newTenantId, contractIdentifier: data.contractIdentifier,
        propertyId: currentProperty.id, ...data,
        tenantPhoneNumber: data.tenantPhoneNumber,
        tenantEmail: data.tenantEmail,
        tenantAddress: data.tenantAddress,
        contractStartDate: format(data.contractStartDate, 'yyyy-MM-dd'),
        contractEndDate: format(data.contractEndDate, 'yyyy-MM-dd'),
        numberOfInstallments: data.numberOfInstallments, contractAttachments: [],
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
      };
      activeSetTenants(prev => [...prev, newTenant]);
      setCurrentTenant(newTenant);
      tenantForPayments = newTenant;
      activeSetProperties(prevProps => prevProps.map(p => p.id === currentProperty.id ? {...p, status: 'rented' as PropertyStatus, lastModifiedBy: modifierUsername, lastModifiedAt: modificationTimestamp} : p));
      toast({ title: "تم إضافة العقد", description: `تم إضافة عقد جديد للمستأجر ${data.tenantName}. تم إنشاء جدول الدفعات.` });
    }

    const remainingOldPayments = activePaymentsList.filter(p => p.tenantId !== tenantForPayments.tenantId);
    const newGeneratedPayments = generatePaymentsForTenant(tenantForPayments);
    activeSetPayments([...remainingOldPayments, ...newGeneratedPayments]);

    closeContractModals();
  };

  const handleConfirmDeleteContract = async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
    if (currentTenant) {
      const tenantName = currentTenant.tenantName;
      const tenantIdToDelete = currentTenant.tenantId;
      const activeSetTenants = dataSource === 'main' ? setTenants : setDeceasedTenants;
      const activeSetProperties = dataSource === 'main' ? setProperties : setDeceasedProperties;
      const activeSetPayments = dataSource === 'main' ? setPayments : setDeceasedPayments;
      const modificationTimestamp = new Date().toISOString();
      const modifierUsername = currentUser?.username || 'system';

      activeSetTenants(prev => prev.filter(t => t.tenantId !== tenantIdToDelete));
      activeSetPayments(prev => prev.filter(p => p.tenantId !== tenantIdToDelete));
      activeSetProperties(prevProps => prevProps.map(p => p.id === currentProperty.id ? {...p, status: 'vacant' as PropertyStatus, lastModifiedBy: modifierUsername, lastModifiedAt: modificationTimestamp} : p));

      setCurrentTenant(null);
      toast({ title: "تم حذف العقد", description: `تم حذف عقد المستأجر ${tenantName} وجميع دفعاته المرتبطة بشكل دائم.`, variant: "destructive" });
    }
    closeContractModals();
  };

  const getContractStatus = (): { label: string; variant: "default" | "secondary" | "destructive" | "outline" } => {
    if (currentTenant) {
      if (currentTenant.contractEndDate && isValid(parseISO(currentTenant.contractEndDate)) && isPast(parseISO(currentTenant.contractEndDate))) return { label: 'مغادر', variant: 'secondary' };
      return { label: 'نشط', variant: 'default' };
    }
    return { label: 'غير متوفر', variant: 'outline' };
  };
  const contractStatus = getContractStatus();

  const handlePlaceholderAction = (actionName: string) => {
    if ((actionName === 'معاينة العقد' || actionName === 'طباعة العقد') && currentTenant && currentProperty) {
        setIsTenantReportModalOpen(true);
    } else {
        toast({ title: "إجراء غير متوفر", description: `ميزة "${actionName}" غير متوفرة حاليًا.`, variant: "default" });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="mb-6 shadow-lg">
        <CardHeader className="flex flex-row justify-between items-center">
          <div>
            <CardTitle className="text-lg font-semibold flex items-center">
              {currentProperty.type === 'commercial' ? <Briefcase className="me-3 h-7 w-7" /> : <Home className="me-3 h-7 w-7" />}
              {currentProperty.name}
            </CardTitle>
            <CardDescription className="text-sm font-semibold">{currentProperty.address}</CardDescription>
            {dataSource === 'deceased' && <Badge variant="outline" className="mt-2 border-orange-500 text-orange-600">عقار من سجلات الورثة</Badge>}
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={() => router.back()}>
              <ArrowRight className="ms-2 h-4 w-4" />
              العودة
            </Button>
          </div>
        </CardHeader>
      </Card>

      {currentTenant ? (
        <ScrollArea className="h-[calc(100vh-280px)]">
          <div className="space-y-6 pb-6">
            <Card className="shadow-md">
              <CardHeader className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="flex items-center gap-2">
                    <Users className="me-2 h-5 w-5 text-primary" />
                    <CardTitle className="text-lg">{'بيانات المستأجر والعقد'}</CardTitle>
                </div>
                <div className="flex items-center gap-2 ms-auto">
                     <TooltipProvider>
                        <Tooltip>
                        <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" onClick={() => setIsTenantInfoMinimized(!isTenantInfoMinimized)} className="text-muted-foreground hover:text-foreground">
                            {isTenantInfoMinimized ? <Plus className="h-4 w-4" /> : <Minus className="h-4 w-4" />}
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>{isTenantInfoMinimized ? 'تكبير' : 'تصغير'}</p></TooltipContent>
                        </Tooltip>
                        <Tooltip>
                        <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                            <Square className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>{'تكبير (غير مفعل)'}</p></TooltipContent>
                        </Tooltip>
                        <Tooltip>
                        <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" onClick={() => router.back()} className="text-muted-foreground hover:text-destructive">
                            <X className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>{'إغلاق (عودة)'}</p></TooltipContent>
                        </Tooltip>
                    </TooltipProvider>
                </div>
                <div className="flex flex-wrap gap-2 items-center">
                    <TooltipProvider>
                        <div className="flex flex-wrap gap-2">
                        <Tooltip><TooltipTrigger asChild><Button variant="outline" size="icon" onClick={() => handlePlaceholderAction('معاينة العقد')}><Eye className="h-4 w-4" /></Button></TooltipTrigger><TooltipContent><p>{'معاينة العقد/التقرير'}</p></TooltipContent></Tooltip>
                        <Tooltip><TooltipTrigger asChild><Button variant="outline" size="icon" onClick={() => handlePlaceholderAction('طباعة العقد')}><Printer className="h-4 w-4" /></Button></TooltipTrigger><TooltipContent><p>{'طباعة العقد/التقرير'}</p></TooltipContent></Tooltip>
                        <Tooltip><TooltipTrigger asChild><Button variant="outline" size="icon" onClick={() => handlePlaceholderAction('تحويل إلى PDF')}><FileText className="h-4 w-4" /></Button></TooltipTrigger><TooltipContent><p>{'تحويل إلى PDF'}</p></TooltipContent></Tooltip>
                        <Tooltip><TooltipTrigger asChild><Button variant="outline" size="icon" onClick={() => handlePlaceholderAction('تحويل إلى Excel')}><FileSpreadsheet className="h-4 w-4" /></Button></TooltipTrigger><TooltipContent><p>{'تحويل إلى Excel'}</p></TooltipContent></Tooltip>
                        <Tooltip><TooltipTrigger asChild><Button variant="outline" size="icon" onClick={() => handlePlaceholderAction('مشاركة العقد')}><Share2 className="h-4 w-4" /></Button></TooltipTrigger><TooltipContent><p>{'مشاركة العقد'}</p></TooltipContent></Tooltip>
                        </div>
                    </TooltipProvider>
                    <Button variant="outline" size="sm" onClick={openEditContractModal} disabled={!canEdit}><Edit className="me-2 h-4 w-4" /> {'تعديل العقد'}</Button>
                    <Button variant="destructive" size="sm" onClick={openDeleteContractDialog} disabled={!canDelete}>
                        <Trash2 className="me-2 h-4 w-4" /> {'حذف العقد'}
                    </Button>
                </div>
              </CardHeader>
              {!isTenantInfoMinimized && (
                <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-0 pt-4">
                  <DetailItem icon={Tag} label={"رقم العقد (المعرف)"} value={currentTenant.contractIdentifier} />
                  <DetailItem icon={Users} label={"اسم المستأجر"} value={currentTenant.tenantName} />
                  {currentTenant.tenantPhoneNumber && <DetailItem icon={Phone} label={"رقم هاتف المستأجر"} value={currentTenant.tenantPhoneNumber} />}
                  {currentTenant.tenantEmail && <DetailItem icon={Mail} label={"البريد الإلكتروني للمستأجر"} value={currentTenant.tenantEmail} />}
                  {currentTenant.tenantAddress && <DetailItem icon={MapPin} label={"عنوان المستأجر"} value={currentTenant.tenantAddress} className="lg:col-span-3 md:col-span-2" />}
                  
                  <DetailItem icon={CalendarDays} label={"تاريخ بداية العقد"} value={currentTenant.contractStartDate ? format(parseISO(currentTenant.contractStartDate), 'yyyy/MM/dd', { locale: arSA }) : '-'} />
                  <DetailItem icon={CalendarDays} label={"تاريخ نهاية العقد"} value={currentTenant.contractEndDate ? format(parseISO(currentTenant.contractEndDate), 'yyyy/MM/dd', { locale: arSA }) : '-'} />
                  
                  <DetailItem icon={CalendarDays} label="عدد سنوات العقد" value={`${contractDurationDisplay.years} سنة`} />
                  <DetailItem icon={CalendarDays} label="عدد أشهر العقد" value={`${contractDurationDisplay.months} شهر`} />
                  <DetailItem icon={CalendarDays} label="عدد أيام العقد" value={`${contractDurationDisplay.days} يوم`} />

                  <DetailItem icon={WalletCards} label={"قيمة العقد السنوية (قبل الضريبة)"} value={`${annualPreTaxRentForDisplay.toLocaleString()} ريال`} />
                  {currentTenant.rentType === 'monthly' && (
                        <DetailItem 
                            icon={WalletCards} 
                            label="القيمة الشهرية (محسوبة, قبل الضريبة)" 
                            value={`${monthlyPreTaxRentForDisplay.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ريال`} 
                        />
                    )}
                  <DetailItem icon={Percent} label={"نسبة الضريبة"} value={getLabelForValue(TAX_RATES, currentTenant.taxRate as TaxRate)} />
                  <DetailItem 
                    icon={TrendingUp} 
                    label={totalWithTaxForDisplay.label}
                    value={`${totalWithTaxForDisplay.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ريال`} 
                  />
                  <DetailItem 
                    icon={TrendingUp} 
                    label="اجمالي الفتره (مع الضريبة)" 
                    value={`${totalPeriodValueForDisplay.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ريال`} 
                  />
                  <DetailItem icon={Landmark} label={"نوع الإيجار"} value={getLabelForValue(RENT_TYPES, currentTenant.rentType as RentType)} />
                  <DetailItem icon={ListChecks} label={"دورة سداد الايجار"} value={getNumberOfInstallmentsLabel(currentTenant.numberOfInstallments)} />
                  <DetailItem icon={ActualFileTextIcon} label={"حالة العقد"} value={<Badge variant={contractStatus.variant} className={contractStatus.variant === 'default' ? 'bg-green-500 hover:bg-green-600' : ''}>{contractStatus.label}</Badge>} />
                   {currentTenant.lastModifiedBy && (
                     <DetailItem icon={UserIconLucide} label={"آخر تعديل للعقد بواسطة"} value={currentTenant.lastModifiedBy} />
                   )}
                   {currentTenant.lastModifiedAt && (
                     <DetailItem icon={Clock} label={"وقت آخر تعديل للعقد"} value={formatTimestampForReport(currentTenant.lastModifiedAt)} />
                   )}
                  {currentTenant.contractAttachments && currentTenant.contractAttachments.length > 0 && (
                    <div className="lg:col-span-3">
                       <DetailItem icon={ActualFileTextIcon} label={"مرفقات العقد"} value={
                            <ul className="list-none p-0 m-0">
                              {currentTenant.contractAttachments.map(att => (
                                <li key={att.name} className="mt-1">
                                  <Button variant="link" asChild className="p-0 h-auto">
                                    <a href={att.url} target="_blank" rel="noopener noreferrer" className="flex items-center text-primary hover:underline">
                                      <FileText className="h-4 w-4 me-1" /> {att.name}
                                    </a>
                                  </Button>
                                </li>
                              ))}
                            </ul>
                          }
                        />
                    </div>
                  )}
                </CardContent>
              )}
            </Card>

            <PaymentHistoryTable
              payments={currentPayments}
              onAddPayment={openAddPaymentModal}
              onEditPayment={openEditPaymentModal}
              onDeletePayment={openDeletePaymentDialog}
              onAddAttachment={handleAddAttachment}
              onDeleteAttachment={handleDeleteAttachment}
              canEdit={canEdit}
              canDelete={canDelete}
            />
          </div>
        </ScrollArea>
      ) : (
        <Card className="shadow-md">
          <CardContent className="py-12 text-center">
            <Home className="mx-auto h-16 w-16 text-muted-foreground mb-4" />
            <p className="text-xl text-muted-foreground">هذا العقار شاغر حاليًا.</p>
            <p className="text-sm font-semibold text-muted-foreground">لا توجد بيانات مستأجر أو دفعات لعرضها.</p>
            <Button size="lg" className="mt-6" onClick={openAddContractModal} disabled={!canAdd}>
              <UserPlus className="me-2 h-5 w-5" />
              إضافة عقد جديد
            </Button>
          </CardContent>
        </Card>
      )}

      <AddEditContractModal
        isOpen={isAddEditContractModalOpen}
        onClose={closeContractModals}
        onSubmit={handleSaveContract}
        initialData={currentTenant}
        propertyId={currentProperty.id}
      />

      <DeleteContractDialog
        isOpen={isDeleteContractDialogOpen}
        onClose={closeContractModals}
        onConfirm={handleConfirmDeleteContract}
        tenantName={currentTenant?.tenantName}
      />

      {currentTenant && (
        <AddEditPaymentModal
          isOpen={isAddEditPaymentModalOpen}
          onClose={closePaymentModals}
          onSubmit={handleSavePayment}
          initialData={currentEditingPayment}
          tenantId={currentTenant.tenantId}
        />
      )}

      <DeletePaymentDialog
        isOpen={isDeletePaymentDialogOpen}
        onClose={closePaymentModals}
        onConfirm={handleConfirmDeletePayment}
        paymentDescription={paymentToDelete?.description}
      />
      {currentTenant && currentProperty && (
        <TenantReportModal
            isOpen={isTenantReportModalOpen}
            onClose={() => setIsTenantReportModalOpen(false)}
            tenant={currentTenant}
            property={currentProperty}
            payments={currentPayments}
        />
      )}
    </div>
  );
}

const formatTimestampForReport = (isoString?: string) => {
  if (!isoString) return '-';
  try {
    return format(parseISO(isoString), 'yyyy/MM/dd HH:mm', { locale: arSA });
  } catch (e) {
    return 'تاريخ خاطئ';
  }
};

    
