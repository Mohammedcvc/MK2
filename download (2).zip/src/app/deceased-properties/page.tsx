
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

// This page will now primarily serve as a redirector to the main page with the correct view query parameter.
export default function DeceasedPropertiesPage() {
  const router = useRouter();

  useEffect(() => {
    router.replace('/?view=deceased');
  }, [router]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)]">
      <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
      <p className="text-lg text-muted-foreground">يتم التوجيه إلى صفحة عقارات الورثة...</p>
    </div>
  );
}
