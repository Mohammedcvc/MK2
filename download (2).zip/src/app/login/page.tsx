
'use client';

import { LoginForm } from '@/components/login-form';
import { useAppContext } from '@/contexts/app-context';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect } from 'react';
import { Loader2 } from 'lucide-react';

export default function LoginPage() {
  const { currentUser, isContextLoading } = useAppContext();
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    if (!isContextLoading && currentUser) {
      const redirectUrl = searchParams.get('redirect') || '/';
      router.replace(redirectUrl); // Redirect if already logged in and context is loaded
    }
  }, [currentUser, isContextLoading, router, searchParams]);

  if (isContextLoading || (!isContextLoading && currentUser) ) {
    // Show loader if context is loading OR if user is logged in and we are about to redirect
    return (
      <div className="flex flex-col items-center justify-center min-h-[calc(100vh-200px)]">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p className="text-lg text-muted-foreground">جاري التحميل...</p>
      </div>
    );
  }

  // If context is loaded and no current user, show login form
  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-200px)] bg-gradient-to-br from-background to-muted/30 p-4">
      <LoginForm />
    </div>
  );
}

