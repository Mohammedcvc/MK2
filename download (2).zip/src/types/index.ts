
export type PropertyStatus = 'vacant' | 'rented' | 'maintenance';
export type RentType = 'annual' | 'monthly';
export type PaymentStatus = 'paid' | 'pending' | 'overdue' | 'due';
export type TaxRate = 0 | 5 | 10 | 15;
export type PropertyType = 'commercial' | 'residential';
export type NumberOfInstallments = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30;
export type InheritorOperationType = 'cashWithdrawal' | 'bankTransfer' | 'commissionExpense';
export type SmartPropertyActiveView = 'dashboard' | 'propertyManagement' | 'expenses' | 'owners' | 'contractStatusReport' | 'overdueAndDuePaymentsReport' | 'userManagement' | 'accountStatementReport' | 'taxReport' | 'profitAndLossReport' | 'smartConsolidatedReport' | 'chartsReport';
export type DeceasedPropertyActiveView = 'deceased-dashboard' | 'deceased-properties-management' | 'inheritors-shares' | 'deceased-expenses' | 'bank-balances-cash' | 'inheritor-balances-report' | 'deceased-expenses-report' | 'deceased-rent-summary-report' | 'deceased-contract-status-report' | 'deceased-overdue-and-due-payments-report' | 'deceasedAccountStatementReport' | 'taxReport' | 'profitAndLossReport' | 'chartsReport';


export interface Attachment {
  name: string;
  url: string;
  type?: string; // Optional: MIME type
  size?: number; // Optional: file size in bytes
}

export interface Property {
  id: string;
  name: string;
  status: PropertyStatus;
  address: string;
  type: PropertyType;
  imageUrl?: string; // Optional image URL for the property
  ownerId?: string; // Link to Owner
  lastModifiedBy?: string;
  lastModifiedAt?: string;
}

export interface Tenant {
  tenantId: string; // رقم المستأجر - System ID
  contractIdentifier: string; // رقم العقد - User-defined contract number
  tenantName: string; // اسم المستاجر
  propertyId: string; // To link tenant to a property
  contractStartDate: string; // تاريخ بداية العقد (ISO string)
  contractEndDate: string; // تاريخ نهاية العقد (ISO string)
  contractValue: number; // قيمة العقد السنوية (قبل الضريبة)
  rentType: RentType; // نوع الايجار
  taxRate: TaxRate; // الضريبة
  numberOfInstallments: NumberOfInstallments; // عدد الدفعات
  contractAttachments?: Attachment[]; // مرفقات العقد
  tenantPhoneNumber?: string; // رقم هاتف المستأجر
  tenantEmail?: string; // البريد الإلكتروني للمستأجر
  tenantAddress?: string; // عنوان المستأجر الشخصي
  lastModifiedBy?: string;
  lastModifiedAt?: string;
}

export interface Payment {
  paymentId: string; // رقم الدفعه
  tenantId: string;
  dueDate: string; // تاريخ إستحقاق الدفعه (ISO string)
  amountDue: number; // مبلغ الدفعه
  amountPaid: number; // المدفوع
  description: string; // بيان الدفعه
  status: PaymentStatus; // حالة الدفعه
  paymentAttachments?: Attachment[]; // مرفقات الدفعه
  lastModifiedBy?: string; // Username of the last modifier
  lastModifiedAt?: string; // ISO timestamp of the last modification
}

// Helper to calculate balance
export const getPaymentBalance = (payment: Payment): number => payment.amountDue - payment.amountPaid;

export interface Expense {
  id: string;
  name: string; // اسم المصروف
  amount: number; // مبلغ المصروف
  date: string; // تاريخ المصروف (ISO string)
  description: string; // بيان المصروف
  attachments?: Attachment[]; // مرفقات المصروف
  lastModifiedBy?: string;
  lastModifiedAt?: string;
}

export interface Owner {
  id: string;
  name: string;
  lastModifiedBy?: string; // For owner profile changes, if any.
  lastModifiedAt?: string;
}

export interface OwnerTransaction {
  id: string;
  ownerId: string;
  amount: number;
  description: string;
  date: string; // ISO string
  attachments?: Attachment[];
  lastModifiedBy?: string;
  lastModifiedAt?: string;
}

// Types for Deceased Properties section
export interface Inheritor {
  id: string;
  name: string;
  sharePercentage?: number; // Optional: share percentage for the inheritor
  lastModifiedBy?: string;
  lastModifiedAt?: string;
}

export interface InheritorTransaction {
  id: string;
  inheritorId: string;
  amount: number;
  description: string;
  date: string; // ISO string
  operationType?: InheritorOperationType; // نوع العملية
  attachments?: Attachment[];
  lastModifiedBy?: string;
  lastModifiedAt?: string;
}

export interface BankTransaction {
  id: string; // رقم العمليه - auto-generated
  date: string; // تاريخ العمليه (ISO string)
  description: string; // البيان
  amountIncoming?: number; // مبلغ العمليه الوارده
  amountOutgoing?: number; // مبلغ العملية الصادرة
  attachments?: Attachment[]; // مرفقات العملية
  lastModifiedBy?: string;
  lastModifiedAt?: string;
}

export interface UserPermissions {
  canDelete: boolean;
  canEdit: boolean;
  canAdd: boolean;
  canPrint: boolean;
}

export interface User {
  id: string;
  username: string;
  password?: string; // Password should be securely hashed in a real app
  roles: string[];
  permissions: UserPermissions;
  lastModifiedBy?: string;
  lastModifiedAt?: string;
}

// Form values for adding/editing users
export interface UserFormValues {
  username: string;
  password?: string;
  roles: string[];
}
