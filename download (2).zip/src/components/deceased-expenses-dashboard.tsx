
'use client';

import type { Expense, Attachment, Inheritor, InheritorTransaction, BankTransaction } from '@/types';
import { useAppContext } from '@/contexts/app-context';
import { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { ExpensesTable } from '@/components/expenses-table';
import { AddEditExpenseModal, ExpenseFormValues as ModalExpenseFormValues } from '@/components/add-edit-expense-modal';
import { DeleteExpenseDialog } from '@/components/delete-expense-dialog';
import { useToast } from '@/hooks/use-toast';
import { PlusCircle, Sigma, FileText, CalendarIcon as CalendarIconLucide, Loader2, Clock, User } from 'lucide-react';
import { format, parse, parseISO, isValid as isValidDate, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { ExpenseReportModal } from '@/components/expense-report-modal';
import { useForm, SubmitHandler } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { cn } from '@/lib/utils';

const expenseFormSchema = z.object({
  name: z.string().min(3, { message: 'اسم المصروف يجب أن لا يقل عن 3 أحرف.' }),
  amount: z.coerce.number().positive({ message: 'مبلغ المصروف يجب أن يكون رقمًا موجبًا.' }),
  date: z.date({ required_error: 'تاريخ المصروف مطلوب.' }),
  description: z.string().min(1, { message: 'وصف المصروف مطلوب.' }),
});

export type InlineExpenseFormValues = z.infer<typeof expenseFormSchema>;


export function DeceasedExpensesDashboard() {
  const {
    currentUser,
    deceasedExpenses, setDeceasedExpenses,
    deceasedInheritors, setDeceasedInheritorTransactions,
    setBankTransactions
  } = useAppContext();
  const { toast } = useToast();

  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [isDeleteDialogVisible, setIsDeleteDialogVisible] = useState(false);
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);
  const [isExpenseReportModalOpen, setIsExpenseReportModalOpen] = useState(false);
  const [isAddExpenseAccordionOpen, setIsAddExpenseAccordionOpen] = useState(false);
  const [isSubmittingInlineForm, setIsSubmittingInlineForm] = useState(false);
  const [isInlineCalendarOpen, setIsInlineCalendarOpen] = useState(false);


  const canEditExpenses = currentUser?.permissions?.canEdit ?? false;
  const canAddExpenses = currentUser?.permissions?.canAdd ?? false;
  const canDeleteExpenses = currentUser?.permissions?.canDelete ?? false;

  const inlineExpenseForm = useForm<InlineExpenseFormValues>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      name: '',
      amount: 0,
      date: new Date(),
      description: '',
    },
  });

  const openAddExpenseModal = () => {
    if (!canAddExpenses) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية إضافة مصروفات.", variant: "destructive"});
      return;
    }
    setEditingExpense(null);
    setIsAddEditModalOpen(true);
  };

  const openEditExpenseModal = (expense: Expense) => {
    if (!canEditExpenses) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية تعديل المصروفات.", variant: "destructive"});
      return;
    }
    setEditingExpense(expense);
    setIsAddEditModalOpen(true);
  };

  const openDeleteExpenseDialog = (expense: Expense) => {
    if (!canDeleteExpenses) {
        toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف مصروفات الورثة.", variant: "destructive"});
        return;
    }
    setExpenseToDelete(expense);
    setIsDeleteDialogVisible(true);
  };

  const closeModals = () => {
    setIsAddEditModalOpen(false);
    setEditingExpense(null);
    setIsDeleteDialogVisible(false);
    setExpenseToDelete(null);
    setIsExpenseReportModalOpen(false);
  };

  const createBankTransactionForExpense = (expense: Expense) => {
    const modifierUsername = currentUser?.username || 'system_bank_trans_expense';
    const modificationTimestamp = new Date().toISOString();
    const newBankTransaction: BankTransaction = {
      id: `bank_trans_exp_${Date.now()}_${expense.id}_${Math.random().toString(36).slice(2, 7)}`,
      date: expense.date,
      description: `مصروف ورثة: ${expense.description || expense.name}`,
      amountIncoming: 0,
      amountOutgoing: expense.amount,
      attachments: [],
      lastModifiedBy: modifierUsername,
      lastModifiedAt: modificationTimestamp,
    };
    setBankTransactions(prev => [...prev, newBankTransaction]);
    toast({
      title: "تم تسجيل عملية بنكية للمصروف",
      description: `تم تسجيل عملية صرف بمبلغ ${expense.amount.toLocaleString()} ريال للمصروف "${expense.description || expense.name}".`,
    });
  };

  const distributeExpenseToInheritorsHelper = (
    expense: Pick<Expense, 'id' | 'amount' | 'date' | 'description' | 'name'>,
  ) => {
    if (deceasedInheritors.length > 0 && expense.amount > 0) {
        const newInheritorTransactionsToAdd: InheritorTransaction[] = [];
        let totalDistributedToInheritors = 0;
        const modifierUsername = currentUser?.username || 'system_inheritor_distro';
        const modificationTimestamp = new Date().toISOString();

        deceasedInheritors.forEach(inheritor => {
            if (inheritor.sharePercentage && inheritor.sharePercentage > 0) {
                const share = inheritor.sharePercentage / 100;
                const amountForThisInheritor = parseFloat((expense.amount * share).toFixed(2));

                if (amountForThisInheritor > 0) {
                    newInheritorTransactionsToAdd.push({
                        id: `inh_trans_exp_${Date.now()}_${inheritor.id}_${expense.id}_${Math.random().toString(36).slice(2, 7)}`,
                        inheritorId: inheritor.id,
                        amount: -amountForThisInheritor,
                        description: `خصم من رصيدكم (مصروف ورثة): ${expense.description || expense.name}`,
                        date: expense.date,
                        attachments: [],
                        lastModifiedBy: modifierUsername,
                        lastModifiedAt: modificationTimestamp,
                    });
                    totalDistributedToInheritors += amountForThisInheritor;
                }
            }
        });

        if (newInheritorTransactionsToAdd.length > 0) {
            setDeceasedInheritorTransactions(prev => [...prev, ...newInheritorTransactionsToAdd]);
            toast({
                title: "تم توزيع مصروف الورثة على الورثة",
                description: `تم توزيع مصروف "${expense.description || expense.name}" (${expense.amount.toLocaleString()} ريال) على ${newInheritorTransactionsToAdd.length} وريث/ورثة حسب نسبهم. إجمالي الموزع: ${totalDistributedToInheritors.toLocaleString()} ريال.`,
            });
        } else if (expense.amount > 0) {
             toast({
                title: "تنبيه بشأن توزيع مصروف الورثة",
                description: `تم تسجيل المصروف "${expense.description || expense.name}"، ولكن لم يتم توزيعه على الورثة لعدم وجود نسب محددة أو صحيحة.`,
                variant: "default"
            });
        }

    } else if (deceasedInheritors.length === 0 && expense.amount > 0) {
        toast({
            title: "تنبيه بشأن توزيع مصروف الورثة",
            description: `تم تسجيل المصروف "${expense.description || expense.name}"، ولكن لا يوجد ورثة مسجلين لتوزيع التكلفة عليهم.`,
            variant: "default"
        });
    }
  };

  const handleSaveExpense = async (data: ModalExpenseFormValues, expenseIdToUpdate?: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    let expenseProcessed: Expense;
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();

    if (expenseIdToUpdate) {
      const originalExpense = deceasedExpenses.find(exp => exp.id === expenseIdToUpdate);
      const updatedExpenseFull: Expense = {
          ...(originalExpense || {} as Expense),
          ...data,
          id: expenseIdToUpdate,
          date: format(data.date, 'yyyy-MM-dd'),
          lastModifiedBy: modifierUsername,
          lastModifiedAt: modificationTimestamp,
      };
      expenseProcessed = updatedExpenseFull;
      setDeceasedExpenses(prevExpenses =>
        prevExpenses.map(exp =>
          exp.id === expenseIdToUpdate
          ? updatedExpenseFull
          : exp
        )
      );
      toast({ title: "تم تعديل مصروف الورثة", description: `تم تحديث بيانات المصروف "${data.name}".` });
    } else {
      const newExpense: Expense = {
        id: `d_exp_${Date.now()}_${Math.random().toString(36).substring(2,7)}`,
        ...data,
        date: format(data.date, 'yyyy-MM-dd'),
        attachments: [],
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
      };
      expenseProcessed = newExpense;
      setDeceasedExpenses(prevExpenses => [...prevExpenses, newExpense]);
      toast({ title: "تمت إضافة مصروف للورثة", description: `تمت إضافة مصروف جديد باسم "${data.name}".` });
    }

    distributeExpenseToInheritorsHelper(expenseProcessed);
    createBankTransactionForExpense(expenseProcessed);

    closeModals();
    return expenseProcessed;
  };

  const handleInlineAddExpenseSubmit: SubmitHandler<InlineExpenseFormValues> = async (data) => {
    if (!canAddExpenses) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية إضافة مصروفات.", variant: "destructive"});
      return;
    }
    setIsSubmittingInlineForm(true);
    await handleSaveExpense(data, undefined);
    setIsSubmittingInlineForm(false);
    inlineExpenseForm.reset({ name: '', amount: 0, date: new Date(), description: '' });
    setIsAddExpenseAccordionOpen(false);
  };


  const handleConfirmDeleteExpense = async () => {
    if (!canDeleteExpenses) {
        toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف مصروفات الورثة.", variant: "destructive"});
        closeModals();
        return;
    }
    await new Promise(resolve => setTimeout(resolve, 500));
    if (expenseToDelete) {
      setDeceasedExpenses(prevExpenses => prevExpenses.filter(exp => exp.id !== expenseToDelete.id));
      toast({ title: "تم حذف مصروف الورثة", description: `تم حذف المصروف "${expenseToDelete.name}" بشكل دائم. (لم يتم عكس توزيعات الورثة أو العمليات البنكية السابقة لهذا المصروف)`, variant: "destructive" });
    }
    closeModals();
  };

  const handleAddAttachment = async (expenseId: string, file: File) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const newAttachment: Attachment = {
      name: file.name,
      url: `#mock-url-for-${file.name}`,
    };
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();

    setDeceasedExpenses(prevExpenses =>
      prevExpenses.map(exp => {
        if (exp.id === expenseId) {
          return {
            ...exp,
            attachments: [...(exp.attachments || []), newAttachment],
            lastModifiedBy: modifierUsername,
            lastModifiedAt: modificationTimestamp,
          };
        }
        return exp;
      })
    );
    toast({ title: "تم إرفاق الملف لمصروف الورثة", description: `تم إرفاق "${file.name}" بنجاح.` });
  };

  const handleDeleteAttachment = async (expenseId: string, attachmentName: string) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();
    setDeceasedExpenses(prevExpenses =>
      prevExpenses.map(exp => {
          if (exp.id === expenseId) {
              return {
                  ...exp,
                  attachments: exp.attachments?.filter(att => att.name !== attachmentName) || [],
                  lastModifiedBy: modifierUsername,
                  lastModifiedAt: modificationTimestamp,
              };
          }
          return exp;
      })
    );
     toast({ title: "تم حذف المرفق من مصروف الورثة", description: `تم حذف المرفق "${attachmentName}".`, variant: "destructive" });
  };

  const totalExpensesAmount = useMemo(() => {
    return deceasedExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  }, [deceasedExpenses]);

  const handleViewReport = () => {
    if (deceasedExpenses.length === 0) {
      toast({
        title: "لا توجد مصروفات للورثة",
        description: "لا يمكن إنشاء تقرير لأنه لا توجد مصروفات مسجلة للورثة.",
        variant: "default"
      });
      return;
    }
    setIsExpenseReportModalOpen(true);
  };

  const currentCalYear = getYear(new Date());
  const fromCalYear = subYears(new Date(), 10).getFullYear();
  const toCalYear = addYears(new Date(), 10).getFullYear();

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg">إدارة مصروفات الورثة</CardTitle>
            <CardDescription className="text-sm font-semibold">عرض، إضافة، تعديل، وحذف مصروفات الورثة.</CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={handleViewReport} variant="outline" size="sm">
              <FileText className="me-2 h-4 w-4" />
              عرض تقرير مصروفات الورثة
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <Accordion
            type="single"
            collapsible
            className="w-full mb-6 border rounded-lg shadow-sm bg-muted/20"
            value={isAddExpenseAccordionOpen ? "add-expense-item" : ""}
            onValueChange={(value) => {
                 if (!canAddExpenses && value === "add-expense-item") {
                    toast({ title: "غير مصرح به", description: "ليس لديك صلاحية إضافة مصروفات.", variant: "destructive"});
                    setIsAddExpenseAccordionOpen(false);
                    return;
                }
                setIsAddExpenseAccordionOpen(value === "add-expense-item");
            }}
        >
            <AccordionItem value="add-expense-item" className="border-b-0">
                <AccordionTrigger className={cn(
                    "px-4 py-3 hover:bg-muted/60 w-full flex justify-between items-center rounded-t-md text-primary hover:text-primary/90 hover:no-underline",
                    !isAddExpenseAccordionOpen && "rounded-b-md"
                )}>
                    <span className="flex items-center text-lg font-medium">
                        <PlusCircle className="me-2 h-5 w-5" />
                        إضافة مصروف ورثة جديد
                    </span>
                </AccordionTrigger>
                <AccordionContent className="p-4 border-t rounded-b-md bg-background">
                    <Form {...inlineExpenseForm}>
                        <form onSubmit={inlineExpenseForm.handleSubmit(handleInlineAddExpenseSubmit)} className="space-y-4">
                            <FormField
                                control={inlineExpenseForm.control}
                                name="name"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>اسم المصروف</FormLabel>
                                    <FormControl>
                                        <Input placeholder="مثال: فاتورة كهرباء" {...field} className="bg-card" />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={inlineExpenseForm.control}
                                name="amount"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>مبلغ المصروف (ريال)</FormLabel>
                                    <FormControl>
                                        <Input type="number" placeholder="مثال: 350.50" {...field} onChange={e => field.onChange(parseFloat(e.target.value) || 0)} className="bg-card" />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={inlineExpenseForm.control}
                                name="date"
                                render={({ field }) => (
                                    <FormItem className="flex flex-col">
                                    <FormLabel>تاريخ المصروف</FormLabel>
                                    <Popover open={isInlineCalendarOpen} onOpenChange={setIsInlineCalendarOpen}>
                                        <PopoverTrigger asChild>
                                            <div className="relative">
                                                <Input
                                                    placeholder="YYYY-MM-DD"
                                                    value={field.value ? format(field.value, 'yyyy-MM-dd') : ''}
                                                    onChange={(e) => {
                                                        const dateString = e.target.value;
                                                        try {
                                                            const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                                                            if (isValidDate(parsedDate)) {
                                                                field.onChange(parsedDate);
                                                            } else if (dateString === '') {
                                                                field.onChange(undefined);
                                                            }
                                                        } catch {
                                                            field.onChange(undefined);
                                                        }
                                                    }}
                                                    className={cn("pe-10 text-center bg-card", !field.value && "text-muted-foreground")}
                                                />
                                                <CalendarIconLucide
                                                    className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                                                    onClick={() => setIsInlineCalendarOpen(prev => !prev)}
                                                />
                                            </div>
                                        </PopoverTrigger>
                                        <PopoverContent className="w-auto p-0" align="start">
                                        <Calendar
                                            mode="single"
                                            selected={field.value}
                                            onSelect={(date) => { field.onChange(date); setIsInlineCalendarOpen(false); }}
                                            captionLayout="dropdown-buttons"
                                            fromYear={fromCalYear}
                                            toYear={toCalYear}
                                            defaultMonth={field.value || new Date()}
                                            initialFocus
                                            dir="rtl"
                                            locale={arSA}
                                        />
                                        </PopoverContent>
                                    </Popover>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <FormField
                                control={inlineExpenseForm.control}
                                name="description"
                                render={({ field }) => (
                                    <FormItem>
                                    <FormLabel>بيان المصروف</FormLabel>
                                    <FormControl>
                                        <Textarea placeholder="مثال: فاتورة كهرباء مكتب الإدارة لشهر مايو" {...field} className="bg-card" />
                                    </FormControl>
                                    <FormMessage />
                                    </FormItem>
                                )}
                            />
                            <div className="flex justify-end gap-2 pt-2">
                                <Button type="button" variant="outline" onClick={() => { inlineExpenseForm.reset(); setIsAddExpenseAccordionOpen(false);}} disabled={isSubmittingInlineForm}>
                                إلغاء
                                </Button>
                                <Button type="submit" disabled={isSubmittingInlineForm || !canAddExpenses}>
                                {isSubmittingInlineForm && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                                إضافة المصروف
                                </Button>
                            </div>
                        </form>
                    </Form>
                </AccordionContent>
            </AccordionItem>
        </Accordion>

        <ExpensesTable
          expenses={deceasedExpenses}
          onEditExpense={openEditExpenseModal}
          onDeleteExpense={openDeleteExpenseDialog}
          onAddAttachment={handleAddAttachment}
          onDeleteAttachment={handleDeleteAttachment}
          canEdit={canEditExpenses}
          canDelete={canDeleteExpenses}
        />
      </CardContent>
      <CardFooter className="border-t p-6">
        <div className="flex items-center w-full justify-between">
          <div className="flex items-center text-lg font-semibold">
            <Sigma className="me-2 h-5 w-5 text-primary" />
            <span>إجمالي مصروفات الورثة:</span>
          </div>
          <span className="text-lg font-bold text-primary">
            {totalExpensesAmount.toLocaleString()} ريال
          </span>
        </div>
      </CardFooter>

      <AddEditExpenseModal
        isOpen={isAddEditModalOpen}
        onClose={closeModals}
        onSubmit={handleSaveExpense}
        initialData={editingExpense}
      />

      <DeleteExpenseDialog
        isOpen={isDeleteDialogVisible}
        onClose={closeModals}
        onConfirm={handleConfirmDeleteExpense}
        expenseName={expenseToDelete?.name}
      />
      <ExpenseReportModal
        isOpen={isExpenseReportModalOpen}
        onClose={closeModals}
        expenses={deceasedExpenses}
        totalAmount={totalExpensesAmount}
      />
    </Card>
  );
}
