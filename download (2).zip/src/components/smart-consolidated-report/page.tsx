
'use client';

import { useAppContext } from '@/contexts/app-context';
import { useMemo, useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableFooter, TableCaption } from '@/components/ui/table';
import { Badge, type BadgeProps } from '@/components/ui/badge';
import { Printer, ArrowRight, Sigma, TrendingUp, TrendingDown, BarChart3, CalendarClock, AlertTriangle, ListFilter, FileText as FileTextIcon, User, Users as UsersIcon, PackageIcon, ChevronDown, ChevronUp, Info } from 'lucide-react';
import { format, parseISO, isWithinInterval, isValid, startOfDay, endOfDay, isPast, isToday, differenceInCalendarDays, differenceInDays as dateFnsDifferenceInDays } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { useRouter } from 'next/navigation';
import { PAYMENT_STATUSES, getLabelForValue as getConstantLabel, PROPERTY_STATUSES, RENT_TYPES, TAX_RATES, getLabelForValue, getNumberOfInstallmentsLabel, PAYMENT_STATUS_BADGE_VARIANT } from '@/lib/constants';
import { cn } from '@/lib/utils';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import type { Payment, Tenant, Property, Owner, OwnerTransaction, Expense } from '@/types';
import { SimplePaymentDetailModal } from '@/components/simple-payment-detail-modal';
import { TenantReportModal } from '@/components/tenant-report-modal';
import { OwnerReportModal } from '@/components/owner-report-modal';


// --- Profit & Loss Section ---
function ProfitAndLossSection() {
  const { payments, expenses } = useAppContext();
  const allTimeData = useMemo(() => {
    const income = (payments || []).reduce((sum, payment) => sum + payment.amountPaid, 0);
    const expensesTotal = (expenses || []).reduce((sum, expense) => sum + expense.amount, 0);
    const net = income - expensesTotal;
    return { income, expensesTotal, net };
  }, [payments, expenses]);

  return (
    <section className="mb-6 p-4 bg-card rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-2 text-primary border-b pb-2 flex items-center">
        <Sigma className="me-2 h-6 w-6" />
        ملخص الأرباح والخسائر (إجمالي)
      </h2>
      <div className="space-y-2 text-sm">
        <div className="flex justify-between items-center py-2 border-b">
          <span className="font-medium">إجمالي الإيرادات (من الدفعات):</span>
          <span className="font-bold text-green-600">{allTimeData.income.toLocaleString()} ريال</span>
        </div>
        <div className="flex justify-between items-center py-2 border-b">
          <span className="font-medium">إجمالي المصروفات:</span>
          <span className="font-bold text-red-600">{allTimeData.expensesTotal.toLocaleString()} ريال</span>
        </div>
        <div className="flex justify-between items-center py-2 text-base">
          <span className="font-bold">صافي الربح/الخسارة:</span>
          <span className={cn("font-extrabold", allTimeData.net >= 0 ? "text-blue-600" : "text-orange-600")}>
            {allTimeData.net.toLocaleString()} ريال
          </span>
        </div>
      </div>
    </section>
  );
}

// --- Tax Report Section ---
type TaxReportItem = {
  paymentDisplayId: string;
  tenantName: string;
  propertyName: string;
  paymentDescription: string;
  paymentDueDate: string;
  amountPaid: number;
  taxRate: number;
  taxAmount: number;
  paymentStatus: any;
  originalPaymentDueDate: string;
  originalPayment: Payment;
}

function TaxReportSection({ onRowClick }: { onRowClick: (payment: Payment) => void }) {
  const { payments, tenants, properties } = useAppContext();
  const taxReportData = useMemo<TaxReportItem[]>(() => {
    const reportItems = [];
    (payments || []).forEach((payment, index) => {
      if (payment.amountPaid > 0) {
        const tenant = (tenants || []).find(t => t.tenantId === payment.tenantId);
        const property = (properties || []).find(p => p.id === tenant?.propertyId);
        if (tenant) {
          const taxAmount = parseFloat((payment.amountPaid * (tenant.taxRate / (100 + tenant.taxRate))).toFixed(2));
          reportItems.push({
            paymentDisplayId: `${1001 + index}`,
            tenantName: tenant.tenantName,
            propertyName: property?.name || 'غير محدد',
            paymentDescription: payment.description,
            paymentDueDate: format(parseISO(payment.dueDate), 'yyyy/MM/dd', { locale: arSA }),
            amountPaid: payment.amountPaid,
            taxRate: tenant.taxRate,
            taxAmount,
            paymentStatus: payment.status,
            originalPaymentDueDate: payment.dueDate,
            originalPayment: payment,
          });
        }
      }
    });
    return reportItems;
  }, [payments, tenants, properties]);

  const totalTaxCollected = useMemo(() => {
    return taxReportData.reduce((sum, item) => sum + item.taxAmount, 0);
  }, [taxReportData]);


  const getPaymentStatusDisplay = (paymentStatus: TaxReportItem['paymentStatus'], dueDate: string) => {
    const dueDateObj = parseISO(dueDate);
    const now = new Date();
    const startOfDueDateClean = startOfDay(dueDateObj);
    const startOfNowClean = startOfDay(now);
    const daysDifference = differenceInCalendarDays(startOfDueDateClean, startOfNowClean);
    let displayStatusLabel: string;
    let printBadgeClass: string = '';

    if (paymentStatus === 'paid') {
      displayStatusLabel = getConstantLabel(PAYMENT_STATUSES, 'paid');
      printBadgeClass = "badge-paid-print";
    } else if (paymentStatus === 'pending') {
      displayStatusLabel = getConstantLabel(PAYMENT_STATUSES, 'pending');
      printBadgeClass = "badge-pending-print";
    } else if (paymentStatus === 'due' || (daysDifference >= 0 && daysDifference <= 10 && paymentStatus !== 'overdue')) {
      displayStatusLabel = paymentStatus === 'due' ? getConstantLabel(PAYMENT_STATUSES, 'due') : `مستحقة خلال ${daysDifference} يوم`;
      if (daysDifference === 0 && paymentStatus !== 'due') displayStatusLabel = 'مستحقة اليوم';
      printBadgeClass = "badge-due-print";
    } else if (paymentStatus === 'overdue' || daysDifference < 0) {
      const daysOverdueCount = Math.abs(daysDifference);
      displayStatusLabel = paymentStatus === 'overdue' ? getConstantLabel(PAYMENT_STATUSES, 'overdue') : `متأخرة بـ ${daysOverdueCount} يوم`;
      printBadgeClass = "badge-overdue-print";
    } else {
      displayStatusLabel = getConstantLabel(PAYMENT_STATUSES, paymentStatus);
    }
    return { displayStatusLabel, printBadgeClass };
  };

  if (taxReportData.length === 0) {
    return (
      <section className="mb-6 p-4 bg-card rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-2 text-primary border-b pb-2 flex items-center">
          <BarChart3 className="me-2 h-6 w-6" />
          تقرير الضريبة (إجمالي)
        </h2>
        <p className="text-muted-foreground">لا توجد دفعات مدفوعة لعرضها في تقرير الضريبة.</p>
      </section>
    );
  }

  return (
    <section className="mb-6 p-4 bg-card rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-2 text-primary border-b pb-2 flex items-center">
        <BarChart3 className="me-2 h-6 w-6" />
        تقرير الضريبة (إجمالي)
      </h2>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="bg-muted">رقم الدفعة</TableHead>
              <TableHead className="bg-muted">اسم المستأجر</TableHead>
              <TableHead className="bg-muted">اسم العقار</TableHead>
              <TableHead className="bg-muted">بيان الدفعة</TableHead>
              <TableHead className="bg-muted">تاريخ الاستحقاق</TableHead>
              <TableHead className="bg-muted">حالة الدفعة</TableHead>
              <TableHead className="bg-muted">المبلغ المدفوع (شامل)</TableHead>
              <TableHead className="bg-muted">نسبة الضريبة</TableHead>
              <TableHead className="bg-muted">مبلغ الضريبة</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {taxReportData.map((item) => {
              const { displayStatusLabel, printBadgeClass } = getPaymentStatusDisplay(item.paymentStatus, item.originalPaymentDueDate);
              return (
                <TableRow
                  key={item.paymentDisplayId}
                  onClick={() => onRowClick(item.originalPayment)}
                  className="cursor-pointer hover:bg-muted/50 transition-colors"
                >
                  <TableCell>{item.paymentDisplayId}</TableCell>
                  <TableCell>{item.tenantName}</TableCell>
                  <TableCell>{item.propertyName}</TableCell>
                  <TableCell>{item.paymentDescription}</TableCell>
                  <TableCell>{item.paymentDueDate}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={cn('badge-print', printBadgeClass)}>{displayStatusLabel}</Badge>
                  </TableCell>
                  <TableCell>{item.amountPaid.toLocaleString()} ريال</TableCell>
                  <TableCell>{item.taxRate}%</TableCell>
                  <TableCell>{item.taxAmount.toLocaleString()} ريال</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
          <TableFooter>
            <TableRow className="font-bold text-base">
              <TableCell colSpan={8}>إجمالي مبلغ الضريبة المحصل</TableCell>
              <TableCell>{totalTaxCollected.toLocaleString()} ريال</TableCell>
            </TableRow>
          </TableFooter>
        </Table>
      </div>
    </section>
  );
}

// --- Contract Status Summary Section ---
interface CategorizedTenantInfo {
  tenantId: string;
  tenantName: string;
  propertyId: string;
  propertyName: string;
  contractEndDate: string;
  contractEndDateObj: Date;
  status: 'endingSoon' | 'active' | 'expired';
  daysDiff: number;
  contractIdentifier: string;
}

function SmartContractStatusSummarySection({ onTenantClick }: { onTenantClick: (tenant: Tenant) => void }) {
  const { tenants, properties } = useAppContext();
  const ENDING_SOON_THRESHOLD_DAYS = 90;

  const categorizedContracts = useMemo<CategorizedTenantInfo[]>(() => {
    const today = new Date();
    const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());

    return tenants
      .map(tenant => {
        if (!tenant.contractEndDate) return null;
        try {
          const endDateObj = parseISO(tenant.contractEndDate);
          if (!isValid(endDateObj)) return null;

          const startOfEndDate = new Date(endDateObj.getFullYear(), endDateObj.getMonth(), endDateObj.getDate());
          const property = properties.find(p => p.id === tenant.propertyId);
          let status: CategorizedTenantInfo['status'];
          let daysDiff: number;

          if (isPast(startOfEndDate)) {
            status = 'expired';
            daysDiff = dateFnsDifferenceInDays(startOfToday, startOfEndDate);
          } else {
            daysDiff = dateFnsDifferenceInDays(startOfEndDate, startOfToday);
            if (daysDiff <= ENDING_SOON_THRESHOLD_DAYS) {
              status = 'endingSoon';
            } else {
              status = 'active';
            }
          }
          return {
            tenantId: tenant.tenantId,
            tenantName: tenant.tenantName,
            propertyId: tenant.propertyId,
            propertyName: property?.name || 'غير محدد',
            contractEndDate: format(endDateObj, 'yyyy/MM/dd', { locale: arSA }),
            contractEndDateObj: endDateObj,
            status,
            daysDiff,
            contractIdentifier: tenant.contractIdentifier || tenant.tenantId,
          };
        } catch (e) { return null; }
      })
      .filter(item => item !== null) as CategorizedTenantInfo[];
  }, [tenants, properties]);

  const summary = useMemo(() => {
    let activeCount = 0;
    let endingSoonCount = 0;
    let expiredCount = 0;

    categorizedContracts.forEach(contract => {
      if (contract.status === 'expired') expiredCount++;
      else if (contract.status === 'endingSoon') endingSoonCount++;
      else if (contract.status === 'active') activeCount++;
    });
    return { activeCount, endingSoonCount, expiredCount };
  }, [categorizedContracts]);

  const endingSoonContracts = categorizedContracts.filter(c => c.status === 'endingSoon').sort((a,b) => a.daysDiff - b.daysDiff);
  const activeContracts = categorizedContracts.filter(c => c.status === 'active').sort((a,b) => b.contractEndDateObj.getTime() - a.contractEndDateObj.getTime());
  const expiredContracts = categorizedContracts.filter(c => c.status === 'expired').sort((a,b) => b.contractEndDateObj.getTime() - a.contractEndDateObj.getTime());

  const renderContractTable = (contracts: CategorizedTenantInfo[], title: string) => (
    <div className="mt-4">
      <h4 className="text-md font-medium mb-2 text-foreground/80">{title} ({contracts.length})</h4>
      {contracts.length > 0 ? (
        <div className="overflow-x-auto rounded-md border bg-card">
          <Table className="text-xs">
            <TableHeader>
              <TableRow>
                <TableHead className="min-w-[100px] bg-muted">اسم المستأجر</TableHead>
                <TableHead className="min-w-[100px] bg-muted">اسم العقار</TableHead>
                <TableHead className="min-w-[80px] bg-muted">رقم العقد</TableHead>
                <TableHead className="min-w-[80px] bg-muted">تاريخ الانتهاء</TableHead>
                <TableHead className="min-w-[120px] bg-muted">الحالة / الأيام</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contracts.map((contract) => {
                let statusBadge: React.ReactNode;
                let daysText: string = '';
                if (contract.status === 'endingSoon') {
                  statusBadge = <Badge variant="destructive" className="badge-print badge-endingSoon-print">قريب الانتهاء</Badge>;
                  daysText = `(${contract.daysDiff} ${contract.daysDiff === 1 ? 'يوم متبقي' : 'أيام متبقية'})`;
                } else if (contract.status === 'active') {
                  statusBadge = <Badge variant="default" className="bg-green-600 hover:bg-green-700 text-white badge-print badge-active-print">ساري</Badge>;
                  daysText = `(${contract.daysDiff} ${contract.daysDiff === 1 ? 'يوم متبقي' : 'أيام متبقية'})`;
                } else {
                  statusBadge = <Badge variant="secondary" className="bg-yellow-400 hover:bg-yellow-500 text-black badge-print badge-expired-print">منتهي</Badge>;
                  daysText = `(منذ ${contract.daysDiff} ${contract.daysDiff === 1 ? 'يوم' : 'أيام'})`;
                }
                const fullTenant = tenants.find(t => t.tenantId === contract.tenantId);
                return (
                  <TableRow 
                    key={contract.tenantId}
                    onClick={() => fullTenant && onTenantClick(fullTenant)}
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                  >
                    <TableCell 
                      className="font-medium"
                    >
                      {contract.tenantName}
                    </TableCell>
                    <TableCell>{contract.propertyName}</TableCell>
                    <TableCell>{contract.contractIdentifier}</TableCell>
                    <TableCell>{contract.contractEndDate}</TableCell>
                    <TableCell>
                      <div className="flex flex-col items-start">
                        {statusBadge}
                        <span className="text-xs text-muted-foreground mt-0.5">{daysText}</span>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">لا توجد عقود ضمن هذه الفئة.</p>
      )}
    </div>
  );


  return (
     <AccordionItem value="contract-status-summary-accordion" className="border-b-0 bg-card rounded-lg shadow-md">
        <AccordionTrigger className="px-4 py-3 hover:bg-muted/60 w-full flex justify-between items-center text-xl font-semibold text-primary hover:text-primary/90 hover:no-underline accordion-trigger-print">
          <span className="flex items-center">
              <CalendarClock className="me-2 h-6 w-6" />
              ملخص حالات العقود
          </span>
        </AccordionTrigger>
        <AccordionContent className="p-4 border-t accordion-content-print bg-card">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm mb-6">
              <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-md text-center">
              <p className="font-semibold text-green-700 dark:text-green-300">عقود سارية</p>
              <p className="text-2xl font-bold text-green-800 dark:text-green-200">{summary.activeCount}</p>
              </div>
              <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-md text-center">
              <p className="font-semibold text-yellow-700 dark:text-yellow-300">عقود قريبة الانتهاء</p>
              <p className="text-2xl font-bold text-yellow-800 dark:text-yellow-200">{summary.endingSoonCount}</p>
              </div>
              <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-md text-center">
              <p className="font-semibold text-red-700 dark:text-red-300">عقود منتهية</p>
              <p className="text-2xl font-bold text-red-800 dark:text-red-200">{summary.expiredCount}</p>
              </div>
          </div>
          {renderContractTable(endingSoonContracts, "العقود القريبة من الانتهاء")}
          {renderContractTable(activeContracts, "العقود السارية")}
          {renderContractTable(expiredContracts, "العقود المنتهية")}
        </AccordionContent>
      </AccordionItem>
  );
}

// --- Tenant List Section for Consolidated Report ---
function TenantListSection({ onTenantClick }: { onTenantClick: (tenant: Tenant) => void }) {
  const { tenants: allTenants, properties: allProperties } = useAppContext();

  const activeTenants = useMemo(() => {
    return allTenants.filter(tenant => {
      if (!tenant.contractEndDate) return false;
      try {
        return !isPast(parseISO(tenant.contractEndDate));
      } catch {
        return false;
      }
    });
  }, [allTenants]);

  if (activeTenants.length === 0) {
    return (
      <AccordionItem value="tenant-list-accordion" className="border-b-0 bg-card rounded-lg shadow-md">
        <AccordionTrigger className="px-4 py-3 hover:bg-muted/60 w-full flex justify-between items-center text-xl font-semibold text-primary hover:text-primary/90 hover:no-underline accordion-trigger-print">
          <span className="flex items-center">
            <UsersIcon className="me-2 h-6 w-6" />
            قائمة المستأجرين النشطين
          </span>
        </AccordionTrigger>
        <AccordionContent className="p-4 border-t accordion-content-print bg-card">
          <p className="text-muted-foreground">لا يوجد مستأجرين نشطين حالياً.</p>
        </AccordionContent>
      </AccordionItem>
    );
  }

  return (
    <AccordionItem value="tenant-list-accordion" className="border-b-0 bg-card rounded-lg shadow-md">
      <AccordionTrigger className="px-4 py-3 hover:bg-muted/60 w-full flex justify-between items-center text-xl font-semibold text-primary hover:text-primary/90 hover:no-underline accordion-trigger-print">
        <span className="flex items-center">
          <UsersIcon className="me-2 h-6 w-6" />
          قائمة المستأجرين النشطين ({activeTenants.length})
        </span>
      </AccordionTrigger>
      <AccordionContent className="p-4 border-t accordion-content-print bg-card">
        <div className="overflow-x-auto rounded-md border bg-card">
          <Table className="text-sm">
            <TableHeader>
              <TableRow>
                <TableHead className="min-w-[150px] bg-muted">اسم المستأجر</TableHead>
                <TableHead className="min-w-[150px] bg-muted">اسم العقار</TableHead>
                <TableHead className="min-w-[100px] bg-muted">رقم العقد</TableHead>
                <TableHead className="min-w-[100px] bg-muted">تاريخ انتهاء العقد</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {activeTenants.map(tenant => {
                const property = allProperties.find(p => p.id === tenant.propertyId);
                return (
                  <TableRow
                    key={tenant.tenantId}
                    onClick={() => onTenantClick(tenant)}
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                  >
                    <TableCell className="font-medium">{tenant.tenantName}</TableCell>
                    <TableCell>{property?.name || 'غير محدد'}</TableCell>
                    <TableCell>{tenant.contractIdentifier || tenant.tenantId}</TableCell>
                    <TableCell>{tenant.contractEndDate ? format(parseISO(tenant.contractEndDate), 'yyyy/MM/dd', { locale: arSA }) : '-'}</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </AccordionContent>
    </AccordionItem>
  );
}


// --- Overdue & Due Payments Summary Section ---
function SmartOverdueDueSummarySection() {
  const { payments } = useAppContext();
  const DUE_SOON_THRESHOLD_DAYS = 10;

  const summary = useMemo(() => {
    let overdueCount = 0;
    let overdueAmount = 0;
    let dueSoonCount = 0;
    let dueSoonAmount = 0;
    let dueTodayCount = 0;
    let dueTodayAmount = 0;

    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());

    (payments || []).forEach(payment => {
      if (payment.amountPaid >= payment.amountDue) return;
      if (!payment.dueDate || !isValid(parseISO(payment.dueDate))) return;

      const dueDateObj = parseISO(payment.dueDate);
      const dueDateStart = new Date(dueDateObj.getFullYear(), dueDateObj.getMonth(), dueDateObj.getDate());
      const balance = payment.amountDue - payment.amountPaid;

      if (isPast(dueDateStart) && !isToday(dueDateStart)) {
        overdueCount++;
        overdueAmount += balance;
      } else {
        const daysUntilDue = differenceInCalendarDays(dueDateStart, todayStart);
        if (daysUntilDue === 0) {
          dueTodayCount++;
          dueTodayAmount += balance;
        } else if (daysUntilDue > 0 && daysUntilDue <= DUE_SOON_THRESHOLD_DAYS) {
          dueSoonCount++;
          dueSoonAmount += balance;
        }
      }
    });
    return { overdueCount, overdueAmount, dueSoonCount, dueSoonAmount, dueTodayCount, dueTodayAmount };
  }, [payments]);

  return (
    <section className="mb-6 p-4 bg-card rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-2 text-primary border-b pb-2 flex items-center">
        <AlertTriangle className="me-2 h-6 w-6" />
        ملخص الدفعات الهامة
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
        <div className="p-3 bg-red-100 dark:bg-red-900/30 rounded-md">
          <p className="font-semibold text-red-700 dark:text-red-300 text-center">دفعات متأخرة</p>
          <p className="text-lg font-bold text-red-800 dark:text-red-200 text-center">{summary.overdueCount} دفعات</p>
          <p className="text-sm text-red-600 dark:text-red-400 text-center">بإجمالي: {summary.overdueAmount.toLocaleString()} ريال</p>
        </div>
        <div className="p-3 bg-orange-100 dark:bg-orange-900/30 rounded-md">
          <p className="font-semibold text-orange-700 dark:text-orange-300 text-center">مستحقة قريباً</p>
          <p className="text-lg font-bold text-orange-800 dark:text-orange-200 text-center">{summary.dueSoonCount} دفعات</p>
          <p className="text-sm text-orange-600 dark:text-orange-400 text-center">بإجمالي: {summary.dueSoonAmount.toLocaleString()} ريال</p>
        </div>
        <div className="p-3 bg-amber-100 dark:bg-amber-900/30 rounded-md">
          <p className="font-semibold text-amber-700 dark:text-amber-300 text-center">مستحقة اليوم</p>
          <p className="text-lg font-bold text-amber-800 dark:text-amber-200 text-center">{summary.dueTodayCount} دفعات</p>
          <p className="text-sm text-amber-600 dark:text-amber-400 text-center">بإجمالي: {summary.dueTodayAmount.toLocaleString()} ريال</p>
        </div>
      </div>
    </section>
  );
}

// --- Expenses Summary Section ---
function SmartExpensesSummarySection() {
  const { expenses } = useAppContext();
  const totalExpensesAmount = useMemo(() => {
    return (expenses || []).reduce((sum, expense) => sum + expense.amount, 0);
  }, [expenses]);

  return (
    <section className="mb-6 p-4 bg-card rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-2 text-primary border-b pb-2 flex items-center">
        <PackageIcon className="me-2 h-6 w-6" />
        ملخص المصروفات
      </h2>
      <div className="text-center py-2">
        <p className="text-sm font-medium">إجمالي المصروفات المسجلة:</p>
        <p className="text-2xl font-bold text-red-600">{totalExpensesAmount.toLocaleString()} ريال</p>
      </div>
    </section>
  );
}

// --- Owner Balances Summary Section ---
function SmartOwnerBalancesSummarySection({ onOwnerClick }: { onOwnerClick: (owner: Owner) => void }) {
  const { owners, ownerTransactions } = useAppContext();
  const ownerBalances = useMemo(() => {
    return (owners || []).map(owner => {
      const transactions = (ownerTransactions || []).filter(t => t.ownerId === owner.id);
      const netBalance = transactions.reduce((sum, t) => sum + t.amount, 0);
      return { ...owner, netBalance };
    });
  }, [owners, ownerTransactions]);

  if (!ownerBalances || ownerBalances.length === 0) {
    return (
      <section className="mb-6 p-4 bg-card rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-2 text-primary border-b pb-2 flex items-center">
          <UsersIcon className="me-2 h-6 w-6" />
          ملخص أرصدة الملاك
        </h2>
        <p className="text-muted-foreground">لا يوجد ملاك لعرض أرصدتهم.</p>
      </section>
    );
  }

  return (
    <section className="mb-6 p-4 bg-card rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-2 text-primary border-b pb-2 flex items-center">
        <UsersIcon className="me-2 h-6 w-6" />
        ملخص أرصدة الملاك
      </h2>
      <div className="space-y-3">
        {ownerBalances.map(owner => (
          <div 
            key={owner.id} 
            className="flex justify-between items-center p-3 border rounded-md bg-card text-sm cursor-pointer hover:bg-muted/50 transition-colors"
            onClick={() => onOwnerClick(owner)}
          >
            <span className="font-medium flex items-center"><User className="me-2 h-4 w-4 text-muted-foreground"/>{owner.name}</span>
            <span className={cn("font-bold", owner.netBalance >= 0 ? "text-green-600" : "text-destructive")}>
              {owner.netBalance.toLocaleString()} ريال
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}


export default function SmartConsolidatedReportPage() {
  const router = useRouter();
  const { 
    tenants: allTenants, 
    properties: allProperties, 
    payments: allPayments,
    owners,
    ownerTransactions,
    expenses
  } = useAppContext();

  const [isPaymentDetailModalOpen, setIsPaymentDetailModalOpen] = useState(false);
  const [selectedPaymentForDetail, setSelectedPaymentForDetail] = useState<Payment | null>(null);

  const [isTenantReportModalOpen, setIsTenantReportModalOpen] = useState(false);
  const [selectedTenantForFullReport, setSelectedTenantForFullReport] = useState<Tenant | null>(null);
  const [selectedPropertyForFullReport, setSelectedPropertyForFullReport] = useState<Property | null>(null);
  const [selectedTenantPaymentsForFullReport, setSelectedTenantPaymentsForFullReport] = useState<Payment[]>([]);

  const [isOwnerReportModalOpen, setIsOwnerReportModalOpen] = useState(false);
  const [selectedOwnerForReport, setSelectedOwnerForReport] = useState<Owner | null>(null);
  const [selectedOwnerTransactionsForReport, setSelectedOwnerTransactionsForReport] = useState<OwnerTransaction[]>([]);

  const ownerBalancesForModal = useMemo(() => { 
    return (owners || []).map(owner => {
      const transactions = (ownerTransactions || []).filter(t => t.ownerId === owner.id);
      const netBalance = transactions.reduce((sum, t) => sum + t.amount, 0);
      return { ...owner, netBalance };
    });
  }, [owners, ownerTransactions]);


  const handleOpenPaymentDetailModal = (payment: Payment) => {
    setSelectedPaymentForDetail(payment);
    setIsPaymentDetailModalOpen(true);
  };

  const handleOpenTenantFullReport = (tenantToReport: Tenant) => {
    const property = allProperties.find(p => p.id === tenantToReport.propertyId);
    const tenantPayments = allPayments.filter(p => p.tenantId === tenantToReport.tenantId);

    setSelectedTenantForFullReport(tenantToReport);
    setSelectedPropertyForFullReport(property || null);
    setSelectedTenantPaymentsForFullReport(tenantPayments);
    setIsTenantReportModalOpen(true);
  };

  const handleOpenOwnerReport = (ownerToReport: Owner) => {
    const transactions = ownerTransactions.filter(t => t.ownerId === ownerToReport.id);
    setSelectedOwnerForReport(ownerToReport);
    setSelectedOwnerTransactionsForReport(transactions);
    setIsOwnerReportModalOpen(true);
  };


  const handlePrint = () => {
    const header = document.querySelector('header.bg-primary');
    const nav = document.querySelector('nav.bg-card');
    const buttons = document.getElementById('report-actions-smart');

    if (header) (header as HTMLElement).style.display = 'none';
    if (nav) (nav as HTMLElement).style.display = 'none';
    if (buttons) buttons.style.display = 'none';
    
    // Ensure all accordions are open for printing
    const accordions = document.querySelectorAll('#smart-consolidated-report-content .accordion-content-print');
    accordions.forEach(acc => (acc as HTMLElement).style.display = 'block');

    window.print();

    if (header) (header as HTMLElement).style.display = '';
    if (nav) (nav as HTMLElement).style.display = '';
    if (buttons) buttons.style.display = '';
  };

  return (
    <div className="container mx-auto px-4 py-8 print-container-smart">
      <style jsx global>{`
        @media print {
          body * { visibility: hidden; }
          .print-container-smart, .print-container-smart * { visibility: visible; }
          .print-container-smart { position: absolute; left: 0; top: 0; width: 100%; }
          .no-print { display: none !important; }
          .badge-print { padding: 0.2em 0.6em; border-radius: 0.25rem; font-size: 0.85em; display: inline-block; border: 1px solid transparent; }
          .badge-paid-print { background-color: #d4edda !important; color: #155724 !important; border-color: #c3e6cb !important; }
          .badge-pending-print { background-color: #e2e8f0 !important; color: #4a5568 !important; border-color: #cbd5e0 !important; }
          .badge-overdue-print { background-color: #f8d7da !important; color: #721c24 !important; border-color: #f5c6cb !important; }
          .badge-due-print { background-color: #ffe8cc !important; color: #994d00 !important; border-color: #ffd1a3 !important; }
          .badge-endingSoon-print { color: #fff !important; background-color: #dc3545 !important; }
          .badge-active-print { color: #fff !important; background-color: #28a745 !important; }
          .badge-expired-print { color: #212529 !important; background-color: #ffc107 !important; }
          .accordion-content-print { display: block !important; } 
          .accordion-trigger-print button > svg { display: none !important; } /* Hide accordion chevron for print */
        }
      `}</style>

      <div id="report-actions-smart" className="flex justify-between items-center mb-6 no-print">
        <h1 className="text-2xl font-bold text-primary">التقرير المجمع للعقار الذكي</h1>
        <div className="space-x-2 rtl:space-x-reverse">
          <Button variant="outline" onClick={() => router.push('/')}>
            <ArrowRight className="me-2 h-4 w-4" />
            العودة إلى لوحة التحكم
          </Button>
          <Button onClick={handlePrint}>
            <Printer className="me-2 h-4 w-4" />
            طباعة التقرير المجمع
          </Button>
        </div>
      </div>
      
      <div id="smart-consolidated-report-content">
        <ProfitAndLossSection />
        <TaxReportSection onRowClick={handleOpenPaymentDetailModal} />
        
        <Accordion type="multiple" className="w-full space-y-4 mb-6" defaultValue={["contract-status-summary-accordion", "tenant-list-accordion"]}>
          <SmartContractStatusSummarySection onTenantClick={handleOpenTenantFullReport} />
          <TenantListSection onTenantClick={handleOpenTenantFullReport} />
        </Accordion>

        <SmartOverdueDueSummarySection />
        <SmartExpensesSummarySection />
        <SmartOwnerBalancesSummarySection onOwnerClick={handleOpenOwnerReport} />
      </div>


      {selectedPaymentForDetail && (
        <SimplePaymentDetailModal
          isOpen={isPaymentDetailModalOpen}
          onClose={() => setIsPaymentDetailModalOpen(false)}
          payment={selectedPaymentForDetail}
        />
      )}

      {selectedTenantForFullReport && selectedPropertyForFullReport && (
        <TenantReportModal
          isOpen={isTenantReportModalOpen}
          onClose={() => setIsTenantReportModalOpen(false)}
          tenant={selectedTenantForFullReport}
          property={selectedPropertyForFullReport}
          payments={selectedTenantPaymentsForFullReport}
        />
      )}

      {selectedOwnerForReport && (
        <OwnerReportModal
          isOpen={isOwnerReportModalOpen}
          onClose={() => setIsOwnerReportModalOpen(false)}
          owner={selectedOwnerForReport}
          transactions={selectedOwnerTransactionsForReport}
          totalAmount={ownerBalancesForModal.find(ob => ob.id === selectedOwnerForReport.id)?.netBalance || 0}
        />
      )}
    </div>
  );
}
    

    
