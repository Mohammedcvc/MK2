
'use client';

import type { User, UserPermissions } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableCaption,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Edit3, Trash2, UserCog, KeyRound, CheckCircle, XCircle, PrinterIcon, PlusCircle, User as UserIcon, Clock } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { useAppContext } from '@/contexts/app-context';
import { format, parseISO } from 'date-fns';
import { arSA } from 'date-fns/locale';

interface UsersTableProps {
  users: User[];
  onEditUser: (user: User) => void;
  onDeleteUser: (userId: string) => void;
  currentUserId?: string;
  canEdit?: boolean; 
  canDelete?: boolean;
}

export function UsersTable({ users, onEditUser, onDeleteUser, currentUserId, canEdit, canDelete }: UsersTableProps) {
  const { currentUser: loggedInUser } = useAppContext();
  
  const formatTimestamp = (isoString?: string) => {
    if (!isoString) return '-';
    try {
      return format(parseISO(isoString), 'yyyy/MM/dd HH:mm', { locale: arSA });
    } catch (e) {
      return 'تاريخ خاطئ';
    }
  };

  if (users.length === 0) {
    return <p className="text-center text-muted-foreground py-8">لا يوجد مستخدمون لعرضهم.</p>;
  }

  const PermissionIndicator = ({ granted }: { granted: boolean }) => (
    granted ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4 text-destructive" />
  );

  return (
    <div className="overflow-x-auto rounded-md border">
      <Table>
        <TableCaption>
          قائمة بجميع المستخدمين في النظام.
          <strong className="text-destructive"> تحذير: عرض كلمات المرور مباشرة هو لأغراض العرض التوضيحي فقط وغير آمن للبيئات الإنتاجية.</strong>
        </TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="min-w-[150px]">اسم المستخدم</TableHead>
            <TableHead className="min-w-[120px]">كلمة المرور</TableHead>
            <TableHead className="min-w-[100px]">الأدوار</TableHead>
            <TableHead className="text-center min-w-[70px]">إضافة</TableHead>
            <TableHead className="text-center min-w-[70px]">تعديل</TableHead>
            <TableHead className="text-center min-w-[70px]">حذف</TableHead>
            <TableHead className="text-center min-w-[70px]">طباعة</TableHead>
            <TableHead className="min-w-[150px]">آخر تعديل بواسطة</TableHead>
            <TableHead className="min-w-[170px]">وقت آخر تعديل</TableHead>
            <TableHead className="text-center min-w-[100px]">الإجراءات</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user.id} className="hover:bg-muted/20 transition-colors">
              <TableCell
                className={cn(
                  "font-medium flex items-center",
                  canEdit && "cursor-pointer hover:underline"
                )}
                onClick={() => {
                  if (canEdit) {
                    onEditUser(user);
                  }
                }}
              >
                <UserCog className="h-4 w-4 me-2 text-muted-foreground" />
                {user.username}
                {user.id === currentUserId && <Badge variant="outline" className="ms-2 text-xs"> (أنت)</Badge>}
              </TableCell>
              <TableCell className="font-mono text-xs flex items-center">
                <KeyRound className="h-3.5 w-3.5 me-1.5 text-muted-foreground" />
                {user.password || '******'}
              </TableCell>
              <TableCell>
                {user.roles.map(role => (
                  <Badge key={role} variant={role === 'admin' ? 'default' : 'secondary'} className="me-1">
                    {role === 'admin' ? 'مسؤول' : 'مستخدم'}
                  </Badge>
                ))}
                {user.roles.length === 0 && <span className="text-xs text-muted-foreground">لا توجد أدوار</span>}
              </TableCell>
              <TableCell className="text-center"><PermissionIndicator granted={user.permissions?.canAdd ?? false} /></TableCell>
              <TableCell className="text-center"><PermissionIndicator granted={user.permissions?.canEdit ?? false} /></TableCell>
              <TableCell className="text-center"><PermissionIndicator granted={user.permissions?.canDelete ?? false} /></TableCell>
              <TableCell className="text-center"><PermissionIndicator granted={user.permissions?.canPrint ?? false} /></TableCell>
              <TableCell>
                <div className="flex items-center text-xs text-muted-foreground">
                  <UserIcon className="h-3 w-3 me-1" /> {user.lastModifiedBy || '-'}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex items-center text-xs text-muted-foreground">
                  <Clock className="h-3 w-3 me-1" /> {formatTimestamp(user.lastModifiedAt)}
                </div>
              </TableCell>
              <TableCell className="text-center">
                <TooltipProvider>
                  <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-primary hover:text-primary/90 h-8 w-8"
                          onClick={() => onEditUser(user)}
                          disabled={!canEdit}
                        >
                          <Edit3 className="h-4 w-4" />
                          <span className="sr-only">تعديل المستخدم</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>{!canEdit ? "لا تملك صلاحية التعديل" : "تعديل المستخدم"}</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:text-destructive/90 h-8 w-8"
                          onClick={() => onDeleteUser(user.id)}
                          disabled={user.id === currentUserId || !canDelete}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">حذف المستخدم</span>
                        </Button>
                      </TooltipTrigger>
                       <TooltipContent><p>{user.id === currentUserId ? "لا يمكن حذف المستخدم الحالي" : (!canDelete ? "لا تملك صلاحية الحذف" : "حذف المستخدم")}</p></TooltipContent>
                    </Tooltip>
                  </div>
                </TooltipProvider>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
