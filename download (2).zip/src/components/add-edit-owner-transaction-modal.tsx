
'use client';

import type { OwnerTransaction } from '@/types';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, SubmitHandler } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Loader2 } from 'lucide-react';
import { format, parse, parseISO, isValid, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useState, useEffect } from 'react';

const ownerTransactionFormSchema = z.object({
  date: z.date({ required_error: 'تاريخ الحركة مطلوب.' }),
  amount: z.coerce.number({ invalid_type_error: 'المبلغ يجب أن يكون رقمًا.' }), // Can be positive or negative
  description: z.string().min(3, { message: 'بيان الحركة يجب أن لا يقل عن 3 أحرف.' }),
});

export type OwnerTransactionFormValues = z.infer<typeof ownerTransactionFormSchema>;

interface AddEditOwnerTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: OwnerTransactionFormValues, transactionIdToUpdate?: string) => Promise<void>;
  initialData?: OwnerTransaction | null; 
  ownerId: string;
}

export function AddEditOwnerTransactionModal({ isOpen, onClose, onSubmit, initialData, ownerId }: AddEditOwnerTransactionModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  const form = useForm<OwnerTransactionFormValues>({
    resolver: zodResolver(ownerTransactionFormSchema),
    defaultValues: initialData
      ? {
          ...initialData,
          date: initialData.date ? parseISO(initialData.date) : new Date(),
        }
      : {
          date: new Date(),
          amount: 0,
          description: '',
        },
  });

  useEffect(() => {
    if (isOpen) {
      form.reset(
        initialData
          ? {
              ...initialData,
              date: initialData.date ? parseISO(initialData.date) : new Date(),
            }
          : {
              date: new Date(),
              amount: 0,
              description: '',
            }
      );
      setIsCalendarOpen(false);
    }
  }, [isOpen, initialData, form]);

  const handleSubmit: SubmitHandler<OwnerTransactionFormValues> = async (data) => {
    setIsSubmitting(true);
    await onSubmit(data, initialData?.id);
    setIsSubmitting(false);
  };

  const currentYear = getYear(new Date());
  const fromYear = subYears(new Date(), 10).getFullYear();
  const toYear = addYears(new Date(), 10).getFullYear();

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{initialData ? 'تعديل الحركة المالية' : 'إضافة حركة مالية جديدة'}</DialogTitle>
          <DialogDescription>
            {initialData ? 'قم بتحديث معلومات الحركة المالية للمالك.' : `إضافة حركة مالية جديدة للمالك.`}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-2 max-h-[70vh] overflow-y-auto px-1">
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>تاريخ الحركة</FormLabel>
                  <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                    <PopoverTrigger asChild>
                      <div className="relative">
                        <Input
                          placeholder="YYYY-MM-DD"
                          value={field.value ? format(field.value, 'yyyy-MM-dd') : ''}
                          onChange={(e) => {
                            const dateString = e.target.value;
                            try {
                              const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                              if (isValid(parsedDate)) {
                                field.onChange(parsedDate);
                              } else if (dateString === '') {
                                field.onChange(undefined);
                              }
                            } catch {
                              field.onChange(undefined);
                            }
                          }}
                          className={cn("pe-10 text-center bg-card", !field.value && "text-muted-foreground")}
                        />
                        <CalendarIcon
                          className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                          onClick={() => setIsCalendarOpen(prev => !prev)}
                        />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={(date) => { field.onChange(date); setIsCalendarOpen(false); }}
                        captionLayout="dropdown-buttons"
                        fromYear={fromYear}
                        toYear={toYear}
                        defaultMonth={field.value || new Date()}
                        initialFocus
                        dir="rtl"
                        locale={arSA}
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>المبلغ (ريال)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="مثال: 5000 أو -500" {...field} className="bg-card text-center" />
                  </FormControl>
                  <FormMessage />
                  <p className="text-xs text-muted-foreground">استخدم قيمة موجبة للإيداع وقيمة سالبة للسحب.</p>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>بيان الحركة</FormLabel>
                  <FormControl>
                    <Textarea placeholder="مثال: تحويل أرباح، سداد مصاريف..." {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                إلغاء
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                {initialData ? 'حفظ التغييرات' : 'إضافة الحركة'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
