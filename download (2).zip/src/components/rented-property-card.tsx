
'use client';

import type { Property, Tenant, Payment, PropertyStatus } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MoreVertical, Bell, Store, CalendarDays, Wallet, Info, CheckCircle, LogOut, Home } from 'lucide-react';
import { format, parseISO, isPast, differenceInDays, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { useToast } from '@/hooks/use-toast';
import { useAppContext } from '@/contexts/app-context';
import { getLabelForValue, PROPERTY_STATUSES } from '@/lib/constants';
import { cn } from '@/lib/utils';


interface RentedPropertyCardProps {
  property: Property;
  tenant: Tenant | null;
  payments: Payment[];
  dataSource?: 'main' | 'deceased';
  onViewDetails?: (property: Property) => void;
}

export function RentedPropertyCard({ property, tenant, payments, dataSource = 'main', onViewDetails }: RentedPropertyCardProps) {
  const [showNotification, setShowNotification] = useState(false);
  const [isEndingSoon, setIsEndingSoon] = useState(false);

  const router = useRouter();
  const { toast } = useToast();
  const {
    setProperties: setMainProperties,
    setTenants: setMainTenants,
    setDeceasedProperties,
    setDeceasedTenants
  } = useAppContext();

  const activeSetProperties = dataSource === 'deceased' ? setDeceasedProperties : setMainProperties;
  const activeSetTenants = dataSource === 'deceased' ? setDeceasedTenants : setMainTenants;

  const { contractEndDateObj, displayContractEndDate } = useMemo(() => {
    if (tenant?.contractEndDate) {
      try {
        const parsedDate = parseISO(tenant.contractEndDate);
        return {
          contractEndDateObj: parsedDate,
          displayContractEndDate: format(parsedDate, 'yyyy/MM/dd', { locale: arSA }),
        };
      } catch (error) {
        console.error("Error parsing contract end date:", error);
        return { contractEndDateObj: null, displayContractEndDate: 'تاريخ خاطئ' };
      }
    }
    return { contractEndDateObj: null, displayContractEndDate: '' };
  }, [tenant?.contractEndDate]);

  const isTenantActive = useMemo(() => {
    return tenant && contractEndDateObj && !isPast(contractEndDateObj);
  }, [tenant, contractEndDateObj]);

  const hasTenantDeparted = useMemo(() => {
    return tenant && contractEndDateObj && isPast(contractEndDateObj);
  }, [tenant, contractEndDateObj]);

  const tenantPayments = tenant ? payments.filter(p => p.tenantId === tenant.tenantId) : [];

  const totalContractValueForTenant = tenant ? tenant.contractValue : 0;
  const taxAmountForTenant = tenant ? (tenant.contractValue * (tenant.taxRate / 100)) : 0;
  const totalWithTaxForTenant = totalContractValueForTenant + taxAmountForTenant;
  const totalPaidByTenant = tenantPayments.reduce((sum, p) => sum + p.amountPaid, 0);
  const balanceForTenant = totalWithTaxForTenant - totalPaidByTenant;

  useEffect(() => {
    if (contractEndDateObj && isTenantActive) {
      const now = new Date();
      const diffDays = differenceInDays(contractEndDateObj, now);

      setShowNotification(diffDays <= 30);
      setIsEndingSoon(diffDays <= 60);
    } else {
      setShowNotification(false);
      setIsEndingSoon(false);
    }
  }, [contractEndDateObj, isTenantActive]);


  const handleCardClick = () => {
    if (onViewDetails) {
      onViewDetails(property);
    } else {
      router.push(`/properties/${property.id}${dataSource === 'deceased' ? '?source=deceased' : ''}`);
    }
  };

  const handleChangePropertyStatus = (newStatus: PropertyStatus) => {
    if (!tenant && (newStatus === 'vacant' || newStatus === 'rented')) {
        toast({ title: "خطأ", description: "لا يوجد مستأجر مرتبط بهذا الإجراء لتغيير حالته.", variant: "destructive"});
        if (newStatus === 'maintenance') {
             activeSetProperties(prevProps =>
                prevProps.map(p => (p.id === property.id ? { ...p, status: newStatus } : p))
            );
            toast({ title: "تم تحديث الحالة", description: `تم تحديث حالة العقار ${property.name} إلى "${getLabelForValue(PROPERTY_STATUSES, newStatus)}".` });
        }
        return;
    }

    let currentTenantIsActuallyActive = false;
    if (tenant && tenant.contractEndDate) {
        try {
            currentTenantIsActuallyActive = !isPast(parseISO(tenant.contractEndDate));
        } catch (e) { /* date parsing error */ }
    }

    let toastMessage = `تم تحديث حالة العقار ${property.name} إلى "${getLabelForValue(PROPERTY_STATUSES, newStatus)}".`;

    if (newStatus === 'vacant' && tenant && currentTenantIsActuallyActive) {
        activeSetTenants(prevTenants =>
            prevTenants.map(t =>
                t.tenantId === tenant.tenantId
                ? { ...t, contractEndDate: format(new Date(), 'yyyy-MM-dd') }
                : t
            )
        );
        activeSetProperties(prevProps =>
            prevProps.map(p => (p.id === property.id ? { ...p, status: 'vacant' } : p))
        );
        toastMessage = `تم تحديث حالة العقار ${property.name} إلى "شاغر" وإنهاء عقد المستأجر ${tenant.tenantName}.`;

    } else if (newStatus === 'rented' && tenant && !currentTenantIsActuallyActive) {
        const newContractEndDate = addYears(new Date(), 1);
        activeSetTenants(prevTenants =>
            prevTenants.map(t =>
                t.tenantId === tenant.tenantId
                ? { ...t, contractEndDate: format(newContractEndDate, 'yyyy-MM-dd') }
                : t
            )
        );
        activeSetProperties(prevProps =>
            prevProps.map(p => (p.id === property.id ? { ...p, status: 'rented' } : p))
        );
        toastMessage = `تم إعادة تأجير العقار ${property.name} للمستأجر ${tenant.tenantName}.`;

    } else if (newStatus === 'rented' && tenant && currentTenantIsActuallyActive) {
        activeSetProperties(prevProps =>
            prevProps.map(p => (p.id === property.id ? { ...p, status: 'rented' } : p))
        );
        toastMessage = `العقار ${property.name} مؤجر بالفعل للمستأجر ${tenant.tenantName}.`;
    } else {
         activeSetProperties(prevProps =>
            prevProps.map(p => (p.id === property.id ? { ...p, status: newStatus } : p))
        );
    }

    toast({ title: "تم تحديث الحالة", description: toastMessage });
};


  const handleMarkAsDeparted = () => {
    if (tenant && isTenantActive) {
        activeSetTenants(prevTenants =>
            prevTenants.map(t =>
            t.tenantId === tenant.tenantId ? { ...t, contractEndDate: format(new Date(), 'yyyy-MM-dd') } : t
            )
        );
        activeSetProperties(prevProps =>
            prevProps.map(p => p.id === property.id ? { ...p, status: 'vacant' } : p)
        );
        toast({ title: "تم تسجيل المغادرة", description: `تم تسجيل مغادرة المستأجر ${tenant.tenantName} من العقار ${property.name}.`});
    } else if (tenant && !isTenantActive) {
        toast({ title: "معلومة", description: `المستأجر ${tenant.tenantName} قد غادر بالفعل أو عقده منتهي.`, variant: "default"});
    } else {
        toast({ title: "خطأ", description: "لا يوجد مستأجر حالي لتسجيل المغادرة.", variant: "destructive"});
    }
  };

  const isPropertyRented = property.status === 'rented';
  const isPropertyVacant = property.status === 'vacant';
  const isPropertyMaintenance = property.status === 'maintenance';


  return (
    <Card className={cn(
      "shadow-lg flex flex-col h-full overflow-hidden transition-all duration-300 ease-in-out hover:shadow-xl hover:scale-[1.02]",
      isTenantActive && property.status === 'rented' && "bg-green-100 dark:bg-green-900/30",
      hasTenantDeparted && "bg-gray-100 dark:bg-gray-800/30"
    )}>
      <CardHeader className="p-4 border-b">
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-1">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    {property.type === 'commercial' ? <Store className="h-4 w-4" /> : <Home className="h-4 w-4" />}
                    <span className="sr-only">نوع العقار</span>
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>{property.type === 'commercial' ? 'تجاري' : 'سكني'}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
           {tenant && showNotification && isTenantActive && (
             <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 relative text-yellow-500">
                        <Bell className="h-4 w-4" />
                        <span className="absolute top-1 right-1 flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-destructive"></span>
                        </span>
                        <span className="sr-only">تنبيهات</span>
                    </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                    <p>العقد سينتهي قريباً!</p>
                    </TooltipContent>
                </Tooltip>
            </TooltipProvider>
           )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="h-4 w-4" />
                  <span className="sr-only">المزيد من الخيارات</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleCardClick}>
                  <Info className="me-2 h-4 w-4" />
                  عرض التفاصيل
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => handleChangePropertyStatus('rented')}
                  disabled={property.status === 'rented' && isTenantActive}
                >
                  <CheckCircle className="me-2 h-4 w-4 text-green-500" />
                  المحل مؤجر
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={handleMarkAsDeparted}
                  disabled={!tenant || !isTenantActive}
                >
                  <LogOut className="me-2 h-4 w-4 text-red-500" />
                  تسجيل مغادرة المستأجر
                </DropdownMenuItem>
                 <DropdownMenuItem
                  onClick={() => handleChangePropertyStatus('vacant')}
                  disabled={isPropertyVacant || (tenant && !isTenantActive && property.status === 'vacant')}
                 >
                  <Store className="me-2 h-4 w-4 text-orange-500" />
                  المحل شاغر
                </DropdownMenuItem>
                 <DropdownMenuItem
                  onClick={() => handleChangePropertyStatus('maintenance')}
                  disabled={isPropertyMaintenance}
                 >

                  <Info className="me-2 h-4 w-4 text-blue-500" />
                  تحت الصيانة
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="flex-grow cursor-pointer text-right" onClick={handleCardClick}>
            <CardTitle className="text-lg font-semibold truncate" title={property.name}>
              {property.name}
            </CardTitle>
            {tenant && (
              <CardDescription className="text-sm truncate" title={tenant.tenantName}>
                {tenant.tenantName}
              </CardDescription>
            )}
            {tenant && contractEndDateObj && (
              <div className="text-xs text-muted-foreground mt-1">
                <div className="flex items-center justify-end">
                  <span className={cn(
                      "truncate",
                      isEndingSoon && isTenantActive && "text-destructive font-semibold"
                    )}
                  >
                    {isPast(contractEndDateObj) ? 'انتهى في: ' : 'ينتهي في: '} {displayContractEndDate}
                  </span>
                  <CalendarDays className="h-3 w-3 ms-1.5 flex-shrink-0" />
                </div>
                <div className="flex items-center justify-end mt-0.5">
                  <span className="truncate">
                    الإيجار الأساسي: {tenant.contractValue.toLocaleString('ar-SA')} ريال
                  </span>
                  <Wallet className="h-3 w-3 ms-1.5 flex-shrink-0" />
                </div>
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 flex-grow cursor-pointer" onClick={handleCardClick}>
        {tenant ? (
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">إجمالي العقد (مع الضريبة):</span>
              <span className="font-semibold">{totalWithTaxForTenant.toLocaleString('ar-SA')} ريال</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">إجمالي المدفوعات:</span>
              <span className="font-medium text-green-600">{totalPaidByTenant.toLocaleString('ar-SA')} ريال</span>
            </div>
             <div className="flex justify-between mt-2 pt-2 border-t">
              <span className="text-muted-foreground">الرصيد المتبقي من العقد:</span>
              <Badge variant={balanceForTenant === 0 ? "default" : (balanceForTenant < 0 ? "secondary" : "destructive")} className={balanceForTenant === 0 ? "bg-green-500 hover:bg-green-600": ""}>
                {Math.abs(balanceForTenant).toLocaleString('ar-SA')} ريال {balanceForTenant < 0 ? "(سداد إضافي)" : balanceForTenant > 0 ? "(مستحق)" : ""}
              </Badge>
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-8">العقار شاغر حالياً</p>
        )}
      </CardContent>
      <CardFooter className="p-3 border-t bg-muted/30">
         <Button variant="outline" size="sm" className="w-full" onClick={handleCardClick}>
            <Info className="me-2 h-4 w-4" />
            عرض التفاصيل الكاملة
          </Button>
      </CardFooter>
    </Card>
  );
}

