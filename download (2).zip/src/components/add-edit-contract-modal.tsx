
'use client';

import type { Tenant, RentType, TaxRate, NumberOfInstallments } from '@/types';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Loader2, Eye, Printer, FileText as FileTextIconLucide, FileSpreadsheet, Share2, CalendarIcon, TrendingUp } from 'lucide-react';
import { format, parse, parseISO, isValid, getYear, subYears, addYears, intervalToDuration, differenceInCalendarMonths } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { RENT_PAYMENT_CYCLE_OPTIONS, TAX_RATES, RENT_TYPES, getLabelForValue as getConstantLabel, getNumberOfInstallmentsLabel } from '@/lib/constants';
import { useState, useEffect, useMemo } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Textarea } from './ui/textarea';
import { cn } from '@/lib/utils';

const contractFormSchema = z.object({
  tenantName: z.string().min(3, { message: 'اسم المستأجر يجب أن لا يقل عن 3 أحرف.' }),
  contractIdentifier: z.string().min(1, { message: 'رقم العقد مطلوب.' }),
  tenantPhoneNumber: z.string().optional(),
  tenantEmail: z.string().email({ message: "البريد الإلكتروني غير صالح." }).optional().or(z.literal('')),
  tenantAddress: z.string().optional(),
  contractStartDate: z.date({ required_error: 'تاريخ بداية العقد مطلوب.' })
    .refine(d => d && !isNaN(d.getTime()), { message: "تاريخ بداية العقد غير صالح." }),
  contractEndDate: z.date({ required_error: 'تاريخ نهاية العقد مطلوب.' })
    .refine(d => d && !isNaN(d.getTime()), { message: "تاريخ نهاية العقد غير صالح." }),
  contractValue: z.coerce.number().positive({ message: 'قيمة العقد السنوية (قبل الضريبة) يجب أن تكون رقمًا موجبًا.' }),
  rentType: z.custom<RentType>((val) => RENT_TYPES.some(rt => rt.value === val), { message: 'نوع الإيجار مطلوب.' }),
  taxRate: z.coerce.number().min(0).max(100, { message: 'نسبة الضريبة يجب أن تكون بين 0 و 100.' }) as z.ZodType<TaxRate>,
  numberOfInstallments: z.coerce.number().min(1).max(30).default(1) as z.ZodType<NumberOfInstallments>,
}).superRefine((data, ctx) => {
  if (data.contractStartDate && data.contractEndDate && isValid(data.contractStartDate) && isValid(data.contractEndDate) && data.contractEndDate < data.contractStartDate) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'تاريخ نهاية العقد يجب أن يكون بعد تاريخ البداية.',
      path: ['contractEndDate'],
    });
  }
});

export type ContractFormValues = z.infer<typeof contractFormSchema>;

interface AddEditContractModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: ContractFormValues) => Promise<void>;
  initialData?: Tenant | null;
  propertyId: string;
}

export function AddEditContractModal({ isOpen, onClose, onSubmit, initialData, propertyId }: AddEditContractModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const [isStartDateCalendarOpen, setIsStartDateCalendarOpen] = useState(false);
  const [isEndDateCalendarOpen, setIsEndDateCalendarOpen] = useState(false);

  const derivedDefaultValues = useMemo(() => {
    const defaultStartDate = new Date();
    const defaultEndDate = addYears(new Date(), 1);
    return initialData
      ? {
          ...initialData,
          contractIdentifier: initialData.contractIdentifier || '',
          tenantPhoneNumber: initialData.tenantPhoneNumber || '',
          tenantEmail: initialData.tenantEmail || '',
          tenantAddress: initialData.tenantAddress || '',
          contractStartDate: initialData.contractStartDate && isValid(parseISO(initialData.contractStartDate)) ? parseISO(initialData.contractStartDate) : defaultStartDate,
          contractEndDate: initialData.contractEndDate && isValid(parseISO(initialData.contractEndDate)) ? parseISO(initialData.contractEndDate) : defaultEndDate,
          contractValue: initialData.contractValue || 0,
          rentType: initialData.rentType || 'annual',
          taxRate: initialData.taxRate || 0,
          numberOfInstallments: initialData.numberOfInstallments || 1,
        }
      : {
          tenantName: '',
          contractIdentifier: '',
          tenantPhoneNumber: '',
          tenantEmail: '',
          tenantAddress: '',
          contractStartDate: defaultStartDate,
          contractEndDate: defaultEndDate,
          contractValue: 0,
          rentType: 'annual' as RentType,
          taxRate: 0 as TaxRate,
          numberOfInstallments: 1 as NumberOfInstallments,
        };
  }, [initialData]);

  const form = useForm<ContractFormValues>({
    resolver: zodResolver(contractFormSchema),
    defaultValues: derivedDefaultValues,
  });

  useEffect(() => {
    if (isOpen) {
      form.reset(derivedDefaultValues);
      setIsStartDateCalendarOpen(false);
      setIsEndDateCalendarOpen(false);
    }
  }, [isOpen, derivedDefaultValues, form]);

  const watchedContractValue = form.watch('contractValue');
  const watchedTaxRate = form.watch('taxRate');
  const watchedRentType = form.watch('rentType');
  const watchedStartDate = form.watch('contractStartDate');
  const watchedEndDate = form.watch('contractEndDate');
  const watchedNumberOfInstallments = form.watch('numberOfInstallments');

  const contractDuration = useMemo(() => {
    let years = 0, months = 0, days = 0;
    if (watchedStartDate && watchedEndDate && isValid(watchedStartDate) && isValid(watchedEndDate) && watchedEndDate >= watchedStartDate) {
      const duration = intervalToDuration({ start: watchedStartDate, end: watchedEndDate });
      years = duration.years || 0;
      months = duration.months || 0;
      days = duration.days || 0;
    }
    return { years, months, days };
  }, [watchedStartDate, watchedEndDate]);

  const calculatedMonthlyValueBeforeTax = useMemo(() => {
    if (watchedRentType === 'monthly') {
      return (Number(watchedContractValue) || 0) / 12;
    }
    return 0;
  }, [watchedRentType, watchedContractValue]);

  const totalWithTaxDisplay = useMemo(() => {
    const annualContractVal = Number(watchedContractValue) || 0;
    const taxRateVal = Number(watchedTaxRate) || 0;
    const taxMultiplier = 1 + taxRateVal / 100;

    if (watchedRentType === 'monthly') {
      const monthlyPreTax = annualContractVal / 12;
      return {
        label: "الإجمالي الشهري مع الضريبة",
        value: monthlyPreTax * taxMultiplier
      };
    } else {
      return {
        label: "الإجمالي السنوي مع الضريبة",
        value: annualContractVal * taxMultiplier
      };
    }
  }, [watchedContractValue, watchedTaxRate, watchedRentType]);
  
  const totalPeriodValueDisplay = useMemo(() => {
    if (watchedStartDate && watchedEndDate && isValid(watchedStartDate) && isValid(watchedEndDate) && watchedEndDate >= watchedStartDate) {
        const annualPreTaxRentLocal = Number(watchedContractValue) || 0;
        const taxRatePercentage = (Number(watchedTaxRate) || 0) / 100;

        const duration = intervalToDuration({ start: watchedStartDate, end: watchedEndDate });
        const years = duration.years || 0;
        const months = duration.months || 0;
        const days = duration.days || 0;
        
        const valueForYears = annualPreTaxRentLocal * years;
        const valueForMonths = (annualPreTaxRentLocal / 12) * months;
        const valueForDays = (annualPreTaxRentLocal / 365.25) * days; 
        
        const totalPreTaxValueForExactPeriod = valueForYears + valueForMonths + valueForDays;
        return parseFloat(((totalPreTaxValueForExactPeriod) * (1 + taxRatePercentage)).toFixed(2));
    }
    return 0;
  }, [watchedStartDate, watchedEndDate, watchedContractValue, watchedTaxRate]);


  const handleSubmit: SubmitHandler<ContractFormValues> = async (data) => {
    setIsSubmitting(true);
    await onSubmit(data);
    setIsSubmitting(false);
  };

  const handlePlaceholderAction = (actionName: string) => {
    toast({
      title: "إجراء غير متوفر",
      description: `ميزة "${actionName}" غير متوفرة حاليًا.`,
      variant: "default",
    });
  };

  const currentYear = getYear(new Date());
  const fromYear = subYears(new Date(), 10).getFullYear();
  const toYear = addYears(new Date(), 10).getFullYear();


  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) {
        onClose();
      }
    }}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{initialData ? 'تعديل بيانات العقد' : 'إضافة عقد جديد'}</DialogTitle>
          <DialogDescription>
            {initialData ? `تحديث معلومات عقد المستأجر ${initialData.tenantName}.` : `إضافة عقد جديد للعقار.`}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-2 max-h-[70vh] overflow-y-auto px-1">
            <FormField
              control={form.control}
              name="tenantName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>اسم المستأجر</FormLabel>
                  <FormControl>
                    <Input placeholder="مثال: خالد الأحمدي" {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="contractIdentifier"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>رقم العقد</FormLabel>
                  <FormControl>
                    <Input placeholder="مثال: C-2024-001" {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4">
              <FormField
                control={form.control}
                name="tenantPhoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>رقم هاتف المستأجر</FormLabel>
                    <FormControl>
                      <Input type="tel" placeholder="مثال: 0501234567" {...field} className="bg-card" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="tenantEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>البريد الإلكتروني للمستأجر</FormLabel>
                    <FormControl>
                      <Input type="email" placeholder="مثال: tenant@example.com" {...field} className="bg-card" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="tenantAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>عنوان المستأجر</FormLabel>
                  <FormControl>
                    <Textarea placeholder="مثال: حي النخيل، شارع الأمير محمد، مبنى 5، شقة 10" {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-4">
              <FormField
                control={form.control}
                name="contractStartDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>تاريخ بداية العقد</FormLabel>
                    <Popover open={isStartDateCalendarOpen} onOpenChange={setIsStartDateCalendarOpen}>
                      <PopoverTrigger asChild>
                        <div className="relative">
                          <Input
                            placeholder="YYYY-MM-DD"
                            value={field.value ? format(field.value, 'yyyy-MM-dd') : ''}
                            onChange={(e) => {
                              const dateString = e.target.value;
                              try {
                                const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                                if (isValid(parsedDate)) {
                                  field.onChange(parsedDate);
                                } else if (dateString === '') {
                                  field.onChange(undefined);
                                }
                              } catch {
                                field.onChange(undefined);
                              }
                            }}
                            className="pe-10 text-center bg-card"
                          />
                          <CalendarIcon
                            className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                            aria-label="فتح التقويم"
                            onClick={() => setIsStartDateCalendarOpen(prev => !prev)}
                          />
                        </div>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={(date) => { 
                            field.onChange(date); 
                            setIsStartDateCalendarOpen(false); 
                          }}
                          captionLayout="dropdown-buttons"
                          fromYear={fromYear}
                          toYear={toYear}
                          defaultMonth={field.value || new Date()}
                          initialFocus
                          dir="rtl"
                          locale={arSA}
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="contractEndDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>تاريخ نهاية العقد</FormLabel>
                    <Popover open={isEndDateCalendarOpen} onOpenChange={setIsEndDateCalendarOpen}>
                      <PopoverTrigger asChild>
                        <div className="relative">
                          <Input
                            placeholder="YYYY-MM-DD"
                            value={field.value ? format(field.value, 'yyyy-MM-dd') : ''}
                            onChange={(e) => {
                              const dateString = e.target.value;
                              try {
                                const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                                if (isValid(parsedDate)) {
                                  field.onChange(parsedDate);
                                } else if (dateString === '') {
                                  field.onChange(undefined);
                                }
                              } catch {
                                field.onChange(undefined);
                              }
                            }}
                            className="pe-10 text-center bg-card"
                          />
                          <CalendarIcon
                            className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                            aria-label="فتح التقويم"
                            onClick={() => setIsEndDateCalendarOpen(prev => !prev)}
                          />
                        </div>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={(date) => { 
                            field.onChange(date); 
                            setIsEndDateCalendarOpen(false); 
                          }}
                          captionLayout="dropdown-buttons"
                          fromYear={fromYear}
                          toYear={toYear}
                          defaultMonth={field.value || form.getValues("contractStartDate") || new Date()}
                          initialFocus
                          dir="rtl"
                          locale={arSA}
                          disabled={(date) =>
                            form.getValues("contractStartDate") && isValid(form.getValues("contractStartDate")) && date < form.getValues("contractStartDate")
                          }
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-4 gap-y-4">
                <FormItem>
                    <FormLabel>عدد سنوات العقد</FormLabel>
                    <Input
                        type="text"
                        value={`${contractDuration.years} سنة`}
                        readOnly
                        className="bg-muted/50 cursor-default text-center"
                        aria-label="عدد سنوات العقد"
                    />
                </FormItem>
                <FormItem>
                    <FormLabel>عدد أشهر العقد</FormLabel>
                    <Input
                        type="text"
                        value={`${contractDuration.months} شهر`}
                        readOnly
                        className="bg-muted/50 cursor-default text-center"
                        aria-label="عدد أشهر العقد"
                    />
                </FormItem>
                <FormItem>
                    <FormLabel>عدد أيام العقد</FormLabel>
                    <Input
                        type="text"
                        value={`${contractDuration.days} يوم`}
                        readOnly
                        className="bg-muted/50 cursor-default text-center"
                        aria-label="عدد أيام العقد"
                    />
                </FormItem>
            </div>

            <FormField
              control={form.control}
              name="contractValue"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>قيمة العقد السنوية (قبل الضريبة)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="مثال: 60000" {...field} onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-4 gap-y-4">
               <FormField
                control={form.control}
                name="taxRate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نسبة الضريبة</FormLabel>
                    <Select onValueChange={(value) => field.onChange(Number(value) as TaxRate)} value={String(field.value)}>
                      <FormControl>
                        <SelectTrigger className="bg-card"><SelectValue placeholder="اختر نسبة الضريبة" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {TAX_RATES.map(rate => <SelectItem key={rate.value} value={String(rate.value)}>{rate.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
               <FormField
                control={form.control}
                name="rentType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>نوع الإيجار</FormLabel>
                    <Select 
                      onValueChange={(value) => {
                        const newRentType = value as RentType;
                        field.onChange(newRentType);
                        if (newRentType === 'monthly') {
                          form.setValue('numberOfInstallments', 12 as NumberOfInstallments, { shouldValidate: true });
                        } else if (newRentType === 'annual' && form.getValues('numberOfInstallments') === 12) {
                          form.setValue('numberOfInstallments', 1 as NumberOfInstallments, { shouldValidate: true });
                        }
                      }} 
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger className="bg-card"><SelectValue placeholder="اختر نوع الإيجار" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {RENT_TYPES.map(type => <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="numberOfInstallments"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>دورة سداد الايجار</FormLabel>
                    <Select
                      onValueChange={(value) => {
                          const numValue = Number(value) as NumberOfInstallments;
                          field.onChange(numValue);
                          if (numValue === 12) { 
                            form.setValue('rentType', 'monthly', { shouldValidate: true });
                          } else if (form.getValues('rentType') === 'monthly' && numValue !== 12) {
                            form.setValue('rentType', 'annual', { shouldValidate: true });
                          }
                        }}
                      value={String(field.value)}
                    >
                      <FormControl>
                        <SelectTrigger className="bg-card">
                          <SelectValue placeholder="اختر دورة السداد" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {RENT_PAYMENT_CYCLE_OPTIONS.map(option => (
                          <SelectItem key={option.value} value={String(option.value)}>{option.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
                
            {watchedRentType === 'monthly' && (
                  <FormItem>
                    <FormLabel>القيمة الشهرية (محسوبة, قبل الضريبة)</FormLabel>
                    <FormControl>
                    <Input
                        type="text"
                        value={`${(calculatedMonthlyValueBeforeTax).toLocaleString('ar-SA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ريال`}
                        readOnly
                        className="bg-muted/50 cursor-default text-center"
                        aria-label="القيمة الشهرية (محسوبة, قبل الضريبة)"
                    />
                    </FormControl>
                </FormItem>
            )}
            
            <FormItem>
                <FormLabel>{totalWithTaxDisplay.label}</FormLabel>
                <FormControl>
                <Input
                    type="text"
                    value={`${totalWithTaxDisplay.value.toLocaleString('ar-SA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ريال`}
                    readOnly
                    className="bg-muted/50 cursor-default text-center"
                    aria-label={totalWithTaxDisplay.label}
                />
                </FormControl>
            </FormItem>

             <FormItem>
                <FormLabel>اجمالي الفتره (مع الضريبة)</FormLabel>
                <FormControl>
                <Input
                    type="text"
                    value={`${totalPeriodValueDisplay.toLocaleString('ar-SA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ريال`}
                    readOnly
                    className="bg-muted/50 cursor-default text-center"
                    aria-label="اجمالي الفتره (مع الضريبة)"
                />
                </FormControl>
            </FormItem>

            <DialogFooter className="pt-4 flex flex-col sm:flex-row sm:justify-between items-center">
              <TooltipProvider>
                <div className="flex gap-1 mb-4 sm:mb-0 order-2 sm:order-1">
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button type="button" variant="outline" size="icon" onClick={() => handlePlaceholderAction('معاينة العقد/التقرير')}>
                                <Eye className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>معاينة العقد/التقرير</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button type="button" variant="outline" size="icon" onClick={() => handlePlaceholderAction('طباعة العقد/التقرير')}>
                                <Printer className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>طباعة العقد/التقرير</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                        <TooltipTrigger asChild>
                             <Button type="button" variant="outline" size="icon" onClick={() => handlePlaceholderAction('تحويل إلى PDF')}>
                                <FileTextIconLucide className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>تحويل إلى PDF</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button type="button" variant="outline" size="icon" onClick={() => handlePlaceholderAction('تحويل إلى Excel')}>
                                <FileSpreadsheet className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>تحويل إلى Excel</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button type="button" variant="outline" size="icon" onClick={() => handlePlaceholderAction('مشاركة العقد')}>
                                <Share2 className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>مشاركة العقد</p></TooltipContent>
                    </Tooltip>
                </div>
              </TooltipProvider>
              <div className="flex gap-2 order-1 sm:order-2">
                <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                  إلغاء
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                  {initialData ? 'حفظ التغييرات' : 'إضافة العقد'}
                </Button>
              </div>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}

