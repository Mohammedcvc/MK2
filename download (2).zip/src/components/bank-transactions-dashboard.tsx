
'use client';

import type { BankTransaction, Attachment } from '@/types';
import { useAppContext } from '@/contexts/app-context';
import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { BankTransactionsTable } from '@/components/bank-transactions-table';
import { AddEditBankTransactionModal, BankTransactionFormValues } from '@/components/add-edit-bank-transaction-modal';
import { DeleteBankTransactionDialog } from '@/components/delete-bank-transaction-dialog';
import { BankTransactionReportModal } from '@/components/bank-transaction-report-modal';
import { useToast } from '@/hooks/use-toast';
import { PlusCircle, Sigma, FileText, Landmark, User, Clock } from 'lucide-react';
import { format } from 'date-fns';

export function BankTransactionsDashboard() {
  const { bankTransactions, setBankTransactions, currentUser } = useAppContext();
  const { toast } = useToast();

  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<BankTransaction | null>(null);
  const [isDeleteDialogVisible, setIsDeleteDialogVisible] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState<BankTransaction | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  const canEditTransactions = currentUser?.permissions?.canEdit ?? false;
  const canAddTransactions = currentUser?.permissions?.canAdd ?? false;
  const canDeleteTransactions = currentUser?.permissions?.canDelete ?? false;

  const openAddTransactionModal = () => {
    if (!canAddTransactions) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية إضافة عمليات بنكية.", variant: "destructive"});
      return;
    }
    setEditingTransaction(null);
    setIsAddEditModalOpen(true);
  };

  const openEditTransactionModal = (transaction: BankTransaction) => {
    if (!canEditTransactions) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية تعديل العمليات البنكية.", variant: "destructive"});
      return;
    }
    setEditingTransaction(transaction);
    setIsAddEditModalOpen(true);
  };

  const openDeleteTransactionDialog = (transaction: BankTransaction) => {
    if (!canDeleteTransactions) {
        toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف العمليات البنكية.", variant: "destructive"});
        return;
    }
    setTransactionToDelete(transaction);
    setIsDeleteDialogVisible(true);
  };

  const closeModals = () => {
    setIsAddEditModalOpen(false);
    setEditingTransaction(null);
    setIsDeleteDialogVisible(false);
    setTransactionToDelete(null);
    setIsReportModalOpen(false);
  };

  const handleSaveTransaction = async (data: BankTransactionFormValues, transactionIdToUpdate?: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();

    if (transactionIdToUpdate) {
      setBankTransactions(prevTransactions =>
        prevTransactions.map(t =>
          t.id === transactionIdToUpdate
            ? { ...t, ...data, date: format(data.date, 'yyyy-MM-dd'), lastModifiedBy: modifierUsername, lastModifiedAt: modificationTimestamp }
            : t
        )
      );
      toast({ title: "تم تعديل العملية البنكية", description: `تم تحديث بيانات العملية "${data.description}".` });
    } else {
      const newTransaction: BankTransaction = {
        id: `bank_trans_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        ...data,
        date: format(data.date, 'yyyy-MM-dd'),
        attachments: [],
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
      };
      setBankTransactions(prevTransactions => [...prevTransactions, newTransaction]);
      toast({ title: "تمت إضافة عملية بنكية", description: `تمت إضافة عملية جديدة ببيان "${data.description}".` });
    }
    closeModals();
  };

  const handleConfirmDeleteTransaction = async () => {
    if (!canDeleteTransactions) {
        toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف العمليات البنكية.", variant: "destructive"});
        closeModals();
        return;
    }
    await new Promise(resolve => setTimeout(resolve, 500));
    if (transactionToDelete) {
      setBankTransactions(prevTransactions => prevTransactions.filter(t => t.id !== transactionToDelete.id));
      toast({ title: "تم حذف العملية البنكية", description: `تم حذف العملية "${transactionToDelete.description}" بشكل دائم.`, variant: "destructive" });
    }
    closeModals();
  };

  const handleAddAttachment = async (transactionId: string, file: File) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const newAttachment: Attachment = {
      name: file.name,
      url: `#mock-url-for-${file.name}`,
    };
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();

    setBankTransactions(prevTransactions =>
      prevTransactions.map(t => {
        if (t.id === transactionId) {
          return {
            ...t,
            attachments: [...(t.attachments || []), newAttachment],
            lastModifiedBy: modifierUsername,
            lastModifiedAt: modificationTimestamp,
          };
        }
        return t;
      })
    );
    toast({ title: "تم إرفاق الملف للعملية البنكية", description: `تم إرفاق "${file.name}" بنجاح.` });
  };

  const handleDeleteAttachment = async (transactionId: string, attachmentName: string) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();
    setBankTransactions(prevTransactions =>
      prevTransactions.map(t => {
        if (t.id === transactionId) {
          return {
            ...t,
            attachments: t.attachments?.filter(att => att.name !== attachmentName) || [],
            lastModifiedBy: modifierUsername,
            lastModifiedAt: modificationTimestamp,
          };
        }
        return t;
      })
    );
    toast({ title: "تم حذف المرفق من العملية البنكية", description: `تم حذف المرفق "${attachmentName}".`, variant: "destructive" });
  };

  const totals = useMemo(() => {
    const totalIncoming = bankTransactions.reduce((sum, t) => sum + (t.amountIncoming || 0), 0);
    const totalOutgoing = bankTransactions.reduce((sum, t) => sum + (t.amountOutgoing || 0), 0);
    const netBalance = totalIncoming - totalOutgoing;
    return { totalIncoming, totalOutgoing, netBalance };
  }, [bankTransactions]);

  const handleViewReport = () => {
    if (bankTransactions.length === 0) {
      toast({
        title: "لا توجد عمليات بنكية",
        description: "لا يمكن إنشاء تقرير لأنه لا توجد عمليات بنكية مسجلة.",
        variant: "default"
      });
      return;
    }
    setIsReportModalOpen(true);
  };

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg flex items-center"><Landmark className="me-3 h-7 w-7 text-primary"/>إدارة العمليات البنكية للورثة</CardTitle>
            <CardDescription className="text-sm font-semibold">عرض وإدارة العمليات البنكية الواردة والصادرة المتعلقة بالورثة.</CardDescription>
          </div>
          <div className="flex flex-wrap gap-2 items-center">
            <Button onClick={openAddTransactionModal} size="sm" disabled={!canAddTransactions}>
              <PlusCircle className="me-2 h-4 w-4" />
              إضافة عملية بنكية
            </Button>
            <Button onClick={handleViewReport} variant="outline" size="sm">
              <FileText className="me-2 h-4 w-4" />
              عرض تقرير العمليات
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <BankTransactionsTable
            transactions={bankTransactions}
            onEditTransaction={openEditTransactionModal}
            onDeleteTransaction={openDeleteTransactionDialog}
            onAddAttachment={handleAddAttachment}
            onDeleteAttachment={handleDeleteAttachment}
            canEdit={canEditTransactions}
            canDelete={canDeleteTransactions}
            />
      </CardContent>
      <CardFooter className="border-t p-6">
        <div className="flex flex-col md:flex-row items-start md:items-center w-full justify-between gap-4">
            <div className="flex items-center text-lg font-semibold">
                <Sigma className="me-2 h-5 w-5 text-primary" />
                <span>إجمالي العمليات:</span>
            </div>
            <div className="space-y-1 text-sm md:text-right">
                <p>إجمالي الوارد: <span className="font-bold text-green-600">{totals.totalIncoming.toLocaleString()} ريال</span></p>
                <p>إجمالي الصادر: <span className="font-bold text-destructive">{totals.totalOutgoing.toLocaleString()} ريال</span></p>
                <p className="text-md font-semibold">الرصيد الصافي: <span className={totals.netBalance >= 0 ? 'text-primary' : 'text-destructive'}>{totals.netBalance.toLocaleString()} ريال</span></p>
            </div>
        </div>
      </CardFooter>

      <AddEditBankTransactionModal
        isOpen={isAddEditModalOpen}
        onClose={closeModals}
        onSubmit={handleSaveTransaction}
        initialData={editingTransaction}
      />

      <DeleteBankTransactionDialog
        isOpen={isDeleteDialogVisible}
        onClose={closeModals}
        onConfirm={handleConfirmDeleteTransaction}
        transactionDescription={transactionToDelete?.description}
      />

      <BankTransactionReportModal
        isOpen={isReportModalOpen}
        onClose={closeModals}
        transactions={bankTransactions}
      />
    </Card>
  );
}
