
'use client';

import { useState, useEffect } from 'react';
import type { Property, PropertyType as PropertyTypeEnum, PropertyStatus, Owner } from '@/types';
import { Button } from '@/components/ui/button';
import { PlusCircle, Edit, Trash2, Eye, Search, LayoutGrid, List, ChevronDown, ChevronUp, User, Clock, UsersRound } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import Image from 'next/image';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { PROPERTY_STATUS_BADGE_CONFIG, getLabelForValue, PROPERTY_TYPES, PROPERTY_STATUSES } from '@/lib/constants';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from '@/lib/utils';
import { useAppContext } from '@/contexts/app-context';
import { Form, FormControl, FormField, FormItem, FormMessage } from '@/components/ui/form';
import { format, parseISO } from 'date-fns';
import { arSA } from 'date-fns/locale';


const propertyFormSchema = z.object({
  name: z.string().min(3, { message: 'اسم العقار يجب أن لا يقل عن 3 أحرف.' }),
  address: z.string().min(5, { message: 'عنوان العقار يجب أن لا يقل عن 5 أحرف.' }),
  type: z.custom<PropertyTypeEnum>((val) => PROPERTY_TYPES.some(pt => pt.value === val),{ message: 'نوع العقار مطلوب.' }),
  status: z.custom<PropertyStatus>((val) => PROPERTY_STATUSES.some(ps => ps.value === val),{ message: 'حالة العقار مطلوبة.' }),
  ownerId: z.string().optional(),
});

export type PropertyFormValues = z.infer<typeof propertyFormSchema>;

interface PropertyFormProps {
  onSubmit: (data: PropertyFormValues) => void;
  initialData?: Partial<PropertyFormValues>;
  onCancel: () => void;
  submitButtonText?: string;
  owners: Owner[];
}

function PropertyForm({ onSubmit, initialData, onCancel, submitButtonText = "حفظ", owners }: PropertyFormProps) {
  const form = useForm<PropertyFormValues>({
    resolver: zodResolver(propertyFormSchema),
    defaultValues: initialData || { name: '', address: '', type: 'commercial', status: 'vacant', ownerId: '' },
  });

  useEffect(() => {
    form.reset(initialData || { name: '', address: '', type: 'commercial', status: 'vacant', ownerId: '' });
  }, [initialData, form]);


  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <Label htmlFor="name-form">اسم العقار</Label>
              <FormControl>
                <Input id="name-form" {...field} className="bg-card" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="address"
          render={({ field }) => (
            <FormItem>
              <Label htmlFor="address-form">العنوان</Label>
              <FormControl>
                <Input id="address-form" {...field} className="bg-card" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
         <FormField
          control={form.control}
          name="type"
          render={({ field }) => (
            <FormItem>
              <Label htmlFor="type-form">نوع العقار</Label>
               <Select onValueChange={field.onChange} value={field.value} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger id="type-form" className="bg-card">
                    <SelectValue placeholder="اختر نوع العقار" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {PROPERTY_TYPES.map(pt => (
                    <SelectItem key={pt.value} value={pt.value}>{pt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="status"
          render={({ field }) => (
            <FormItem>
              <Label htmlFor="status-form">حالة العقار</Label>
              <Select onValueChange={field.onChange} value={field.value} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger id="status-form" className="bg-card">
                    <SelectValue placeholder="اختر حالة العقار" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {PROPERTY_STATUSES.map(ps => (
                    <SelectItem key={ps.value} value={ps.value}>{ps.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name="ownerId"
          render={({ field }) => (
            <FormItem>
              <Label htmlFor="ownerId-form">المالك (اختياري)</Label>
              <Select onValueChange={field.onChange} value={field.value || ""} defaultValue={field.value || ""}>
                <FormControl>
                  <SelectTrigger id="ownerId-form" className="bg-card">
                    <SelectValue placeholder="اختر المالك (إن وجد)" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value=""><em>لا يوجد مالك محدد</em></SelectItem>
                  {owners.map(owner => (
                    <SelectItem key={owner.id} value={owner.id}>
                      {owner.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <div className="flex justify-end gap-2 pt-4">
          <Button type="button" variant="outline" onClick={onCancel}>إلغاء</Button>
          <Button type="submit">{submitButtonText}</Button>
        </div>
      </form>
    </Form>
  );
}

interface PropertyCardProps {
  property: Property;
  onEdit: () => void;
  onDelete: () => void;
  onViewDetails: () => void;
  canEdit?: boolean;
  canDelete?: boolean;
  owners: Owner[];
}

function PropertyCard({ property, onEdit, onDelete, onViewDetails, canEdit, canDelete, owners }: PropertyCardProps) {
  const badgeConfig = PROPERTY_STATUS_BADGE_CONFIG[property.status];
  const [isFooterExpanded, setIsFooterExpanded] = useState(false);
  const owner = owners.find(o => o.id === property.ownerId);

  const formatTimestamp = (isoString?: string) => {
    if (!isoString) return '-';
    try {
      return format(parseISO(isoString), 'yyyy/MM/dd HH:mm', { locale: arSA });
    } catch (e) {
      return 'تاريخ خاطئ';
    }
  };

  return (
    <Card className="overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 flex flex-col rounded-lg">
      <div className="relative w-full h-36 sm:h-40 md:h-48 cursor-pointer group" onClick={onViewDetails}>
        <Image
          src={property.imageUrl || `https://placehold.co/400x300.png`}
          alt={property.name}
          fill
          sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
          className="object-cover group-hover:scale-105 transition-transform duration-300"
          data-ai-hint="real estate property"
          priority={false}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/20 to-transparent group-hover:from-black/60 transition-colors"></div>
        <Badge variant={badgeConfig.variant} className={cn("absolute top-2 right-2 text-xs px-2 py-1", badgeConfig.className)}>
          {getLabelForValue(PROPERTY_STATUSES, property.status)}
        </Badge>
        <div className="absolute bottom-2 left-2 right-2 p-2">
          <CardTitle className="text-md md:text-lg truncate text-white" title={property.name}>{property.name}</CardTitle>
          <CardDescription className="text-xs truncate text-gray-200" title={property.address}>{property.address}</CardDescription>
        </div>
      </div>
      <CardFooter 
        className={cn(
            "p-2 border-t bg-muted/30 flex flex-col items-stretch transition-all duration-300 ease-in-out",
            isFooterExpanded ? "max-h-72" : "max-h-12 overflow-hidden" // Increased max-h for owner info
        )}
      >
        <div className="flex flex-row justify-between items-center w-full">
            <Button variant="ghost" size="sm" onClick={() => setIsFooterExpanded(!isFooterExpanded)} className="text-muted-foreground hover:text-foreground px-2 py-1 h-auto">
                {isFooterExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                <span className="sr-only">{isFooterExpanded ? "طي التفاصيل" : "عرض التفاصيل"}</span>
            </Button>
            <div className="flex gap-1">
                 <TooltipProvider>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" onClick={onViewDetails} className="text-primary hover:text-primary/80 h-7 w-7">
                                <Eye className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>عرض التفاصيل</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" onClick={onEdit} disabled={!canEdit} className="text-blue-600 hover:text-blue-700 h-7 w-7">
                                <Edit className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>{!canEdit ? "لا تملك صلاحية التعديل" : "تعديل"}</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" onClick={onDelete} disabled={!canDelete} className="text-destructive hover:text-destructive/80 h-7 w-7">
                                <Trash2 className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف"}</p></TooltipContent>
                    </Tooltip>
                </TooltipProvider>
            </div>
        </div>
        {isFooterExpanded && (
            <div className="mt-2 pt-2 border-t text-xs space-y-1 text-muted-foreground w-full">
                <p><span className="font-medium text-foreground">النوع:</span> {getLabelForValue(PROPERTY_TYPES, property.type)}</p>
                <p><span className="font-medium text-foreground">الحالة:</span> {getLabelForValue(PROPERTY_STATUSES, property.status)}</p>
                {owner && <p><UsersRound className="h-3 w-3 me-1 inline-block" /><span className="font-medium text-foreground">المالك:</span> {owner.name}</p>}
                {property.lastModifiedBy && (
                  <p className="flex items-center"><User className="h-3 w-3 me-1" /> <span className="font-medium text-foreground">آخر تعديل بواسطة:</span> {property.lastModifiedBy}</p>
                )}
                {property.lastModifiedAt && (
                  <p className="flex items-center"><Clock className="h-3 w-3 me-1" /> <span className="font-medium text-foreground">وقت التعديل:</span> {formatTimestamp(property.lastModifiedAt)}</p>
                )}
            </div>
        )}
      </CardFooter>
    </Card>
  );
}

interface PropertyTableProps {
  properties: Property[];
  onEditProperty: (property: Property) => void;
  onDeleteProperty: (property: Property) => void;
  onViewDetails: (property: Property) => void;
  canEdit?: boolean;
  canDelete?: boolean;
  owners: Owner[];
}

function PropertyTable({ properties, onEditProperty, onDeleteProperty, onViewDetails, canEdit, canDelete, owners }: PropertyTableProps) {
  const formatTimestamp = (isoString?: string) => {
    if (!isoString) return '-';
    try {
      return format(parseISO(isoString), 'yyyy/MM/dd HH:mm', { locale: arSA });
    } catch (e) {
      return 'تاريخ خاطئ';
    }
  };
  return (
    <div className="overflow-x-auto rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>اسم العقار</TableHead>
            <TableHead>العنوان</TableHead>
            <TableHead>المالك</TableHead>
            <TableHead>النوع</TableHead>
            <TableHead>الحالة</TableHead>
            <TableHead>آخر تعديل بواسطة</TableHead>
            <TableHead>وقت آخر تعديل</TableHead>
            <TableHead className="text-center">الإجراءات</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {properties.map((property) => {
            const owner = owners.find(o => o.id === property.ownerId);
            return (
              <TableRow key={property.id} className="hover:bg-muted/20 transition-colors">
                <TableCell className="font-medium py-3 px-4 cursor-pointer" onClick={() => onViewDetails(property)}>{property.name}</TableCell>
                <TableCell className="py-3 px-4 cursor-pointer" onClick={() => onViewDetails(property)}>{property.address}</TableCell>
                <TableCell className="py-3 px-4">{owner?.name || 'غير محدد'}</TableCell>
                <TableCell className="py-3 px-4">{getLabelForValue(PROPERTY_TYPES, property.type)}</TableCell>
                <TableCell className="py-3 px-4">
                  <Badge variant={PROPERTY_STATUS_BADGE_CONFIG[property.status].variant} className={PROPERTY_STATUS_BADGE_CONFIG[property.status].className}>
                    {getLabelForValue(PROPERTY_STATUSES, property.status)}
                  </Badge>
                </TableCell>
                 <TableCell className="py-3 px-4 text-xs text-muted-foreground">
                  <div className="flex items-center">
                    <User className="h-3 w-3 me-1" /> {property.lastModifiedBy || '-'}
                  </div>
                </TableCell>
                <TableCell className="py-3 px-4 text-xs text-muted-foreground">
                  <div className="flex items-center">
                    <Clock className="h-3 w-3 me-1" /> {formatTimestamp(property.lastModifiedAt)}
                  </div>
                </TableCell>
                <TableCell className="text-center py-2 px-4">
                  <TooltipProvider>
                    <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse">
                       <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => onViewDetails(property)} className="text-primary hover:text-primary/80 h-8 w-8">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>عرض التفاصيل</p></TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => onEditProperty(property)} disabled={!canEdit} className="text-blue-600 hover:text-blue-700 h-8 w-8">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>{!canEdit ? "لا تملك صلاحية التعديل" : "تعديل"}</p></TooltipContent>
                      </Tooltip>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => onDeleteProperty(property)} disabled={!canDelete} className="text-destructive hover:text-destructive/80 h-8 w-8">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف"}</p></TooltipContent>
                      </Tooltip>
                    </div>
                  </TooltipProvider>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}

interface PropertyManagementDashboardProps {
  properties: Property[];
  onAddProperty: (data: Omit<Property, 'id' | 'imageUrl' | 'lastModifiedBy' | 'lastModifiedAt'>) => void;
  onUpdateProperty: (data: Property) => void;
  onDeleteProperty: (propertyId: string) => void;
  onSelectProperty: (property: Property) => void;
  owners: Owner[];
}

export function PropertyManagementDashboard({
  properties: initialProperties,
  onAddProperty,
  onUpdateProperty,
  onDeleteProperty,
  onSelectProperty,
  owners,
}: PropertyManagementDashboardProps) {
  const { toast } = useToast();
  const { currentUser } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('grid');
  const [currentProperties, setCurrentProperties] = useState<Property[]>(initialProperties);

  useEffect(() => {
    setCurrentProperties(initialProperties);
  }, [initialProperties]);

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [propertyToEdit, setPropertyToEdit] = useState<Property | null>(null);
  const [propertyToDelete, setPropertyToDelete] = useState<Property | null>(null);
  const [isAddAccordionOpen, setIsAddAccordionOpen] = useState(false);
  
  const canEditProperty = currentUser?.permissions?.canEdit ?? false;
  const canDeleteProperty = currentUser?.permissions?.canDelete ?? false;


  const filteredProperties = currentProperties.filter(
    (property) =>
      property.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      property.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      getLabelForValue(PROPERTY_TYPES, property.type as PropertyTypeEnum).toLowerCase().includes(searchTerm.toLowerCase()) ||
      (owners.find(o => o.id === property.ownerId)?.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleAddPropertySubmit = (data: PropertyFormValues) => {
    onAddProperty(data);
    setIsAddAccordionOpen(false);
    toast({ title: "تم إضافة العقار", description: `تم إضافة ${data.name} بنجاح.` });
  };

  const handleEditPropertySubmit = (data: PropertyFormValues) => {
    if (!propertyToEdit) return;
    const modifierUsername = currentUser?.username || 'system_prop_edit';
    const modificationTimestamp = new Date().toISOString();
    const updatedProperty: Property = { 
        ...propertyToEdit, 
        ...data, 
        type: data.type as PropertyTypeEnum, 
        status: data.status as PropertyStatus,
        ownerId: data.ownerId || undefined,
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
    };
    onUpdateProperty(updatedProperty);
    setIsEditModalOpen(false);
    setPropertyToEdit(null);
  };

  const handleDeleteConfirm = () => {
    if (!propertyToDelete) return;
    onDeleteProperty(propertyToDelete.id);
    setPropertyToDelete(null);
  };

  const openEditModal = (property: Property) => {
    setPropertyToEdit(property);
    setIsEditModalOpen(true);
  };

  const handleViewDetails = (property: Property) => {
    onSelectProperty(property); 
  };
  
  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg">إدارة العقارات</CardTitle>
            <CardDescription className="text-sm font-semibold">عرض، إضافة، تعديل، وحذف العقارات.</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative w-full md:w-64">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="بحث عن عقار..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pe-10"
                dir="rtl"
              />
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant={viewMode === 'grid' ? 'default' : 'outline'} size="icon" onClick={() => setViewMode('grid')}>
                    <LayoutGrid className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent><p>عرض شبكي</p></TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                   <Button variant={viewMode === 'table' ? 'default' : 'outline'} size="icon" onClick={() => setViewMode('table')}>
                    <List className="h-4 w-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent><p>عرض جدولي</p></TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <Accordion 
            type="single" 
            collapsible 
            className="w-full mb-6 border rounded-lg shadow-sm"
            value={isAddAccordionOpen ? "add-property-item" : ""}
            onValueChange={(value) => {
                setIsAddAccordionOpen(value === "add-property-item");
            }}
        >
          <AccordionItem value="add-property-item" className="border-b-0">
             <AccordionTrigger className={cn(
                "px-4 py-3 hover:bg-muted/60 w-full flex justify-between items-center rounded-t-md text-primary hover:text-primary/90 hover:no-underline",
                !isAddAccordionOpen && "rounded-b-md" 
             )}>
                <span className="flex items-center text-lg font-medium">
                    <PlusCircle className="me-2 h-5 w-5" />
                    إضافة عقار جديد
                </span>
            </AccordionTrigger>
            <AccordionContent className="p-4 border-t rounded-b-md bg-background">
              <PropertyForm 
                onSubmit={handleAddPropertySubmit} 
                onCancel={() => setIsAddAccordionOpen(false)} 
                submitButtonText="إضافة العقار"
                owners={owners}
              />
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        {filteredProperties.length === 0 ? (
          <div className="text-center py-10 text-muted-foreground bg-background rounded-md border border-dashed">
            <LayoutGrid className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-lg font-medium">لا توجد عقارات لعرضها</p>
            <p className="text-sm">
              {searchTerm ? "لا توجد عقارات تطابق بحثك." : "ابدأ بإضافة عقار جديد لعرضه هنا."}
            </p>
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProperties.map((property) => (
              <PropertyCard
                key={property.id}
                property={property}
                onEdit={() => openEditModal(property)}
                onDelete={() => setPropertyToDelete(property)}
                onViewDetails={() => handleViewDetails(property)}
                canEdit={canEditProperty}
                canDelete={canDeleteProperty}
                owners={owners}
              />
            ))}
          </div>
        ) : (
          <PropertyTable
            properties={filteredProperties}
            onEditProperty={openEditModal}
            onDeleteProperty={(prop) => setPropertyToDelete(prop)}
            onViewDetails={handleViewDetails}
            canEdit={canEditProperty}
            canDelete={canDeleteProperty}
            owners={owners}
          />
        )}
      </CardContent>

      <Dialog open={isEditModalOpen} onOpenChange={(isOpen) => {
        if (!isOpen) {
            setIsEditModalOpen(false);
            setPropertyToEdit(null);
        } else {
            setIsEditModalOpen(true);
        }
      }}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>تعديل بيانات العقار</DialogTitle>
            <DialogDescription>قم بتحديث معلومات العقار المحدد.</DialogDescription>
          </DialogHeader>
          {propertyToEdit && (
            <PropertyForm
              onSubmit={handleEditPropertySubmit}
              initialData={{
                name: propertyToEdit.name,
                address: propertyToEdit.address,
                type: propertyToEdit.type,
                status: propertyToEdit.status,
                ownerId: propertyToEdit.ownerId,
              }}
              onCancel={() => {
                setIsEditModalOpen(false);
                setPropertyToEdit(null);
              }}
              submitButtonText="حفظ التعديلات"
              owners={owners}
            />
          )}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!propertyToDelete} onOpenChange={(isOpen) => { if (!isOpen) setPropertyToDelete(null);}}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>هل أنت متأكد من حذف هذا العقار؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف العقار "{propertyToDelete?.name}" بشكل دائم. هذا الإجراء لا يمكن التراجع عنه وسيشمل حذف جميع المستأجرين والدفعات المرتبطة بهذا العقار.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setPropertyToDelete(null)}>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive hover:bg-destructive/90 text-destructive-foreground">
              حذف
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
