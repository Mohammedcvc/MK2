
'use client';

import type { BankTransaction, Attachment } from '@/types';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, SubmitHandler } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Loader2 } from 'lucide-react';
import { format, parse, parseISO, isValid, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useState, useEffect } from 'react';

const bankTransactionFormSchema = z.object({
  date: z.date({ required_error: 'تاريخ العملية مطلوب.' }),
  description: z.string().min(3, { message: 'بيان العملية يجب أن لا يقل عن 3 أحرف.' }),
  amountIncoming: z.coerce.number().optional().default(0),
  amountOutgoing: z.coerce.number().optional().default(0),
}).refine(data => data.amountIncoming || data.amountOutgoing, {
  message: "يجب إدخال مبلغ وارد أو مبلغ صادر على الأقل.",
  path: ["amountIncoming"],
}).refine(data => !(data.amountIncoming && data.amountIncoming > 0 && data.amountOutgoing && data.amountOutgoing > 0), {
  message: "لا يمكن إدخال مبلغ وارد ومبلغ صادر في نفس العملية.",
  path: ["amountIncoming"], 
});

export type BankTransactionFormValues = z.infer<typeof bankTransactionFormSchema>;

interface AddEditBankTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: BankTransactionFormValues, transactionIdToUpdate?: string) => Promise<void>;
  initialData?: BankTransaction | null; 
}

export function AddEditBankTransactionModal({ isOpen, onClose, onSubmit, initialData }: AddEditBankTransactionModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  const form = useForm<BankTransactionFormValues>({
    resolver: zodResolver(bankTransactionFormSchema),
    defaultValues: initialData
      ? {
          ...initialData,
          date: initialData.date ? parseISO(initialData.date) : new Date(),
          amountIncoming: initialData.amountIncoming || 0,
          amountOutgoing: initialData.amountOutgoing || 0,
        }
      : {
          date: new Date(),
          description: '',
          amountIncoming: 0,
          amountOutgoing: 0,
        },
  });

  useEffect(() => {
    if (isOpen) {
      form.reset(
        initialData
          ? {
              ...initialData,
              date: initialData.date ? parseISO(initialData.date) : new Date(),
              amountIncoming: initialData.amountIncoming || 0,
              amountOutgoing: initialData.amountOutgoing || 0,
            }
          : {
              date: new Date(),
              description: '',
              amountIncoming: 0,
              amountOutgoing: 0,
            }
      );
      setIsCalendarOpen(false);
    }
  }, [isOpen, initialData, form]);

  const handleSubmit: SubmitHandler<BankTransactionFormValues> = async (data) => {
    setIsSubmitting(true);
    const processedData = {
        ...data,
        amountIncoming: Number(data.amountIncoming) || 0,
        amountOutgoing: Number(data.amountOutgoing) || 0,
    };
    await onSubmit(processedData, initialData?.id);
    setIsSubmitting(false);
  };

  const currentYear = getYear(new Date());
  const fromYear = subYears(new Date(), 10).getFullYear();
  const toYear = addYears(new Date(), 10).getFullYear();

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{initialData ? 'تعديل العملية البنكية' : 'إضافة عملية بنكية جديدة'}</DialogTitle>
          <DialogDescription>
            {initialData ? 'قم بتحديث معلومات العملية البنكية.' : `إضافة عملية بنكية جديدة للتركة.`}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-2 max-h-[70vh] overflow-y-auto px-1">
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>تاريخ العملية</FormLabel>
                  <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                    <PopoverTrigger asChild>
                      <div className="relative">
                        <Input
                          placeholder="YYYY-MM-DD"
                          value={field.value ? format(field.value, 'yyyy-MM-dd') : ''}
                          onChange={(e) => {
                            const dateString = e.target.value;
                            try {
                              const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                              if (isValid(parsedDate)) {
                                field.onChange(parsedDate);
                              } else if (dateString === '') {
                                field.onChange(undefined);
                              }
                            } catch {
                              field.onChange(undefined);
                            }
                          }}
                          className={cn("pe-10 text-center bg-card", !field.value && "text-muted-foreground")}
                        />
                        <CalendarIcon
                          className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                          onClick={() => setIsCalendarOpen(prev => !prev)}
                        />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={(date) => { field.onChange(date); setIsCalendarOpen(false); }}
                        captionLayout="dropdown-buttons"
                        fromYear={fromYear}
                        toYear={toYear}
                        defaultMonth={field.value || new Date()}
                        initialFocus
                        dir="rtl"
                        locale={arSA}
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>بيان العملية</FormLabel>
                  <FormControl>
                    <Textarea placeholder="مثال: إيداع إيجار، سداد فاتورة..." {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="amountIncoming"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>مبلغ وارد (ريال)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="مثال: 5000" {...field} className="bg-card text-center" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amountOutgoing"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>مبلغ صادر (ريال)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="مثال: 500" {...field} className="bg-card text-center" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                إلغاء
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                {initialData ? 'حفظ التغييرات' : 'إضافة العملية'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
