
'use client';

import type { InheritorTransaction, Attachment, InheritorOperationType } from '@/types';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, SubmitHandler } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarIcon, Loader2 } from 'lucide-react';
import { format, parse, parseISO, isValid, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { INHERITOR_OPERATION_TYPES } from '@/lib/constants';
import { useState, useEffect } from 'react';

const inheritorTransactionFormSchema = z.object({
  date: z.date({ required_error: 'تاريخ الحركة مطلوب.' }),
  amountCredit: z.coerce.number().optional().default(0), // له مبلغ
  amountDebit: z.coerce.number().optional().default(0), // عليه مبلغ
  description: z.string().min(3, { message: 'بيان الحركة يجب أن لا يقل عن 3 أحرف.' }),
  operationType: z.custom<InheritorOperationType>((val) => INHERITOR_OPERATION_TYPES.some(rt => rt.value === val), { message: 'نوع العملية مطلوب.' }).optional(),
}).refine(data => !(data.amountCredit && data.amountCredit > 0 && data.amountDebit && data.amountDebit > 0), {
  message: "لا يمكن إدخال مبلغ له وعليه في نفس الوقت. استخدم حقلًا واحدًا.",
  path: ["amountCredit"], 
}).refine(data => (data.amountCredit && data.amountCredit !== 0) || (data.amountDebit && data.amountDebit !== 0), {
    message: "يجب إدخال مبلغ في حقل 'له مبلغ' أو 'عليه مبلغ'.",
    path: ["amountCredit"],
});

export type InheritorTransactionFormValues = z.infer<typeof inheritorTransactionFormSchema>;

interface AddEditInheritorTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Pick<InheritorTransaction, 'date' | 'amount' | 'description' | 'operationType'>, transactionIdToUpdate?: string) => Promise<void>;
  initialData?: InheritorTransaction | null; 
  inheritorId: string;
}

export function AddEditInheritorTransactionModal({ isOpen, onClose, onSubmit, initialData, inheritorId }: AddEditInheritorTransactionModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  const form = useForm<InheritorTransactionFormValues>({
    resolver: zodResolver(inheritorTransactionFormSchema),
    defaultValues: {
      date: new Date(),
      amountCredit: 0,
      amountDebit: 0,
      description: '',
      operationType: undefined,
    },
  });

  useEffect(() => {
    if (isOpen) {
      if (initialData) {
        form.reset({
          date: initialData.date ? parseISO(initialData.date) : new Date(),
          amountCredit: initialData.amount > 0 ? initialData.amount : 0,
          amountDebit: initialData.amount < 0 ? Math.abs(initialData.amount) : 0,
          description: initialData.description,
          operationType: initialData.operationType || undefined,
        });
      } else {
        form.reset({
          date: new Date(),
          amountCredit: 0,
          amountDebit: 0,
          description: '',
          operationType: undefined,
        });
      }
      setIsCalendarOpen(false);
    }
  }, [isOpen, initialData, form]);

  const handleSubmit: SubmitHandler<InheritorTransactionFormValues> = async (formData) => {
    setIsSubmitting(true);
    let finalAmount = 0;
    if (formData.amountCredit && formData.amountCredit > 0) {
      finalAmount = formData.amountCredit;
    } else if (formData.amountDebit && formData.amountDebit > 0) {
      finalAmount = -formData.amountDebit;
    }

    const dataToSubmit = {
      date: format(formData.date, 'yyyy-MM-dd'),
      amount: finalAmount,
      description: formData.description,
      operationType: formData.operationType,
    };
    
    await onSubmit(dataToSubmit, initialData?.id);
    setIsSubmitting(false);
  };

  const currentYear = getYear(new Date());
  const fromYear = subYears(new Date(), 10).getFullYear();
  const toYear = addYears(new Date(), 10).getFullYear();

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{initialData ? 'تعديل الحركة المالية للوريث' : 'إضافة حركة مالية جديدة للوريث'}</DialogTitle>
          <DialogDescription>
            {initialData ? 'قم بتحديث معلومات الحركة المالية للوريث.' : `إضافة حركة مالية جديدة للوريث.`}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-2 max-h-[70vh] overflow-y-auto px-1">
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>تاريخ الحركة</FormLabel>
                  <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                    <PopoverTrigger asChild>
                      <div className="relative">
                        <Input
                          placeholder="YYYY-MM-DD"
                          value={field.value ? format(field.value, 'yyyy-MM-dd') : ''}
                          onChange={(e) => {
                            const dateString = e.target.value;
                            try {
                              const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                              if (isValid(parsedDate)) {
                                field.onChange(parsedDate);
                              } else if (dateString === '') {
                                field.onChange(undefined);
                              }
                            } catch {
                              field.onChange(undefined);
                            }
                          }}
                          className={cn("pe-10 text-center bg-card", !field.value && "text-muted-foreground")}
                        />
                        <CalendarIcon
                          className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                          onClick={() => setIsCalendarOpen(prev => !prev)}
                        />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={(date) => { field.onChange(date); setIsCalendarOpen(false); }}
                        captionLayout="dropdown-buttons"
                        fromYear={fromYear}
                        toYear={toYear}
                        defaultMonth={field.value || new Date()}
                        initialFocus
                        dir="rtl"
                        locale={arSA}
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amountCredit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>له مبلغ (ريال)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="مثال: 5000" {...field} onChange={e => field.onChange(parseFloat(e.target.value) || 0)} className="bg-card text-center" />
                  </FormControl>
                  <FormMessage />
                  <p className="text-xs text-muted-foreground">المبلغ الذي يستحقه الوارث (إيداع).</p>
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amountDebit"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>عليه مبلغ (ريال)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="مثال: 500" {...field} onChange={e => field.onChange(parseFloat(e.target.value) || 0)} className="bg-card text-center" />
                  </FormControl>
                  <FormMessage />
                   <p className="text-xs text-muted-foreground">المبلغ المطلوب من الوارث (سحب/خصم).</p>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>بيان الحركة</FormLabel>
                  <FormControl>
                    <Textarea placeholder="مثال: حصة من إيجار، سداد مصروفات التركة..." {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="operationType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>نوع العملية</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-card"><SelectValue placeholder="اختر نوع العملية" /></SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {INHERITOR_OPERATION_TYPES.map(type => <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                إلغاء
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                {initialData ? 'حفظ التغييرات' : 'إضافة الحركة'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
