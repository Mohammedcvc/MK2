
'use client';

import type { Tenant, Property, Payment } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableCaption
} from '@/components/ui/table';
import { Badge, type BadgeProps } from '@/components/ui/badge';
import { differenceInDays, parseISO, isFuture, format } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { cn } from '@/lib/utils';

interface TenantMovementTableProps {
  tenants: Tenant[];
  properties: Property[];
  payments: Payment[];
  onTenantSelect: (tenant: Tenant) => void;
}

export function TenantMovementTable({ tenants, properties, payments, onTenantSelect }: TenantMovementTableProps) {
  if (tenants.length === 0) {
    return <p className="text-center text-muted-foreground py-8">لا توجد بيانات مستأجرين لعرضها.</p>;
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableCaption>قائمة بحركة جميع المستأجرين. انقر على صف لعرض التقرير المفصل.</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="min-w-[150px]">اسم المستأجر</TableHead>
            <TableHead className="min-w-[120px]">اسم المتجر</TableHead>
            <TableHead className="min-w-[150px]">رقم العقد</TableHead>
            <TableHead className="min-w-[120px] text-center">إجمالي الإيجار (ريال)</TableHead>
            <TableHead className="min-w-[120px] text-center">المبلغ المدفوع (ريال)</TableHead>
            <TableHead className="min-w-[120px] text-center">الرصيد (ريال)</TableHead>
            <TableHead className="min-w-[180px] text-center">حالة العقد</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {tenants.map((tenant) => {
            const property = properties.find(p => p.id === tenant.propertyId);
            const tenantPayments = payments.filter(p => p.tenantId === tenant.tenantId);
            
            const totalDueForTenant = tenantPayments.reduce((sum, p) => sum + p.amountDue, 0);
            const totalPaidByTenant = tenantPayments.reduce((sum, p) => sum + p.amountPaid, 0);
            const tenantBalance = totalDueForTenant - totalPaidByTenant;

            let contractStatusDisplay = '-';
            let badgeVariant: BadgeProps['variant'] = 'outline';
            let badgeClassName = 'text-muted-foreground';


            if (tenant.contractEndDate) {
              try {
                const endDate = parseISO(tenant.contractEndDate);
                const today = new Date();
                // Clear time part for accurate day difference
                const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
                const endDateStart = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());

                if (isFuture(endDateStart) || differenceInDays(endDateStart, todayStart) === 0) { // If contract ends today or in future
                  const remainingDays = differenceInDays(endDateStart, todayStart);
                  if (remainingDays <= 90) {
                    contractStatusDisplay = `قرب الانتهاء (${remainingDays} ${remainingDays === 0 ? 'اليوم' : remainingDays === 1 ? 'يوم' : 'أيام'} متبقية)`;
                    badgeVariant = 'destructive'; 
                    badgeClassName = 'text-destructive-foreground';
                  } else {
                    contractStatusDisplay = 'العقد ساري';
                    badgeVariant = 'default';
                    badgeClassName = 'bg-green-600 text-primary-foreground hover:bg-green-700 border-green-600';
                  }
                } else { // Contract is past
                  contractStatusDisplay = `منتهي منذ ${format(endDate, 'yyyy/MM/dd', { locale: arSA })}`;
                  badgeVariant = 'secondary'; 
                  badgeClassName = 'bg-yellow-400 text-black hover:bg-yellow-500 border-yellow-500';
                }
              } catch (e) {
                console.error("Error parsing contract end date for tenant movement table:", e);
                contractStatusDisplay = 'تاريخ خاطئ';
                badgeVariant = 'destructive';
                badgeClassName = 'text-destructive-foreground';
              }
            }


            return (
              <TableRow 
                key={tenant.tenantId} 
                onClick={() => onTenantSelect(tenant)}
                className="cursor-pointer hover:bg-muted/50 transition-colors"
              >
                <TableCell className="font-medium">{tenant.tenantName}</TableCell>
                <TableCell>{property?.name || '-'}</TableCell>
                <TableCell>{tenant.contractIdentifier || tenant.tenantId}</TableCell>
                <TableCell className="text-center">{totalDueForTenant.toLocaleString('ar-SA')} ريال</TableCell>
                <TableCell className="text-center">{totalPaidByTenant.toLocaleString('ar-SA')} ريال</TableCell>
                <TableCell className="text-center">
                  <Badge variant={tenantBalance === 0 ? "default" : (tenantBalance < 0 ? "secondary" : "destructive")}
                         className={cn(tenantBalance === 0 ? "bg-green-500 hover:bg-green-600 text-primary-foreground" : "")}>
                    {Math.abs(tenantBalance).toLocaleString('ar-SA')} ريال
                  </Badge>
                </TableCell>
                <TableCell className="text-center">
                   <Badge variant={badgeVariant} className={cn(badgeClassName)}>
                    {contractStatusDisplay}
                  </Badge>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}

