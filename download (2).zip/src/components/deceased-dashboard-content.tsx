
'use client';

import { useMemo, useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import type { Property, Tenant, Payment, Inheritor, InheritorTransaction } from '@/types';
import { LayoutGrid, Search, TrendingUp, BadgePercent, Building, FileText, Wallet, WalletCards, Home, UserMinus, Receipt, UsersRound, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DashboardSummaryCard } from '@/components/dashboard-summary-card';
import { RentedPropertyCard } from '@/components/rented-property-card';
import { TenantMovementTable } from '@/components/tenant-movement-table';
import { useAppContext } from '@/contexts/app-context';
import { TenantReportModal } from '@/components/tenant-report-modal';
import { DeceasedTenantMovementReportModal } from '@/components/deceased-tenant-movement-report-modal';
import { InheritorReportModal } from '@/components/inheritor-report-modal';
import { isPast, parseISO, format } from 'date-fns';
import { cn } from '@/lib/utils';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export function DeceasedDashboardContent() {
  const {
    deceasedProperties,
    deceasedTenants,
    deceasedPayments,
    deceasedInheritors,
    deceasedInheritorTransactions
  } = useAppContext();
  const router = useRouter();
  const { toast } = useToast();

  const [isTenantReportModalOpen, setIsTenantReportModalOpen] = useState(false);
  const [isDeceasedTenantMovementReportModalOpen, setIsDeceasedTenantMovementReportModalOpen] = useState(false);
  const [selectedTenantForReport, setSelectedTenantForReport] = useState<Tenant | null>(null);
  const [selectedPropertyForReport, setSelectedPropertyForReport] = useState<Property | null>(null);
  const [selectedTenantPaymentsForReport, setSelectedTenantPaymentsForReport] = useState<Payment[]>([]);

  const [isInheritorDetailModalOpen, setIsInheritorDetailModalOpen] = useState(false);
  const [selectedInheritorForDetailReport, setSelectedInheritorForDetailReport] = useState<Inheritor | null>(null);
  const [selectedInheritorTransactionsForDetailReport, setSelectedInheritorTransactionsForDetailReport] = useState<InheritorTransaction[]>([]);


  const [currentDateFormatted, setCurrentDateFormatted] = useState('');
  useEffect(() => {
    setCurrentDateFormatted(format(new Date(), 'yyyy-MM-dd'));
  }, []);

  const handleSelectPropertyForDetails = (property: Property) => {
    router.push(`/properties/${property.id}?source=deceased`);
  };

  const totalRentsDeceased = useMemo(() => {
    return deceasedTenants.filter(tenant => {
      const property = deceasedProperties.find(p => p.id === tenant.propertyId);
      if (!property || property.status !== 'rented') return false;
      if (!tenant.contractEndDate) return false;
      try {
        return !isPast(parseISO(tenant.contractEndDate));
      } catch { return false; }
    }).reduce((sum, tenant) => sum + tenant.contractValue, 0);
  }, [deceasedTenants, deceasedProperties]);

  const totalPaidDeceased = useMemo(() => {
    return deceasedPayments.reduce((sum, payment) => sum + payment.amountPaid, 0);
  }, [deceasedPayments]);

  const totalTaxDeceased = useMemo(() => {
    return deceasedTenants.filter(tenant => {
      const property = deceasedProperties.find(p => p.id === tenant.propertyId);
      if (!property || property.status !== 'rented') return false;
      if (!tenant.contractEndDate) return false;
      try {
        return !isPast(parseISO(tenant.contractEndDate));
      } catch { return false; }
    }).reduce((sum, tenant) => {
      return sum + (tenant.contractValue * (tenant.taxRate / 100));
    }, 0);
  }, [deceasedTenants, deceasedProperties]);

  const remainingBalanceDeceased = useMemo(() => {
    const totalContractValuesWithTax = deceasedTenants.filter(tenant => {
      const property = deceasedProperties.find(p => p.id === tenant.propertyId);
      if (!property || property.status !== 'rented') return false;
      if (!tenant.contractEndDate) return false;
      try {
        return !isPast(parseISO(tenant.contractEndDate));
      } catch { return false; }
    }).reduce((acc, t) => acc + (t.contractValue * (1 + t.taxRate / 100)), 0);
    return totalContractValuesWithTax - totalPaidDeceased;
  }, [deceasedTenants, deceasedProperties, totalPaidDeceased]);

  const activeContractsCountDeceased = useMemo(() => deceasedTenants.filter(t => {
    const property = deceasedProperties.find(p => p.id === t.propertyId);
    if (!property || property.status !== 'rented') return false;
    if (!t.contractEndDate) return false;
    try {
      return !isPast(parseISO(t.contractEndDate));
    } catch { return false; }
  }).length, [deceasedTenants, deceasedProperties]);

  const rentedPropertiesDataDeceased = useMemo(() => {
    return deceasedProperties
      .filter(property => property.status === 'rented')
      .map(property => {
        const tenant = deceasedTenants.find(t => {
          if (t.propertyId !== property.id) return false;
          if (!t.contractEndDate) return false;
          try {
            return !isPast(parseISO(t.contractEndDate));
          } catch { return false; }
        });
        if (!tenant) return null;
        const tenantPayments = deceasedPayments.filter(p => p.tenantId === tenant.tenantId);
        return { property, tenant, payments: tenantPayments };
      })
      .filter(item => item !== null) as { property: Property; tenant: Tenant; payments: Payment[] }[];
  }, [deceasedProperties, deceasedTenants, deceasedPayments]);

  const departedPropertiesDataDeceased = useMemo(() => {
    return deceasedTenants
      .filter(tenant => {
        if (!tenant.contractEndDate) return true;
        try {
          return isPast(parseISO(tenant.contractEndDate));
        } catch { return false; }
      })
      .map(tenant => {
        const property = deceasedProperties.find(p => p.id === tenant.propertyId);
        if (!property) return null;
        const tenantPayments = deceasedPayments.filter(p => p.tenantId === tenant.tenantId);
        return { property, tenant, payments: tenantPayments };
      })
      .filter(item => item !== null) as { property: Property; tenant: Tenant; payments: Payment[] }[];
  }, [deceasedProperties, deceasedTenants, deceasedPayments]);

  const [searchTerm, setSearchTerm] = useState('');
  const filteredDeceasedTenantMovements = useMemo(() => {
    if (!searchTerm) return deceasedTenants;
    return deceasedTenants.filter(tenant =>
      tenant.tenantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (deceasedProperties.find(p => p.id === tenant.propertyId)?.name.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [deceasedTenants, deceasedProperties, searchTerm]);

  const handleSelectTenantForReport = (tenant: Tenant) => {
    const property = deceasedProperties.find(p => p.id === tenant.propertyId);
    const tenantPayments = deceasedPayments.filter(p => p.tenantId === tenant.tenantId);

    setSelectedTenantForReport(tenant);
    setSelectedPropertyForReport(property || null);
    setSelectedTenantPaymentsForReport(tenantPayments);
    setIsTenantReportModalOpen(true);
  };

  const handleOpenDeceasedTenantMovementReport = () => {
    if (deceasedTenants.length === 0) {
        toast({
            title: "لا توجد بيانات",
            description: "لا يوجد مستأجرين لعرضهم في تقرير حركة المستأجرين.",
            variant: "default",
        });
        return;
    }
    setIsDeceasedTenantMovementReportModalOpen(true);
  };

  const inheritorBalances = useMemo(() => {
    return deceasedInheritors.map(inheritor => {
      const transactions = deceasedInheritorTransactions.filter(t => t.inheritorId === inheritor.id);
      const netBalance = transactions.reduce((sum, t) => sum + t.amount, 0);
      return {
        ...inheritor,
        netBalance,
      };
    });
  }, [deceasedInheritors, deceasedInheritorTransactions]);

  const handleOpenInheritorDetailReport = (inheritor: Inheritor) => {
    const transactions = deceasedInheritorTransactions.filter(t => t.inheritorId === inheritor.id);
    setSelectedInheritorForDetailReport(inheritor);
    setSelectedInheritorTransactionsForDetailReport(transactions);
    setIsInheritorDetailModalOpen(true);
  };

  const accordionDefaultValues = [
    "deceased-info-accordion",
    "inheritor-balances-accordion",
    "rented-shops-accordion-deceased",
    "departed-shops-accordion-deceased",
    "tenant-movements-accordion-deceased"
  ];

  return (
    <Accordion type="multiple" defaultValue={accordionDefaultValues} className="space-y-6">
      <AccordionItem value="deceased-info-accordion" className="border-b-0">
        <Card>
          <AccordionTrigger className="w-full px-6 py-4 hover:no-underline flex justify-between items-center data-[state=open]:border-b">
            <CardTitle className="text-lg flex items-center">
              <LayoutGrid className="me-3 h-7 w-7 text-primary" />
              {'لوحة معلومات عقارات الورثة'}
            </CardTitle>
          </AccordionTrigger>
          <AccordionContent>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 pt-6">
              <DashboardSummaryCard
                title="إجمالي إيجارات الورثة"
                value={totalRentsDeceased}
                icon={TrendingUp}
                description={`${activeContractsCountDeceased} عقد نشط حالياً للورثة`}
                iconBgColor="bg-blue-100"
                iconColor="text-blue-600"
              />
              <DashboardSummaryCard
                title="إجمالي ضريبة الورثة"
                value={totalTaxDeceased}
                icon={BadgePercent}
                description={`نسبة الضريبة ${deceasedTenants.length > 0 && deceasedTenants.find(t => t.contractEndDate && !isPast(parseISO(t.contractEndDate))) ? deceasedTenants.find(t => t.contractEndDate && !isPast(parseISO(t.contractEndDate)))!.taxRate : 0}% (للعقود النشطة)`}
                iconBgColor="bg-yellow-100"
                iconColor="text-yellow-600"
              />
              <DashboardSummaryCard
                title="إجمالي مدفوعات الورثة"
                value={totalPaidDeceased}
                icon={Wallet}
                description="خلال الفترة"
                iconBgColor="bg-green-100"
                iconColor="text-green-600"
              />
              <DashboardSummaryCard
                title="الرصيد المتبقي للورثة"
                value={remainingBalanceDeceased}
                icon={WalletCards}
                description="رصيد مدين/دائن (للعقود النشطة للورثة)"
                iconBgColor="bg-red-100"
                iconColor="text-red-600"
                valueClassName={remainingBalanceDeceased < 0 ? "text-green-600" : "text-destructive"}
              />
            </CardContent>
          </AccordionContent>
        </Card>
      </AccordionItem>

      {inheritorBalances.length > 0 && (
        <AccordionItem value="inheritor-balances-accordion" className="border-b-0">
          <Card>
            <AccordionTrigger className="w-full px-6 py-4 hover:no-underline flex justify-between items-center data-[state=open]:border-b">
              <CardTitle className="text-lg">ملخص أرصدة الورثة</CardTitle>
            </AccordionTrigger>
            <AccordionContent>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-6">
                {inheritorBalances.map(inheritor => (
                  <div
                    key={inheritor.id}
                    onClick={() => handleOpenInheritorDetailReport(inheritor)}
                    className="cursor-pointer rounded-lg overflow-hidden transition-shadow hover:shadow-lg"
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleOpenInheritorDetailReport(inheritor); }}
                  >
                    <DashboardSummaryCard
                      title={`الوارث: ${inheritor.name}`}
                      value={inheritor.netBalance}
                      icon={User}
                      description={`نسبة الإرث: ${inheritor.sharePercentage?.toFixed(2) || 'غير محددة'}%`}
                      iconBgColor="bg-sky-100"
                      iconColor="text-sky-600"
                      valueClassName={inheritor.netBalance >= 0 ? 'text-green-600' : 'text-destructive'}
                    />
                  </div>
                ))}
              </CardContent>
            </AccordionContent>
          </Card>
        </AccordionItem>
      )}

      <AccordionItem value="rented-shops-accordion-deceased" className="border-b-0">
        <Card>
          <AccordionTrigger className="w-full px-6 py-4 hover:no-underline flex justify-between items-center data-[state=open]:border-b">
            <CardTitle className="text-lg flex items-center"><Home className="me-2 h-5 w-5 text-primary" />عقارات الورثة المؤجرة</CardTitle>
          </AccordionTrigger>
          <AccordionContent>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-6">
              {rentedPropertiesDataDeceased.map(({ property, tenant, payments }) => property && (
                  <RentedPropertyCard
                    key={`${property.id}-${tenant.tenantId}-rented-deceased`}
                    property={property}
                    tenant={tenant}
                    payments={payments}
                    dataSource="deceased"
                    onViewDetails={handleSelectPropertyForDetails}
                  />
                )
              )}
              {rentedPropertiesDataDeceased.length === 0 && <p className="col-span-full text-center text-muted-foreground py-4">لا توجد عقارات مؤجرة حالياً ضمن أملاك الورثة.</p>}
            </CardContent>
          </AccordionContent>
        </Card>
      </AccordionItem>

      <AccordionItem value="departed-shops-accordion-deceased" className="border-b-0">
        <Card>
          <AccordionTrigger className="w-full px-6 py-4 hover:no-underline flex justify-between items-center data-[state=open]:border-b">
            <CardTitle className="text-lg flex items-center"><UserMinus className="me-2 h-5 w-5 text-primary" />عقارات الورثة المغادرة</CardTitle>
          </AccordionTrigger>
          <AccordionContent>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-6">
              {departedPropertiesDataDeceased.map(({ property, tenant, payments }) => property && (
                  <RentedPropertyCard
                    key={`${property.id}-${tenant.tenantId}-departed-deceased`}
                    property={property}
                    tenant={tenant}
                    payments={payments}
                    dataSource="deceased"
                    onViewDetails={handleSelectPropertyForDetails}
                  />
                )
              )}
              {departedPropertiesDataDeceased.length === 0 && <p className="col-span-full text-center text-muted-foreground py-4">لا توجد عقارات غادرها مستأجرون مؤخرًا ضمن أملاك الورثة.</p>}
            </CardContent>
          </AccordionContent>
        </Card>
      </AccordionItem>

      <AccordionItem value="tenant-movements-accordion-deceased" className="border-b-0">
        <Card>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 p-6 data-[state=open]:border-b">
            <AccordionTrigger className="flex-grow text-right p-0 hover:no-underline [&_svg.lucide-chevron-down]:ms-2">
              <CardTitle className="text-lg">حركة مستأجري عقارات الورثة</CardTitle>
            </AccordionTrigger>
            <div className="flex items-center gap-2">
              <div className="relative w-full md:w-72">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="بحث..."
                  className="ps-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button variant="outline" onClick={handleOpenDeceasedTenantMovementReport}>
                <FileText className="me-2 h-4 w-4" />
                تقرير الحركة
              </Button>
            </div>
          </div>
          <AccordionContent>
            <CardContent className="pt-0">
              <TenantMovementTable
                tenants={filteredDeceasedTenantMovements}
                properties={deceasedProperties}
                payments={deceasedPayments}
                onTenantSelect={handleSelectTenantForReport}
              />
            </CardContent>
          </AccordionContent>
        </Card>
      </AccordionItem>

      {selectedTenantForReport && selectedPropertyForReport && (
        <TenantReportModal
          isOpen={isTenantReportModalOpen}
          onClose={() => setIsTenantReportModalOpen(false)}
          tenant={selectedTenantForReport}
          property={selectedPropertyForReport}
          payments={selectedTenantPaymentsForReport}
        />
      )}
      <DeceasedTenantMovementReportModal
        isOpen={isDeceasedTenantMovementReportModalOpen}
        onClose={() => setIsDeceasedTenantMovementReportModalOpen(false)}
        tenants={deceasedTenants}
        properties={deceasedProperties}
        payments={deceasedPayments}
      />
       {selectedInheritorForDetailReport && (
        <InheritorReportModal
          isOpen={isInheritorDetailModalOpen}
          onClose={() => setIsInheritorDetailModalOpen(false)}
          inheritor={selectedInheritorForDetailReport}
          transactions={selectedInheritorTransactionsForDetailReport}
          totalAmount={inheritorBalances.find(ib => ib.id === selectedInheritorForDetailReport.id)?.netBalance || 0}
        />
      )}
    </Accordion>
  );
}
