
'use client';

import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Loader2 } from 'lucide-react';
import { useState } from 'react';

interface DeletePaymentDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => Promise<void>; // Make onConfirm async
  paymentDescription?: string;
}

export function DeletePaymentDialog({ isOpen, onClose, onConfirm, paymentDescription }: DeletePaymentDialogProps) {
  const [isDeleting, setIsDeleting] = useState(false);

  const handleConfirm = async () => {
    setIsDeleting(true);
    await onConfirm();
    setIsDeleting(false);
    // onClose will be called by parent after confirmation
  };
  
  return (
    <AlertDialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>هل أنت متأكد من حذف هذه الدفعة؟</AlertDialogTitle>
          <AlertDialogDescription>
            {paymentDescription && (
              <span className="block mb-2"> {/* Changed div to span with block display */}
                بيان الدفعة: <strong>{paymentDescription}</strong>.
              </span>
            )}
            هذا الإجراء لا يمكن التراجع عنه. سيتم حذف بيانات الدفعة بشكل دائم.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={onClose} disabled={isDeleting}>إلغاء</AlertDialogCancel>
          <AlertDialogAction asChild>
            <Button
              variant="destructive"
              onClick={handleConfirm}
              disabled={isDeleting}
            >
              {isDeleting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
              حذف
            </Button>
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

