
'use client';

import type { Tenant, Property, Payment } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { Badge, type BadgeProps } from '@/components/ui/badge';
import { format, parseISO, isFuture, differenceInDays } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { Printer, XIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DeceasedTenantMovementReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenants: Tenant[];
  properties: Property[];
  payments: Payment[];
}

export function DeceasedTenantMovementReportModal({ isOpen, onClose, tenants, properties, payments }: DeceasedTenantMovementReportModalProps) {
  if (!isOpen) return null;

  const handlePrint = () => {
    const printContentsElement = document.getElementById('deceased-tenant-movement-report-content');
    const printContents = printContentsElement ? printContentsElement.innerHTML.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';

    if (printContents) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        const printHtml = `
          <html>
            <head>
              <title>تقرير حركة مستأجري عقارات الورثة</title>
              <style>
                body { font-family: "Sakkal Majalla", var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
                .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
                .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11pt; }
                th, td { border: 1px solid #ddd; padding: 6px; text-align: right; font-weight: 500; }
                th { background-color: #f2f2f2; font-weight: bold; }
                .no-print { display: none; }
                .badge-print { padding: 0.2em 0.6em; border-radius: 0.25rem; font-size: 0.85em; display: inline-block; border: 1px solid transparent; }
                .badge-destructive-print { background-color: #f8d7da !important; color: #721c24 !important; border-color: #f5c6cb !important; }
                .badge-default-print { background-color: #d4edda !important; color: #155724 !important; border-color: #c3e6cb !important; }
                .badge-secondary-print { background-color: #fff3cd !important; color: #856404 !important; border-color: #ffeeba !important; }
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>تقرير حركة مستأجري عقارات الورثة</h1>
                <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
              </div>
              ${printContents}
            </body>
          </html>`;
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col">
        <DialogHeader className="border-b pb-4">
          <DialogTitle className="text-lg text-primary">تقرير حركة مستأجري عقارات الورثة</DialogTitle>
          <DialogDescription className="text-sm font-semibold">عرض لحركة المستأجرين في عقارات الورثة.</DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-grow overflow-y-auto p-1 -mx-1">
          <div id="deceased-tenant-movement-report-content" className="p-4 space-y-6">
            {tenants.length > 0 ? (
              <div className="overflow-x-auto rounded-md border">
                <Table>
                  <TableCaption className="no-print">قائمة بحركة جميع المستأجرين لعقارات الورثة.</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[150px]">اسم المستأجر</TableHead>
                      <TableHead className="min-w-[120px]">اسم المتجر</TableHead>
                      <TableHead className="min-w-[150px]">رقم العقد</TableHead>
                      <TableHead className="min-w-[120px] text-center">إجمالي الإيجار (ريال)</TableHead>
                      <TableHead className="min-w-[120px] text-center">المبلغ المدفوع (ريال)</TableHead>
                      <TableHead className="min-w-[120px] text-center">الرصيد (ريال)</TableHead>
                      <TableHead className="min-w-[180px] text-center">حالة العقد</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {tenants.map((tenant) => {
                      const property = properties.find(p => p.id === tenant.propertyId);
                      const tenantPayments = payments.filter(p => p.tenantId === tenant.tenantId);

                      const totalDueForTenant = tenantPayments.reduce((sum, p) => sum + p.amountDue, 0);
                      const totalPaidByTenant = tenantPayments.reduce((sum, p) => sum + p.amountPaid, 0);
                      const tenantBalance = totalDueForTenant - totalPaidByTenant;

                      let contractStatusDisplay = '-';
                      let badgeVariant: BadgeProps['variant'] = 'outline';
                      let badgeClassName = 'text-muted-foreground';
                      let printBadgeClass = '';

                      if (tenant.contractEndDate) {
                        try {
                          const endDate = parseISO(tenant.contractEndDate);
                          const today = new Date();
                          const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
                          const endDateStart = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());

                          if (isFuture(endDateStart) || differenceInDays(endDateStart, todayStart) === 0) {
                            const remainingDays = differenceInDays(endDateStart, todayStart);
                            if (remainingDays <= 90) {
                              contractStatusDisplay = `قرب الانتهاء (${remainingDays} ${remainingDays === 0 ? 'اليوم' : remainingDays === 1 ? 'يوم' : 'أيام'} متبقية)`;
                              badgeVariant = 'destructive';
                              badgeClassName = 'text-destructive-foreground';
                              printBadgeClass = 'badge-destructive-print';
                            } else {
                              contractStatusDisplay = 'العقد ساري';
                              badgeVariant = 'default';
                              badgeClassName = 'bg-green-600 text-primary-foreground hover:bg-green-700 border-green-600';
                              printBadgeClass = 'badge-default-print';
                            }
                          } else {
                            contractStatusDisplay = `منتهي منذ ${format(endDate, 'yyyy/MM/dd', { locale: arSA })}`;
                            badgeVariant = 'secondary';
                            badgeClassName = 'bg-yellow-400 text-black hover:bg-yellow-500 border-yellow-500';
                            printBadgeClass = 'badge-secondary-print';
                          }
                        } catch (e) {
                          contractStatusDisplay = 'تاريخ خاطئ';
                          badgeVariant = 'destructive';
                          badgeClassName = 'text-destructive-foreground';
                          printBadgeClass = 'badge-destructive-print';
                        }
                      }

                      return (
                        <TableRow key={tenant.tenantId}>
                          <TableCell className="font-medium">{tenant.tenantName}</TableCell>
                          <TableCell>{property?.name || '-'}</TableCell>
                          <TableCell>{tenant.contractIdentifier || tenant.tenantId}</TableCell>
                          <TableCell className="text-center">{totalDueForTenant.toLocaleString()} ريال</TableCell>
                          <TableCell className="text-center">{totalPaidByTenant.toLocaleString()} ريال</TableCell>
                          <TableCell className="text-center">
                            <Badge
                                variant={tenantBalance === 0 ? "default" : (tenantBalance < 0 ? "secondary" : "destructive")}
                                className={cn(tenantBalance === 0 ? "bg-green-500 hover:bg-green-600 text-primary-foreground" : "", "badge-print", tenantBalance === 0 ? "badge-default-print" : tenantBalance < 0 ? "badge-secondary-print" : "badge-destructive-print")}
                            >
                              {Math.abs(tenantBalance).toLocaleString()} ريال
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant={badgeVariant} className={cn(badgeClassName, 'badge-print', printBadgeClass)}>
                              {contractStatusDisplay}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">لا توجد بيانات حركة مستأجرين لعرضها في التقرير.</p>
            )}
          </div>
        </ScrollArea>

        <DialogFooter className="pt-4 border-t no-print">
          <Button variant="outline" onClick={onClose}>
            <XIcon className="me-2 h-4 w-4" /> إغلاق
          </Button>
          <Button onClick={handlePrint} disabled={tenants.length === 0}>
            <Printer className="me-2 h-4 w-4" /> طباعة التقرير
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
