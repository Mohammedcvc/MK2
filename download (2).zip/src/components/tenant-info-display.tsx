
import type { Tenant } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { User, CalendarDays, FileText, Tag, Percent } from 'lucide-react';
import { format } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { RENT_TYPES, TAX_RATES, getLabelForValue } from '@/lib/constants';
import { Button } from './ui/button'; // Added Button import

interface TenantInfoDisplayProps {
  tenant: Tenant;
}

function DetailItem({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-start space-x-3 space-x-reverse mb-3">
      <Icon className="h-5 w-5 text-primary mt-1" />
      <div>
        <p className="text-sm text-muted-foreground">{label}</p>
        <div className="font-medium">{value}</div>
      </div>
    </div>
  );
}

export function TenantInfoDisplay({ tenant }: TenantInfoDisplayProps) {
  return (
    <Card className="shadow-sm">
      <CardHeader>
        <CardTitle className="text-xl">بيانات المستأجر والعقد</CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
        <DetailItem icon={User} label="اسم المستأجر" value={tenant.tenantName} />
        <DetailItem icon={Tag} label="رقم المستأجر" value={tenant.tenantId} />
        <DetailItem 
          icon={CalendarDays} 
          label="تاريخ بداية العقد" 
          value={format(new Date(tenant.contractStartDate), 'PPP', { locale: arSA })} 
        />
        <DetailItem 
          icon={CalendarDays} 
          label="تاريخ نهاية العقد" 
          value={format(new Date(tenant.contractEndDate), 'PPP', { locale: arSA })} 
        />
        <DetailItem icon={Tag} label="قيمة العقد" value={`${tenant.contractValue.toLocaleString()} ريال`} />
        <DetailItem icon={Tag} label="نوع الإيجار" value={getLabelForValue(RENT_TYPES, tenant.rentType)} />
        <DetailItem icon={Percent} label="الضريبة" value={getLabelForValue(TAX_RATES, tenant.taxRate)} />
        
        {tenant.contractAttachments && tenant.contractAttachments.length > 0 && (
          <div className="md:col-span-2">
            <div className="flex items-start space-x-3 space-x-reverse mb-3">
              <FileText className="h-5 w-5 text-primary mt-1" />
              <div>
                <p className="text-sm text-muted-foreground">مرفقات العقد</p>
                <ul className="list-none p-0 m-0 font-medium">
                  {tenant.contractAttachments.map(att => (
                    <li key={att.name} className="mt-1">
                       <Button variant="link" asChild className="p-0 h-auto">
                        <a href={att.url} target="_blank" rel="noopener noreferrer" className="flex items-center text-primary hover:underline">
                           <FileText className="h-4 w-4 me-1" /> {att.name}
                        </a>
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
