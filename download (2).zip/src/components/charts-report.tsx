
'use client';

import { useMemo, useState } from 'react';
import type { Payment, Expense, Tenant, Property, InheritorTransaction, Inheritor } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Printer, ArrowRight, BarChartHorizontalBig, PieChart as PieChartIcon, User as UserIcon } from 'lucide-react';
import { Bar, BarChart, Pie, PieChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, Cell } from 'recharts';
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent, ChartLegend, ChartLegendContent } from "@/components/ui/chart";
import { PAYMENT_STATUSES, getLabelForValue, INHERITOR_OPERATION_TYPES } from '@/lib/constants';
import { format, parseISO } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { cn } from '@/lib/utils';

interface ChartsReportProps {
  payments: Payment[];
  expenses: Expense[];
  tenants: Tenant[];
  properties: Property[];
  reportTitle: string;
  onBackToDashboard?: () => void;
  inheritorTransactions?: InheritorTransaction[];
  deceasedInheritors?: Inheritor[]; 
}

const CHART_COLORS = ["hsl(var(--chart-1))", "hsl(var(--chart-2))", "hsl(var(--chart-3))", "hsl(var(--chart-4))", "hsl(var(--chart-5))"];

export function ChartsReport({
  payments,
  expenses,
  tenants,
  properties,
  reportTitle,
  onBackToDashboard,
  inheritorTransactions,
  deceasedInheritors, 
}: ChartsReportProps) {

  const [selectedInheritorId, setSelectedInheritorId] = useState<string | undefined>(undefined);

  const incomeVsExpensesData = useMemo(() => {
    const totalIncome = payments.reduce((sum, p) => sum + p.amountPaid, 0);
    const totalExpensesAmount = expenses.reduce((sum, e) => sum + e.amount, 0);
    const data = [
      { name: 'الإيرادات', total: totalIncome, fill: "var(--color-income)" },
      { name: 'المصروفات', total: totalExpensesAmount, fill: "var(--color-expenses)" },
    ];

    if (inheritorTransactions) {
      const totalInheritorWithdrawals = inheritorTransactions
        .filter(t => t.amount < 0)
        .reduce((sum, t) => sum + Math.abs(t.amount), 0);
      data.push({ name: 'سحوبات الورثة', total: totalInheritorWithdrawals, fill: "var(--color-withdrawals)" });
    }
    return data;
  }, [payments, expenses, inheritorTransactions]);

  const incomeVsExpensesChartConfig = {
    total: {
      label: "المبلغ (ريال)",
    },
    income: {
      label: "الإيرادات",
      color: "hsl(var(--chart-2))",
    },
    expenses: {
      label: "المصروفات",
      color: "hsl(var(--chart-1))",
    },
    withdrawals: {
      label: "سحوبات الورثة",
      color: "hsl(var(--chart-3))",
    }
  } satisfies ChartConfig;


  const paymentStatusData = useMemo(() => {
    const statusCounts = payments.reduce((acc, payment) => {
      const statusLabel = getLabelForValue(PAYMENT_STATUSES, payment.status);
      acc[statusLabel] = (acc[statusLabel] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return Object.entries(statusCounts).map(([name, value], index) => ({
      name,
      value,
      fill: CHART_COLORS[index % CHART_COLORS.length],
    }));
  }, [payments]);

  const paymentStatusChartConfig = useMemo(() => {
    const config: ChartConfig = {};
    paymentStatusData.forEach(item => {
      config[item.name] = { label: item.name, color: item.fill };
    });
    return config;
  }, [paymentStatusData]);

  // --- Inheritor Specific Data ---
  const selectedInheritorTransactions = useMemo(() => {
    if (!selectedInheritorId || !inheritorTransactions) return [];
    return inheritorTransactions.filter(t => t.inheritorId === selectedInheritorId);
  }, [selectedInheritorId, inheritorTransactions]);

  const inheritorFinancialSummaryChartData = useMemo(() => {
    if (!selectedInheritorId || selectedInheritorTransactions.length === 0) return [];
    const totalCredits = selectedInheritorTransactions
      .filter(t => t.amount > 0)
      .reduce((sum, t) => sum + t.amount, 0);
    const totalDebits = selectedInheritorTransactions
      .filter(t => t.amount < 0)
      .reduce((sum, t) => sum + Math.abs(t.amount), 0);

    return [
      { name: 'نصيب (له)', total: totalCredits, fill: "hsl(var(--chart-2))" }, 
      { name: 'سحوبات (عليه)', total: totalDebits, fill: "hsl(var(--chart-1))" }, 
    ];
  }, [selectedInheritorId, selectedInheritorTransactions]);

  const inheritorBalanceChartConfig = {
    total: {
      label: "المبلغ (ريال)",
    },
    credits: { 
      label: "نصيب (له)",
      color: "hsl(var(--chart-2))",
    },
    debits: { 
      label: "سحوبات (عليه)",
      color: "hsl(var(--chart-1))",
    },
  } satisfies ChartConfig;
  // --- End Inheritor Specific Data ---

  const handlePrint = () => {
    const printContentElement = document.getElementById('charts-report-content');
    const printContent = printContentElement ? printContentElement.innerHTML.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';
    const reportTitleSafe = reportTitle.replace(/`/g, '\\`').replace(/\$\{/g, '\\${');

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      const printHtml = `
        <html>
          <head>
            <title>${reportTitleSafe}</title>
            <style>
              body { font-family: "Sakkal Majalla", Arial, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
              .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
              .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
              .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
              .chart-section { margin-bottom: 30px; page-break-inside: avoid; }
              .chart-title { font-size: 13pt; font-weight: bold; margin-bottom: 10px; text-align: center; }
              .recharts-responsive-container { width: 100% !important; height: 350px !important; }
              .recharts-legend-wrapper { display: flex; justify-content: center; }
              .recharts-default-legend { padding:0 !important; margin: 0 !important; }
              .recharts-legend-item { margin-right: 10px !important; }
              .no-print { display: none !important; }
              table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 11pt; }
              th, td { border: 1px solid #ddd; padding: 6px; text-align: right; font-weight: 500; }
              th { background-color: #f2f2f2; font-weight: bold; }
              .amount-positive { color: green !important; }
              .amount-negative { color: red !important; }
            </style>
          </head>
          <body>
            <div class="print-header">
              <h1>${reportTitleSafe}</h1>
              <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
            </div>
            ${printContent}
          </body>
        </html>`;
      printWindow.document.write(printHtml);
      printWindow.document.close();
      printWindow.focus();
      setTimeout(() => {
        printWindow.print();
        printWindow.close();
      }, 1000);
    }
  };


  return (
    <Card className="shadow-lg rounded-xl w-full">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg font-semibold flex items-center">
              <BarChartHorizontalBig className="me-3 h-7 w-7 text-primary" />
              {reportTitle}
            </CardTitle>
            <CardDescription className="text-sm font-semibold">
              عرض بياني للمؤشرات الرئيسية.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2 no-print">
            {onBackToDashboard && (
              <Button variant="outline" size="sm" onClick={onBackToDashboard}>
                <ArrowRight className="ms-2 h-4 w-4" />
                العودة إلى لوحة التحكم
              </Button>
            )}
            <Button onClick={handlePrint} variant="outline" size="sm">
              <Printer className="me-2 h-4 w-4" />
              طباعة التقرير
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-8" id="charts-report-content">
        <section className="chart-section">
          <h3 className="text-md font-semibold mb-4 text-center chart-title">ملخص الإيرادات والمصروفات {inheritorTransactions && !deceasedInheritors && "وسحوبات الورثة"}</h3>
          <ChartContainer config={incomeVsExpensesChartConfig} className="h-[300px] w-full">
            <BarChart accessibilityLayer data={incomeVsExpensesData} layout="vertical" margin={{ right: 20, left: 20 }}>
              <XAxis type="number" hide />
              <YAxis
                dataKey="name"
                type="category"
                tickLine={false}
                axisLine={false}
                tickMargin={10}
                width={100}
              />
              <ChartTooltip cursor={false} content={<ChartTooltipContent hideLabel />} />
              <Bar dataKey="total" radius={5}>
                 {incomeVsExpensesData.map((entry) => (
                    <Cell key={`cell-${entry.name}`} fill={entry.fill} />
                  ))}
              </Bar>
            </BarChart>
          </ChartContainer>
        </section>

        <section className="chart-section">
          <h3 className="text-md font-semibold mb-4 text-center chart-title">توزيع حالات الدفعات</h3>
           {paymentStatusData.length > 0 ? (
            <ChartContainer config={paymentStatusChartConfig} className="h-[300px] w-full">
                <PieChart accessibilityLayer>
                <ChartTooltip content={<ChartTooltipContent hideLabel nameKey="name" />} />
                <Pie
                    data={paymentStatusData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    labelLine={false}
                    label={({ cx, cy, midAngle, innerRadius, outerRadius, percent, index, name }) => {
                      const RADIAN = Math.PI / 180;
                      const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                      const x = cx + radius * Math.cos(-midAngle * RADIAN);
                      const y = cy + radius * Math.sin(-midAngle * RADIAN);
                      return (
                        <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central" fontSize="10px">
                          {`${name} (${(percent * 100).toFixed(0)}%)`}
                        </text>
                      );
                    }}
                  >
                  {paymentStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                  </Pie>
                  <ChartLegend content={<ChartLegendContent nameKey="name"/>} />
              </PieChart>
            </ChartContainer>
           ) : (
            <p className="text-center text-muted-foreground">لا توجد بيانات دفعات لعرض توزيع الحالات.</p>
           )}
        </section>

        {deceasedInheritors && deceasedInheritors.length > 0 && inheritorTransactions && (
          <section className="chart-section border-t pt-6 mt-6">
            <h3 className="text-md font-semibold mb-4 text-center chart-title">تحليل مالي للوارث</h3>
            <div className="mb-4 no-print">
              <Select onValueChange={setSelectedInheritorId} value={selectedInheritorId}>
                <SelectTrigger className="w-full md:w-[280px] mx-auto">
                  <SelectValue placeholder="اختر وريث لعرض تحليله المالي..." />
                </SelectTrigger>
                <SelectContent>
                  {deceasedInheritors.map(inheritor => (
                    <SelectItem key={inheritor.id} value={inheritor.id}>
                      {inheritor.name} {inheritor.sharePercentage ? `(${inheritor.sharePercentage}%)` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedInheritorId && inheritorFinancialSummaryChartData && inheritorFinancialSummaryChartData.length > 0 && (
              <>
                <ChartContainer config={inheritorBalanceChartConfig} className="h-[250px] w-full mt-4">
                  <BarChart accessibilityLayer data={inheritorFinancialSummaryChartData} layout="vertical" margin={{ right: 20, left: 20 }}>
                    <XAxis type="number" hide />
                    <YAxis dataKey="name" type="category" tickLine={false} axisLine={false} tickMargin={10} width={100} />
                    <ChartTooltip cursor={false} content={<ChartTooltipContent hideLabel />} />
                    <Bar dataKey="total" radius={4}>
                      {inheritorFinancialSummaryChartData.map((entry) => (
                        <Cell key={`cell-inheritor-${entry.name}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ChartContainer>

                {selectedInheritorTransactions.length > 0 && (
                  <div className="mt-6">
                    <h4 className="text-sm font-semibold mb-2 text-center">تفاصيل حركات الوارث: {deceasedInheritors.find(i => i.id === selectedInheritorId)?.name}</h4>
                    <div className="overflow-x-auto rounded-md border max-h-80">
                      <Table className="text-xs">
                        <TableHeader>
                          <TableRow>
                            <TableHead className="min-w-[80px]">التاريخ</TableHead>
                            <TableHead className="min-w-[150px]">البيان</TableHead>
                            <TableHead className="min-w-[100px]">نوع العملية</TableHead>
                            <TableHead className="min-w-[100px] text-center">المبلغ</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {selectedInheritorTransactions.map(tx => (
                            <TableRow key={tx.id}>
                              <TableCell>{format(parseISO(tx.date), 'yyyy/MM/dd', { locale: arSA })}</TableCell>
                              <TableCell>{tx.description}</TableCell>
                              <TableCell>{getLabelForValue(INHERITOR_OPERATION_TYPES, tx.operationType)}</TableCell>
                              <TableCell className={cn("text-center font-medium", tx.amount >= 0 ? "text-green-600 amount-positive" : "text-red-600 amount-negative")}>
                                {tx.amount.toLocaleString()} ريال
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}
              </>
            )}
            {!selectedInheritorId && <p className="text-center text-muted-foreground mt-4">الرجاء اختيار وريث لعرض البيانات.</p>}
            {selectedInheritorId && (!inheritorFinancialSummaryChartData || inheritorFinancialSummaryChartData.length === 0) && <p className="text-center text-muted-foreground mt-4">لا توجد بيانات مالية لهذا الوارث.</p>}
          </section>
        )}

      </CardContent>
    </Card>
  );
}
