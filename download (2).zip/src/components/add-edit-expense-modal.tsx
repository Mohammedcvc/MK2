
'use client';

import type { Expense } from '@/types';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, SubmitHandler } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Loader2 } from 'lucide-react';
import { format, parse, parseISO, isValid, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useState, useEffect } from 'react';

const expenseFormSchema = z.object({
  name: z.string().min(3, { message: 'اسم المصروف يجب أن لا يقل عن 3 أحرف.' }),
  amount: z.coerce.number().positive({ message: 'مبلغ المصروف يجب أن يكون رقمًا موجبًا.' }),
  date: z.date({ required_error: 'تاريخ المصروف مطلوب.' }),
  description: z.string().min(1, { message: 'وصف المصروف مطلوب.' }),
});

export type ExpenseFormValues = z.infer<typeof expenseFormSchema>;

interface AddEditExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: ExpenseFormValues, expenseIdToUpdate?: string) => Promise<void>;
  initialData?: Expense | null; 
}

export function AddEditExpenseModal({ isOpen, onClose, onSubmit, initialData }: AddEditExpenseModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);

  const form = useForm<ExpenseFormValues>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: initialData
      ? {
          ...initialData,
          date: initialData.date ? parseISO(initialData.date) : new Date(),
        }
      : {
          name: '',
          amount: 0,
          date: new Date(),
          description: '',
        },
  });

  useEffect(() => {
    if (isOpen) {
      form.reset(
        initialData
          ? {
              ...initialData,
              date: initialData.date ? parseISO(initialData.date) : new Date(),
            }
          : {
              name: '',
              amount: 0,
              date: new Date(),
              description: '',
            }
      );
      setIsCalendarOpen(false);
    }
  }, [isOpen, initialData, form]);

  const handleSubmit: SubmitHandler<ExpenseFormValues> = async (data) => {
    setIsSubmitting(true);
    await onSubmit(data, initialData?.id);
    setIsSubmitting(false);
  };

  const currentYear = getYear(new Date());
  const fromYear = subYears(new Date(), 10).getFullYear();
  const toYear = addYears(new Date(), 10).getFullYear();

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{initialData ? 'تعديل بيانات المصروف' : 'إضافة مصروف جديد'}</DialogTitle>
          <DialogDescription>
            {initialData ? 'قم بتحديث معلومات المصروف.' : 'إضافة مصروف جديد للنظام.'}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-2 max-h-[70vh] overflow-y-auto px-1">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>اسم المصروف</FormLabel>
                  <FormControl>
                    <Input placeholder="مثال: فاتورة كهرباء" {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>مبلغ المصروف (ريال)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="مثال: 350.50" {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>تاريخ المصروف</FormLabel>
                  <Popover open={isCalendarOpen} onOpenChange={setIsCalendarOpen}>
                    <PopoverTrigger asChild>
                      <div className="relative">
                        <Input
                          placeholder="YYYY-MM-DD"
                          value={field.value ? format(field.value, 'yyyy-MM-dd') : ''}
                          onChange={(e) => {
                            const dateString = e.target.value;
                            try {
                              const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                              if (isValid(parsedDate)) {
                                field.onChange(parsedDate);
                              } else if (dateString === '') {
                                field.onChange(undefined);
                              }
                            } catch {
                              field.onChange(undefined);
                            }
                          }}
                          className={cn("pe-10 text-center bg-card", !field.value && "text-muted-foreground")}
                        />
                        <CalendarIcon
                          className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                          onClick={() => setIsCalendarOpen(prev => !prev)}
                        />
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={(date) => { field.onChange(date); setIsCalendarOpen(false); }}
                        captionLayout="dropdown-buttons"
                        fromYear={fromYear}
                        toYear={toYear}
                        defaultMonth={field.value || new Date()}
                        initialFocus
                        dir="rtl"
                        locale={arSA}
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>بيان المصروف</FormLabel>
                  <FormControl>
                    <Textarea placeholder="مثال: فاتورة كهرباء مكتب الإدارة لشهر مايو" {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                إلغاء
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                {initialData ? 'حفظ التغييرات' : 'إضافة المصروف'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
