
'use client';

import { useAppContext } from '@/contexts/app-context';
import { useMemo, useState } from 'react';
import type { Inheritor, InheritorTransaction } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption, TableFooter } from '@/components/ui/table';
import { Printer, FileText as FileTextIcon, Eye, Download, Sigma, Percent, User, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';
import { InheritorReportModal } from '@/components/inheritor-report-modal'; // Import the detailed report modal

interface InheritorBalance {
  id: string;
  name: string;
  sharePercentage?: number;
  totalCredit: number;
  totalDebit: number;
  netBalance: number;
}

interface InheritorBalancesReportProps {
  onBackToDashboard?: () => void;
}

export function InheritorBalancesReport({ onBackToDashboard }: InheritorBalancesReportProps) {
  const { deceasedInheritors, deceasedInheritorTransactions } = useAppContext();
  const { toast } = useToast();

  const [isInheritorDetailModalOpen, setIsInheritorDetailModalOpen] = useState(false);
  const [selectedInheritorForDetail, setSelectedInheritorForDetail] = useState<Inheritor | null>(null);
  const [selectedInheritorTransactions, setSelectedInheritorTransactions] = useState<InheritorTransaction[]>([]);


  const inheritorBalances = useMemo<InheritorBalance[]>(() => {
    return deceasedInheritors.map(inheritor => {
      const transactions = deceasedInheritorTransactions.filter(t => t.inheritorId === inheritor.id);
      const totalCredit = transactions
        .filter(t => t.amount > 0)
        .reduce((sum, t) => sum + t.amount, 0);
      const totalDebit = transactions
        .filter(t => t.amount < 0)
        .reduce((sum, t) => sum + Math.abs(t.amount), 0);
      const netBalance = totalCredit - totalDebit;
      return {
        id: inheritor.id,
        name: inheritor.name,
        sharePercentage: inheritor.sharePercentage,
        totalCredit,
        totalDebit,
        netBalance,
      };
    });
  }, [deceasedInheritors, deceasedInheritorTransactions]);

  const overallTotals = useMemo(() => {
    const totalCredit = inheritorBalances.reduce((sum, ib) => sum + ib.totalCredit, 0);
    const totalDebit = inheritorBalances.reduce((sum, ib) => sum + ib.totalDebit, 0);
    const netBalance = totalCredit - totalDebit;
    return { totalCredit, totalDebit, netBalance };
  }, [inheritorBalances]);

  const handleViewInheritorDetails = (inheritorId: string) => {
    const inheritor = deceasedInheritors.find(i => i.id === inheritorId);
    if (inheritor) {
      const transactions = deceasedInheritorTransactions.filter(t => t.inheritorId === inheritorId);
      setSelectedInheritorForDetail(inheritor);
      setSelectedInheritorTransactions(transactions);
      setIsInheritorDetailModalOpen(true);
    } else {
      toast({
        title: "خطأ",
        description: "لم يتم العثور على بيانات الوارث.",
        variant: "destructive",
      });
    }
  };

  const handlePrint = () => {
    const printContent = document.getElementById('inheritor-balances-report-content')?.innerHTML;
    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>تقرير أرصدة الورثة</title>
              <style>
                body { font-family: var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 10pt; }
                .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                .print-header h1 { font-size: 20px; color: #333; margin-bottom: 5px; }
                .print-header p { font-size: 12px; color: #666; margin: 2px 0; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 9pt; }
                th, td { border: 1px solid #ddd; padding: 6px; text-align: right; }
                th { background-color: #f2f2f2; font-weight: bold; }
                .total-row td { font-weight: bold; background-color: #f9f9f9; }
                .amount-positive { color: green !important; }
                .amount-negative { color: red !important; }
                .no-print { display: none; }
                .inheritor-name-link { color: #29ABE2; text-decoration: underline; cursor: pointer; }
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>تقرير أرصدة الورثة الإجمالي</h1>
                <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
              </div>
              ${printContent.replace(/class="inheritor-name-link"/g, 'style="color: #000; text-decoration: none;"')}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    }
  };

  const handlePreview = () => {
    toast({
      title: "المعاينة",
      description: "سيتم عرض تفاصيل هذا التقرير في نافذة منبثقة (ميزة قيد التطوير).",
      variant: "default",
    });
  };
  
  const handleExportPDF = () => {
    toast({
      title: "تحويل إلى PDF",
      description: "ميزة تحويل التقرير إلى PDF غير متوفرة حاليًا.",
      variant: "default",
    });
  };


  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-2xl flex items-center">
              <FileTextIcon className="me-3 h-7 w-7 text-primary" />
              تقرير أرصدة الورثة
            </CardTitle>
            <CardDescription>
              ملخص شامل لأرصدة جميع الورثة بناءً على الحركات المالية المسجلة. انقر على اسم الوارث لعرض تقريره التفصيلي.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
             {onBackToDashboard && (
              <Button variant="outline" size="sm" onClick={onBackToDashboard}>
                 <ArrowRight className="ms-2 h-4 w-4" /> 
                عودة
              </Button>
            )}
            <Button onClick={handlePrint} variant="outline" size="sm" disabled={inheritorBalances.length === 0}>
              <Printer className="me-2 h-4 w-4" />
              طباعة التقرير
            </Button>
            <Button onClick={handlePreview} variant="outline" size="sm" disabled={inheritorBalances.length === 0}>
              <Eye className="me-2 h-4 w-4" />
              معاينة
            </Button>
            <Button onClick={handleExportPDF} variant="outline" size="sm" disabled={inheritorBalances.length === 0}>
              <Download className="me-2 h-4 w-4" />
              تحويل PDF
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div id="inheritor-balances-report-content">
          {inheritorBalances.length > 0 ? (
            <div className="overflow-x-auto rounded-md border">
              <Table>
                <TableCaption>ملخص أرصدة الورثة. انقر على اسم الوارث لعرض تقريره التفصيلي.</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[150px]">اسم الوارث</TableHead>
                    <TableHead className="min-w-[100px] text-center">
                        <div className="flex items-center justify-center">
                            <Percent className="h-4 w-4 me-1" /> نسبة الإرث
                        </div>
                    </TableHead>
                    <TableHead className="min-w-[120px] text-center">إجمالي له (ريال)</TableHead>
                    <TableHead className="min-w-[120px] text-center">إجمالي عليه (ريال)</TableHead>
                    <TableHead className="min-w-[120px] text-center">صافي الرصيد (ريال)</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {inheritorBalances.map((inheritor) => (
                    <TableRow key={inheritor.id}>
                      <TableCell 
                        className="font-medium inheritor-name-link"
                        onClick={() => handleViewInheritorDetails(inheritor.id)}
                      >
                        {inheritor.name}
                      </TableCell>
                      <TableCell className="text-center">
                        {inheritor.sharePercentage !== undefined ? `${inheritor.sharePercentage.toFixed(2)}%` : 'غير محددة'}
                      </TableCell>
                      <TableCell className="text-center amount-positive">
                        {inheritor.totalCredit.toLocaleString()}
                      </TableCell>
                      <TableCell className="text-center amount-negative">
                        {inheritor.totalDebit.toLocaleString()}
                      </TableCell>
                      <TableCell className={`text-center font-semibold ${inheritor.netBalance >= 0 ? 'amount-positive' : 'amount-negative'}`}>
                        {inheritor.netBalance.toLocaleString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
                <TableFooter className="total-row bg-muted/50">
                  <TableRow>
                    <TableCell colSpan={2} className="font-bold text-lg">
                        <div className="flex items-center">
                            <Sigma className="h-5 w-5 me-2 text-primary" /> الإجماليات العامة
                        </div>
                    </TableCell>
                    <TableCell className="text-center font-bold text-lg amount-positive">
                      {overallTotals.totalCredit.toLocaleString()} ريال
                    </TableCell>
                    <TableCell className="text-center font-bold text-lg amount-negative">
                      {overallTotals.totalDebit.toLocaleString()} ريال
                    </TableCell>
                    <TableCell className={`text-center font-bold text-lg ${overallTotals.netBalance >= 0 ? 'amount-positive' : 'amount-negative'}`}>
                      {overallTotals.netBalance.toLocaleString()} ريال
                    </TableCell>
                  </TableRow>
                </TableFooter>
              </Table>
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              لا يوجد ورثة أو حركات مالية مسجلة لعرض التقرير.
            </p>
          )}
        </div>
      </CardContent>
      {selectedInheritorForDetail && (
        <InheritorReportModal
          isOpen={isInheritorDetailModalOpen}
          onClose={() => setIsInheritorDetailModalOpen(false)}
          inheritor={selectedInheritorForDetail}
          transactions={selectedInheritorTransactions}
          totalAmount={inheritorBalances.find(ib => ib.id === selectedInheritorForDetail.id)?.netBalance || 0}
        />
      )}
    </Card>
  );
}

