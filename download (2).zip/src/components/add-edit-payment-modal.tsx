
'use client';

import type { Payment, PaymentStatus } from '@/types';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, SubmitHandler } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarIcon, Loader2 } from 'lucide-react';
import { format, parse, parseISO, isValid, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { PAYMENT_STATUSES } from '@/lib/constants';
import { useState, useEffect } from 'react';

const paymentFormSchema = z.object({
  dueDate: z.date({ required_error: 'تاريخ الاستحقاق مطلوب.' }),
  amountDue: z.coerce.number().positive({ message: 'مبلغ الاستحقاق يجب أن يكون رقمًا موجبًا.' }),
  amountPaid: z.coerce.number().min(0, { message: 'المبلغ المدفوع لا يمكن أن يكون سالبًا.' }),
  description: z.string().min(1, { message: 'وصف الدفعة مطلوب.' }),
  status: z.enum(['paid', 'pending', 'overdue', 'due'], { required_error: 'حالة الدفعة مطلوبة.' }),
});

export type PaymentFormValues = z.infer<typeof paymentFormSchema>;

interface AddEditPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: PaymentFormValues, paymentId?: string) => void;
  initialData?: Payment | null; // For editing
  tenantId: string; // Needed for context, though not directly in form
}

export function AddEditPaymentModal({ isOpen, onClose, onSubmit, initialData, tenantId }: AddEditPaymentModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDueDateCalendarOpen, setIsDueDateCalendarOpen] = useState(false);

  const form = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: initialData
      ? {
          ...initialData,
          dueDate: initialData.dueDate ? parseISO(initialData.dueDate) : new Date(),
        }
      : {
          dueDate: new Date(),
          amountDue: 0,
          amountPaid: 0,
          description: '',
          status: 'pending' as PaymentStatus,
        },
  });

  useEffect(() => {
    if (isOpen) {
      form.reset(
        initialData
          ? {
              ...initialData,
              dueDate: initialData.dueDate ? parseISO(initialData.dueDate) : new Date(),
            }
          : {
              dueDate: new Date(),
              amountDue: 0,
              amountPaid: 0,
              description: '',
              status: 'pending' as PaymentStatus,
            }
      );
      setIsDueDateCalendarOpen(false);
    }
  }, [isOpen, initialData, form]);

  const handleSubmit: SubmitHandler<PaymentFormValues> = async (data) => {
    setIsSubmitting(true);
    await onSubmit(data, initialData?.paymentId);
    setIsSubmitting(false);
  };

  const currentYear = getYear(new Date());
  const fromYear = subYears(new Date(), 10).getFullYear();
  const toYear = addYears(new Date(), 10).getFullYear();

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{initialData ? 'تعديل بيانات الدفعة' : 'إضافة دفعة جديدة'}</DialogTitle>
          <DialogDescription>
            {initialData ? 'قم بتحديث معلومات الدفعة.' : `إضافة دفعة جديدة للمستأجر.`}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 py-2">
            <FormField
              control={form.control}
              name="dueDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>تاريخ الاستحقاق</FormLabel>
                  <Popover open={isDueDateCalendarOpen} onOpenChange={setIsDueDateCalendarOpen}>
                    <PopoverTrigger asChild>
                        <div className="relative">
                          <Input
                            placeholder="YYYY-MM-DD"
                            value={field.value ? format(field.value, 'yyyy-MM-dd') : ''}
                            onChange={(e) => {
                              const dateString = e.target.value;
                              try {
                                const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                                if (isValid(parsedDate)) {
                                  field.onChange(parsedDate);
                                } else if (dateString === '') {
                                  field.onChange(undefined); 
                                }
                              } catch {
                                field.onChange(undefined);
                              }
                            }}
                            className={cn("pe-10 text-center bg-card", !field.value && "text-muted-foreground")}
                          />
                          <CalendarIcon
                            className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                            onClick={() => setIsDueDateCalendarOpen(prev => !prev)}
                            aria-label="فتح التقويم"
                          />
                        </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={(date) => {
                          field.onChange(date);
                          setIsDueDateCalendarOpen(false);
                        }}
                        captionLayout="dropdown-buttons"
                        fromYear={fromYear}
                        toYear={toYear}
                        defaultMonth={field.value || new Date()}
                        initialFocus
                        dir="rtl"
                        locale={arSA}
                        disabled={(date) => date < new Date("1900-01-01")}
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amountDue"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>مبلغ الاستحقاق (ريال)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="مثال: 5000" {...field} className="bg-card text-center" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="amountPaid"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>المبلغ المدفوع (ريال)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="مثال: 2500" {...field} className="bg-card text-center" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>وصف الدفعة</FormLabel>
                  <FormControl>
                    <Textarea placeholder="مثال: دفعة إيجار شهر يناير" {...field} className="bg-card" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="status"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>حالة الدفعة</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-card">
                        <SelectValue placeholder="اختر حالة الدفعة" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {PAYMENT_STATUSES.map(status => (
                        <SelectItem key={status.value} value={status.value}>
                          {status.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                إلغاء
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                {initialData ? 'حفظ التغييرات' : 'إضافة الدفعة'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
