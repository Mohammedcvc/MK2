
import type { Payment, Attachment } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableCaption,
  TableFooter
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge, type BadgeProps } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Paperclip, PlusCircle, Edit3, Trash2, ChevronDown, UploadCloud, FileText, X, Sigma } from 'lucide-react';
import { format, parseISO, isToday, isBefore, differenceInCalendarDays } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { getPaymentBalance } from '@/types';
import { PAYMENT_STATUSES, getLabelForValue, PAYMENT_STATUS_BADGE_VARIANT } from '@/lib/constants';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cn } from '@/lib/utils';
import React, { useMemo, useRef } from 'react';
import { useAppContext } from '@/contexts/app-context';

interface PaymentHistoryTableProps {
  payments: Payment[];
  onAddPayment: () => void;
  onEditPayment: (payment: Payment) => void;
  onDeletePayment: (payment: Payment) => void;
  onAddAttachment: (paymentId: string, file: File) => Promise<void>;
  onDeleteAttachment: (paymentId: string, attachmentName: string) => Promise<void>;
  canEdit?: boolean;
  canDelete?: boolean;
}

export function PaymentHistoryTable({ 
  payments, 
  onAddPayment, 
  onEditPayment, 
  onDeletePayment,
  onAddAttachment,
  onDeleteAttachment,
  canEdit,
  canDelete
}: PaymentHistoryTableProps) {
  
  const fileInputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const { currentUser } = useAppContext();
  const canAddPayment = currentUser?.permissions?.canAdd ?? true; 
  const canAddAttachment = currentUser?.permissions?.canAdd ?? false;


  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>, paymentId: string) => {
    const file = event.target.files?.[0];
    if (file) {
      await onAddAttachment(paymentId, file);
      if (event.target) {
        event.target.value = ''; 
      }
    }
  };

  const triggerFileInput = (paymentId: string) => {
    fileInputRefs.current[paymentId]?.click();
  };

  const totals = useMemo(() => {
    const totalDue = payments.reduce((sum, p) => sum + p.amountDue, 0);
    const totalPaid = payments.reduce((sum, p) => sum + p.amountPaid, 0);
    const totalBalance = totalDue - totalPaid;
    return { totalDue, totalPaid, totalBalance };
  }, [payments]);

  return (
    <Card className="shadow-sm mt-6">
      <Accordion type="single" collapsible className="w-full" defaultValue="item-1">
        <AccordionItem value="item-1" className="border-b-0">
          <div className="flex justify-between items-center w-full px-6 py-3 hover:bg-muted/20 rounded-t-md">
           <AccordionTrigger
              className={cn(
                "flex-grow py-1 hover:no-underline flex justify-between items-center w-full [&[data-state=open]>svg]:ms-auto [&[data-state=closed]>svg]:me-auto"
              )}
            >
              <CardTitle className="text-xl flex items-center">
                سجل الدفعات
              </CardTitle>
            </AccordionTrigger>
             <div className="flex-shrink-0 mx-2">
                <TooltipProvider>
                <Tooltip>
                    <TooltipTrigger asChild>
                    <Button
                        variant="default"
                        size="sm"
                        onClick={(e) => { e.stopPropagation(); onAddPayment(); }}
                        className="me-4"
                        disabled={!canAddPayment}
                    >
                        <PlusCircle className="h-4 w-4 me-2" />
                        إضافة دفعة
                    </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                    <p>{!canAddPayment ? "لا تملك صلاحية الإضافة" : "إضافة دفعة جديدة"}</p>
                    </TooltipContent>
                </Tooltip>
                </TooltipProvider>
            </div>
          </div>


          <AccordionContent>
            <CardContent className="pt-2 pb-4 px-6">
              {payments.length === 0 ? (
                <p className="text-center text-muted-foreground py-4">لا توجد دفعات مسجلة لهذا المستأجر.</p>
              ) : (
                <div className="overflow-x-auto rounded-md border">
                <Table>
                  <TableCaption>قائمة بجميع دفعات المستأجر.</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[60px]">رقم الدفعة</TableHead>
                      <TableHead className="min-w-[90px]">تاريخ الاستحقاق</TableHead>
                      <TableHead className="min-w-[80px]">مبلغ الدفعة</TableHead>
                      <TableHead className="min-w-[70px]">المدفوع</TableHead>
                      <TableHead className="min-w-[70px]">الرصيد</TableHead>
                      <TableHead className="min-w-[150px]">بيان الدفعة</TableHead>
                      <TableHead className="text-center min-w-[100px]">الإجراءات</TableHead>
                      <TableHead className="min-w-[100px]">حالة الدفعة</TableHead>
                      <TableHead className="min-w-[130px]">المرفقات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payments.map((payment, index) => {
                      const balance = getPaymentBalance(payment);
                      const isEffectivelyPaid = balance === 0 && payment.amountDue > 0;
                      const isMarkedAsPaid = payment.status === 'paid';
                      const dueDateObj = parseISO(payment.dueDate);
                      
                      const now = new Date();
                      const startOfDueDate = new Date(dueDateObj.getFullYear(), dueDateObj.getMonth(), dueDateObj.getDate());
                      const startOfNow = new Date(now.getFullYear(), now.getMonth(), now.getDate());
                      const daysDifference = differenceInCalendarDays(startOfDueDate, startOfNow); 

                      let displayStatusLabel: string;
                      let displayStatusVariant: BadgeProps['variant'];
                      let displayStatusClassName: string | undefined;

                      if (isEffectivelyPaid || isMarkedAsPaid) {
                        displayStatusLabel = getLabelForValue(PAYMENT_STATUSES, 'paid');
                        displayStatusVariant = 'default';
                        displayStatusClassName = "bg-green-500 hover:bg-green-600 text-primary-foreground border-transparent";
                      } else if (payment.status === 'due') { // User explicitly set status to 'due'
                        displayStatusLabel = getLabelForValue(PAYMENT_STATUSES, 'due');
                        displayStatusVariant = 'outline';
                        displayStatusClassName = "border-orange-500 text-orange-700 bg-orange-100 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700 hover:bg-orange-200 dark:hover:bg-orange-800/40";
                      } else if (daysDifference >= 0 && daysDifference <= 10) { // Due today or within next 10 days
                        displayStatusLabel = "دفعه مستحقه";
                        displayStatusVariant = 'outline'; 
                        displayStatusClassName = "border-orange-500 text-orange-700 bg-orange-100 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700 hover:bg-orange-200 dark:hover:bg-orange-800/40";
                      } else if (daysDifference < 0) { // Overdue
                        const daysOverdueCount = Math.abs(daysDifference);
                        displayStatusLabel = `متأخرة (${daysOverdueCount} ${daysOverdueCount === 1 ? 'يوم' : 'أيام'})`;
                        displayStatusVariant = 'destructive';
                        displayStatusClassName = undefined; 
                      } else { // Fallback to explicitly set status if not paid, not due soon, and not overdue
                        displayStatusLabel = getLabelForValue(PAYMENT_STATUSES, payment.status);
                        displayStatusVariant = PAYMENT_STATUS_BADGE_VARIANT[payment.status] || 'outline';
                        displayStatusClassName = undefined;
                      }
                      
                      return (
                      <TableRow key={payment.paymentId}>
                        <TableCell>{101 + index}</TableCell>
                        <TableCell>{format(dueDateObj, 'yyyy/MM/dd', { locale: arSA })}</TableCell>
                        <TableCell>{payment.amountDue.toLocaleString()} ريال</TableCell>
                        <TableCell>{payment.amountPaid.toLocaleString()} ريال</TableCell>
                        <TableCell>{balance.toLocaleString()} ريال</TableCell>
                        <TableCell>{payment.description}</TableCell>
                        <TableCell className="text-center">
                          <TooltipProvider>
                            <div className="flex items-center justify-center space-x-1 space-x-reverse">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="text-primary hover:text-primary/90 h-8 w-8"
                                    onClick={() => onEditPayment(payment)}
                                    disabled={!canEdit}
                                  >
                                    <Edit3 className="h-4 w-4" />
                                    <span className="sr-only">تعديل بيانات الدفعة</span>
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{!canEdit ? "لا تملك صلاحية التعديل" : "تعديل بيانات الدفعة"}</p>
                                </TooltipContent>
                              </Tooltip>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="text-destructive hover:text-destructive/90 h-8 w-8"
                                    onClick={() => onDeletePayment(payment)}
                                    disabled={!canDelete}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                    <span className="sr-only">حذف بيانات الدفعة</span>
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف بيانات الدفعة"}</p>
                                </TooltipContent>
                              </Tooltip>
                            </div>
                          </TooltipProvider>
                        </TableCell>
                        <TableCell>
                          <Badge variant={displayStatusVariant} className={displayStatusClassName}>
                            {displayStatusLabel}
                          </Badge>
                        </TableCell>
                         <TableCell>
                          <div className="space-y-1">
                            {payment.paymentAttachments && payment.paymentAttachments.map(att => (
                              <div key={att.name} className="flex items-center justify-between text-xs group">
                                <Button variant="link" size="sm" asChild className="p-0 h-auto text-primary hover:underline flex-grow justify-start">
                                  <a href={att.url} target="_blank" rel="noopener noreferrer" className="flex items-center">
                                    <FileText className="h-3 w-3 me-1 flex-shrink-0" />
                                    <span className="truncate" title={att.name}>{att.name}</span>
                                  </a>
                                </Button>
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-5 w-5 text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                                        onClick={() => onDeleteAttachment(payment.paymentId, att.name)}
                                        disabled={!canDelete}
                                      >
                                        <X className="h-3 w-3" />
                                      </Button>
                                    </TooltipTrigger>
                                    <TooltipContent side="top"><p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف المرفق"}</p></TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              </div>
                            ))}
                            <input 
                              type="file" 
                              ref={el => fileInputRefs.current[payment.paymentId] = el} 
                              style={{ display: 'none' }} 
                              onChange={(e) => handleFileChange(e, payment.paymentId)}
                            />
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="w-full mt-1" 
                                    onClick={() => triggerFileInput(payment.paymentId)}
                                    disabled={!canAddAttachment} 
                                  >
                                    <UploadCloud className="h-3 w-3 me-1" /> إرفاق ملف
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent side="top"><p>{!canAddAttachment ? "لا تملك صلاحية الإضافة" : "إرفاق ملف جديد لهذه الدفعة"}</p></TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          </div>
                          {(!payment.paymentAttachments || payment.paymentAttachments.length === 0) && <p className="text-xs text-muted-foreground text-center py-1">لا توجد مرفقات</p>}
                        </TableCell>
                      </TableRow>
                      );
                    })}
                    </TableBody>
                    <TableFooter>
                      <TableRow className="bg-muted/50 hover:bg-muted/80">
                        <TableCell colSpan={2} className="font-semibold text-lg">
                          <div className="flex items-center">
                           <Sigma className="h-5 w-5 me-2 text-primary" /> الإجمالي
                          </div>
                        </TableCell>
                        <TableCell className="font-semibold text-md">{totals.totalDue.toLocaleString()} ريال</TableCell>
                        <TableCell className="font-semibold text-md">{totals.totalPaid.toLocaleString()} ريال</TableCell>
                        <TableCell className="font-semibold text-md">
                          <Badge 
                            variant={totals.totalBalance === 0 ? 'default' : (totals.totalBalance < 0 ? 'secondary' : 'destructive')}
                            className={cn(totals.totalBalance === 0 ? "bg-green-500 hover:bg-green-600 text-primary-foreground" : "", "text-sm px-2 py-1")}
                          >
                            {Math.abs(totals.totalBalance).toLocaleString()} ريال
                            {totals.totalBalance < 0 ? " (سداد إضافي)" : totals.totalBalance > 0 ? " (مستحق)" : ""}
                          </Badge>
                        </TableCell>
                        <TableCell colSpan={4}></TableCell>
                      </TableRow>
                    </TableFooter>
                  </Table>
                </div>
              )}
            </CardContent>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </Card>
  );
}

