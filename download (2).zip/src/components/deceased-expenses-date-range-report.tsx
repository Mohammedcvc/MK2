
'use client';

import { useState, useMemo } from 'react';
import { useAppContext } from '@/contexts/app-context';
import type { Expense } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { CalendarIcon, Printer, FileText as FileTextIcon, ArrowRight } from 'lucide-react';
import { format, parse, parseISO, isWithinInterval, isValid, startOfDay, endOfDay, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { ExpenseReportModal } from '@/components/expense-report-modal';

type ReportType = 'all' | 'dateRange';

interface DeceasedExpensesDateRangeReportProps {
  onBackToDashboard?: () => void;
}

export function DeceasedExpensesDateRangeReport({ onBackToDashboard }: DeceasedExpensesDateRangeReportProps) {
  const { deceasedExpenses } = useAppContext();
  const { toast } = useToast();

  const [reportType, setReportType] = useState<ReportType>('dateRange');
  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [isFromDateCalendarOpen, setIsFromDateCalendarOpen] = useState(false);
  const [isToDateCalendarOpen, setIsToDateCalendarOpen] = useState(false);

  const filteredExpenses = useMemo(() => {
    if (reportType === 'all') {
      return deceasedExpenses;
    }

    if (!fromDate || !toDate) {
      return [];
    }
    if (!isValid(fromDate) || !isValid(toDate)) return [];

    const startDate = startOfDay(fromDate);
    const endDate = endOfDay(toDate);

    if (endDate < startDate) return [];

    return deceasedExpenses.filter(expense => {
      try {
        const expenseDate = parseISO(expense.date);
        return isWithinInterval(expenseDate, { start: startDate, end: endDate });
      } catch (e) {
        return false;
      }
    });
  }, [deceasedExpenses, fromDate, toDate, reportType]);

  const totalFilteredAmount = useMemo(() => {
    return filteredExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  }, [filteredExpenses]);

  const handleViewReport = () => {
    if (reportType === 'dateRange') {
      if (!fromDate || !toDate) {
        toast({
          title: "الرجاء تحديد التواريخ",
          description: "يرجى تحديد تاريخ البداية وتاريخ النهاية لعرض التقرير.",
          variant: "destructive",
        });
        return;
      }
      const adjustedToDate = endOfDay(toDate);
      const adjustedFromDate = startOfDay(fromDate);

      if (adjustedToDate < adjustedFromDate) {
        toast({
          title: "خطأ في التواريخ",
          description: "تاريخ النهاية يجب أن يكون بعد أو نفس تاريخ البداية.",
          variant: "destructive",
        });
        return;
      }
    }

    if (filteredExpenses.length === 0) {
      toast({
        title: "لا توجد بيانات",
        description: reportType === 'all'
          ? "لا توجد مصروفات مسجلة لعرضها."
          : "لا توجد مصروفات مسجلة ضمن نطاق التواريخ المحدد.",
        variant: "default",
      });
      return;
    }
    setIsReportModalOpen(true);
  };

  const currentYear = getYear(new Date());
  const fromCalYear = subYears(new Date(), 10).getFullYear();
  const toCalYear = addYears(new Date(), 10).getFullYear();

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex-1">
                <CardTitle className="text-lg font-semibold flex items-center">
                <FileTextIcon className="me-3 h-7 w-7 text-primary" />
                تقرير مصروفات الورثة (حسب الفترة)
                </CardTitle>
                <CardDescription className="text-sm font-semibold">
                حدد فترة زمنية لعرض وطباعة تقرير المصروفات الخاص بالورثة.
                </CardDescription>
            </div>
            {onBackToDashboard && (
                <Button variant="outline" size="sm" onClick={onBackToDashboard}>
                    <ArrowRight className="ms-2 h-4 w-4" />
                    عودة
                </Button>
            )}
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <RadioGroup
            defaultValue="dateRange"
            onValueChange={(value: ReportType) => setReportType(value)}
            className="flex flex-col sm:flex-row gap-4 mb-4"
        >
            <div className="flex items-center space-x-2 space-x-reverse">
                <RadioGroupItem value="all" id="report-all" />
                <Label htmlFor="report-all" className="cursor-pointer">عرض كل المصروفات</Label>
            </div>
            <div className="flex items-center space-x-2 space-x-reverse">
                <RadioGroupItem value="dateRange" id="report-date-range" />
                <Label htmlFor="report-date-range" className="cursor-pointer">تحديد فترة زمنية</Label>
            </div>
        </RadioGroup>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="space-y-2">
            <Label htmlFor="fromDate" className={cn(reportType === 'all' && "text-muted-foreground/50")}>من تاريخ</Label>
            <Popover open={isFromDateCalendarOpen} onOpenChange={setIsFromDateCalendarOpen}>
              <PopoverTrigger asChild>
                  <div className="relative">
                    <Input
                      id="fromDate"
                      placeholder="YYYY-MM-DD"
                      value={fromDate ? format(fromDate, 'yyyy-MM-dd') : ''}
                      onChange={(e) => {
                        const dateString = e.target.value;
                        try {
                          const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                          if (isValid(parsedDate)) { setFromDate(parsedDate); }
                          else if (dateString === '') { setFromDate(undefined); }
                        } catch { setFromDate(undefined); }
                      }}
                      onFocus={() => setIsFromDateCalendarOpen(true)}
                      className={cn("w-full justify-start text-left font-normal pe-10", !fromDate && "text-muted-foreground", reportType === 'all' && "bg-muted/50 cursor-not-allowed" )}
                      disabled={reportType === 'all'}
                    />
                    <CalendarIcon
                      className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 opacity-50 cursor-pointer"
                      onClick={() => {if(reportType !== 'all') setIsFromDateCalendarOpen(prev => !prev)}}
                    />
                  </div>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={fromDate}
                  onSelect={(date) => {setFromDate(date); setIsFromDateCalendarOpen(false);}}
                  captionLayout="dropdown-buttons"
                  fromYear={fromCalYear}
                  toYear={toCalYear}
                  defaultMonth={fromDate || new Date()}
                  initialFocus
                  locale={arSA}
                  dir="rtl"
                  disabled={reportType === 'all'}
                />
              </PopoverContent>
            </Popover>
          </div>
          <div className="space-y-2">
            <Label htmlFor="toDate" className={cn(reportType === 'all' && "text-muted-foreground/50")}>إلى تاريخ</Label>
            <Popover open={isToDateCalendarOpen} onOpenChange={setIsToDateCalendarOpen}>
              <PopoverTrigger asChild>
                  <div className="relative">
                    <Input
                      id="toDate"
                      placeholder="YYYY-MM-DD"
                      value={toDate ? format(toDate, 'yyyy-MM-dd') : ''}
                      onChange={(e) => {
                        const dateString = e.target.value;
                        try {
                          const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                          if (isValid(parsedDate) && (!fromDate || parsedDate >= fromDate)) { setToDate(parsedDate); }
                          else if (dateString === '') { setToDate(undefined); }
                        } catch { setToDate(undefined); }
                      }}
                      onFocus={() => setIsToDateCalendarOpen(true)}
                      className={cn("w-full justify-start text-left font-normal pe-10", !toDate && "text-muted-foreground", reportType === 'all' && "bg-muted/50 cursor-not-allowed" )}
                      disabled={reportType === 'all'}
                    />
                    <CalendarIcon
                      className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 opacity-50 cursor-pointer"
                      onClick={() => {if(reportType !== 'all') setIsToDateCalendarOpen(prev => !prev)}}
                    />
                  </div>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={toDate}
                  onSelect={(date) => {setToDate(date); setIsToDateCalendarOpen(false);}}
                  disabled={(date) => (fromDate && date < fromDate) || reportType === 'all'}
                  captionLayout="dropdown-buttons"
                  fromYear={fromCalYear}
                  toYear={toCalYear}
                  defaultMonth={toDate || fromDate || new Date()}
                  initialFocus
                  locale={arSA}
                  dir="rtl"
                />
              </PopoverContent>
            </Popover>
          </div>
          <Button onClick={handleViewReport} className="w-full md:w-auto">
            <Printer className="me-2 h-4 w-4" />
            عرض وطباعة التقرير
          </Button>
        </div>
      </CardContent>
      <ExpenseReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        expenses={filteredExpenses}
        totalAmount={totalFilteredAmount}
        reportTitle={reportType === 'all' ? 'تقرير جميع مصروفات الورثة' : `تقرير مصروفات الورثة من ${fromDate ? format(fromDate, "yyyy/MM/dd") : ''} إلى ${toDate ? format(toDate, "yyyy/MM/dd") : ''}`}
      />
    </Card>
  );
}
