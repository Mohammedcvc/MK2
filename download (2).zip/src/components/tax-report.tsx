
'use client';

import { useMemo, useState } from 'react';
import type { Tenant, Property, Payment, PaymentStatus } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption, TableFooter } from '@/components/ui/table';
import { Printer, Eye, BarChart3, ArrowRight, Sigma, Info, CalendarIcon } from 'lucide-react';
import { format, parse, parseISO, differenceInCalendarDays, isPast, isToday, isValid, startOfDay, endOfDay, isWithinInterval, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';
import { Badge, type BadgeProps } from '@/components/ui/badge';
import { PAYMENT_STATUSES, getLabelForValue as getConstantLabel, PAYMENT_STATUS_BADGE_VARIANT } from '@/lib/constants';
import { cn } from '@/lib/utils';
import { SimplePaymentDetailModal } from './simple-payment-detail-modal';

interface TaxReportItem {
  tenantName: string;
  paymentId: string;
  paymentDisplayId: string;
  paymentDescription: string;
  paymentDueDate: string; // Formatted date
  amountPaid: number;
  taxRate: number;
  taxAmount: number;
  propertyName: string;
  paymentStatus: PaymentStatus;
  originalPayment: Payment;
}

interface TaxReportProps {
  payments: Payment[];
  tenants: Tenant[];
  properties: Property[];
  reportTitle: string;
  onBackToDashboard?: () => void;
}

export function TaxReport({ payments, tenants, properties, reportTitle, onBackToDashboard }: TaxReportProps) {
  const { toast } = useToast();
  const [isPaymentDetailModalOpen, setIsPaymentDetailModalOpen] = useState(false);
  const [selectedPaymentForDetail, setSelectedPaymentForDetail] = useState<Payment | null>(null);

  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);
  const [isFromDateCalendarOpen, setIsFromDateCalendarOpen] = useState(false);
  const [isToDateCalendarOpen, setIsToDateCalendarOpen] = useState(false);

  const taxReportData = useMemo<TaxReportItem[]>(() => {
    let filteredPaymentsByDate = payments;

    if (fromDate && toDate && isValid(fromDate) && isValid(toDate)) {
      const startDate = startOfDay(fromDate);
      const endDate = endOfDay(toDate);
      if (endDate >= startDate) {
        filteredPaymentsByDate = payments.filter(payment => {
          try {
            const paymentDueDate = parseISO(payment.dueDate);
            return isWithinInterval(paymentDueDate, { start: startDate, end: endDate });
          } catch (e) {
            return false;
          }
        });
      }
    }

    const reportItems: TaxReportItem[] = [];
    filteredPaymentsByDate.forEach((payment, index) => {
      if (payment.amountPaid > 0) {
        const tenant = tenants.find(t => t.tenantId === payment.tenantId);
        const property = properties.find(p => p.id === tenant?.propertyId);
        if (tenant) {
          const taxAmount = parseFloat((payment.amountPaid * (tenant.taxRate / (100 + tenant.taxRate))).toFixed(2));
          reportItems.push({
            tenantName: tenant.tenantName,
            paymentId: payment.paymentId,
            paymentDisplayId: `${1001 + index}`, 
            paymentDescription: payment.description,
            paymentDueDate: format(parseISO(payment.dueDate), 'yyyy/MM/dd', { locale: arSA }),
            amountPaid: payment.amountPaid,
            taxRate: tenant.taxRate,
            taxAmount,
            propertyName: property?.name || 'غير محدد',
            paymentStatus: payment.status,
            originalPayment: payment,
          });
        }
      }
    });
    return reportItems.sort((a,b) => new Date(b.originalPayment.dueDate).getTime() - new Date(a.originalPayment.dueDate).getTime());
  }, [payments, tenants, properties, fromDate, toDate]);

  const totalTaxCollected = useMemo(() => {
    return taxReportData.reduce((sum, item) => sum + item.taxAmount, 0);
  }, [taxReportData]);

  const handlePrint = () => {
    const printContentElement = document.getElementById('tax-report-content');
    const printContent = printContentElement ? printContentElement.innerHTML.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';

    let currentReportTitle = reportTitle.replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
    if (fromDate && toDate && isValid(fromDate) && isValid(toDate)) {
        const fromDateSafe = format(fromDate, 'yyyy/MM/dd').replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
        const toDateSafe = format(toDate, 'yyyy/MM/dd').replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
        currentReportTitle = `${currentReportTitle} (من ${fromDateSafe} إلى ${toDateSafe})`;
    }

    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        const printHtml = `
          <html>
            <head>
              <title>${currentReportTitle}</title>
              <style>
                body { font-family: "Sakkal Majalla", var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
                .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
                .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11pt; }
                th, td { border: 1px solid #ddd; padding: 6px; text-align: right; font-weight: 500; }
                th { background-color: #f2f2f2; font-weight: bold; }
                .total-row td { font-weight: bold; background-color: #f9f9f9; }
                .no-print { display: none !important; }
                .badge-print { padding: 0.2em 0.6em; border-radius: 0.25rem; font-size: 0.85em; display: inline-block; border: 1px solid transparent; }
                .badge-paid-print { background-color: #d4edda !important; color: #155724 !important; border-color: #c3e6cb !important; }
                .badge-pending-print { background-color: #e2e8f0 !important; color: #4a5568 !important; border-color: #cbd5e0 !important; }
                .badge-overdue-print { background-color: #f8d7da !important; color: #721c24 !important; border-color: #f5c6cb !important; }
                .badge-due-print { background-color: #ffe8cc !important; color: #994d00 !important; border-color: #ffd1a3 !important; }
                .footer-summary { margin-top: 20px; padding-top: 10px; border-top: 2px solid #ccc; text-align: left; }
                .footer-summary div { margin-bottom: 5px; font-size: 11pt;}
                .footer-summary strong { min-width: 150px; display: inline-block; }
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>${currentReportTitle}</h1>
                <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
              </div>
              ${printContent}
            </body>
          </html>`;
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    } else {
        toast({ title: 'خطأ', description: 'لم يتم العثور على محتوى للطباعة.', variant: 'destructive' });
    }
  };

  const handlePreview = () => {
    if (taxReportData.length === 0) {
        toast({ title: "لا توجد بيانات", description: "لا توجد دفعات مدفوعة لعرضها في معاينة تقرير الضريبة.", variant: "default"});
        return;
    }
    handlePrint(); // Re-use existing print logic for preview
    toast({ title: "معاينة التقرير", description: "سيتم عرض التقرير في نافذة طباعة.", variant: "default"});
  };

  const getPaymentStatusDisplay = (paymentStatus: PaymentStatus, dueDate: string) => {
      const dueDateObj = parseISO(dueDate);
      const now = new Date();
      const startOfDueDateClean = startOfDay(dueDateObj);
      const startOfNowClean = startOfDay(now);
      const daysDifference = differenceInCalendarDays(startOfDueDateClean, startOfNowClean);

      let displayStatusLabel: string;
      let displayStatusVariant: BadgeProps['variant'];
      let displayStatusClassName: string | undefined;
      let printBadgeClass: string = '';

      if (paymentStatus === 'paid') {
        displayStatusLabel = getConstantLabel(PAYMENT_STATUSES, 'paid');
        displayStatusVariant = 'default';
        displayStatusClassName = "bg-green-500 hover:bg-green-600 text-primary-foreground border-transparent";
        printBadgeClass = "badge-paid-print";
      } else if (paymentStatus === 'pending') {
        displayStatusLabel = getConstantLabel(PAYMENT_STATUSES, 'pending');
        displayStatusVariant = 'secondary';
        printBadgeClass = "badge-pending-print";
      } else if (paymentStatus === 'due' || (daysDifference >= 0 && daysDifference <= 10 && paymentStatus !== 'overdue')) {
        displayStatusLabel = paymentStatus === 'due' ? getConstantLabel(PAYMENT_STATUSES, 'due') : `مستحقة خلال ${daysDifference} يوم`;
        if (daysDifference === 0 && paymentStatus !== 'due') displayStatusLabel = 'مستحقة اليوم';
        displayStatusVariant = 'outline';
        displayStatusClassName = "border-orange-500 text-orange-700 bg-orange-100 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700 hover:bg-orange-200 dark:hover:bg-orange-800/40";
        printBadgeClass = "badge-due-print";
      } else if (paymentStatus === 'overdue' || daysDifference < 0) {
        const daysOverdueCount = Math.abs(daysDifference);
        displayStatusLabel = paymentStatus === 'overdue' ? getConstantLabel(PAYMENT_STATUSES, 'overdue') : `متأخرة بـ ${daysOverdueCount} يوم`;
        displayStatusVariant = 'destructive';
        printBadgeClass = "badge-overdue-print";
      } else {
        displayStatusLabel = getConstantLabel(PAYMENT_STATUSES, paymentStatus);
        displayStatusVariant = PAYMENT_STATUS_BADGE_VARIANT[paymentStatus] || 'outline';
      }
      return { displayStatusLabel, displayStatusVariant, displayStatusClassName, printBadgeClass };
  };

  const handleOpenPaymentDetailModal = (payment: Payment) => {
    setSelectedPaymentForDetail(payment);
    setIsPaymentDetailModalOpen(true);
  };

  const currentCalYear = getYear(new Date());
  const fromCalYear = subYears(new Date(), 10).getFullYear();
  const toCalYear = addYears(new Date(), 10).getFullYear();

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg font-semibold flex items-center">
              <BarChart3 className="me-3 h-7 w-7 text-primary" />
              {reportTitle}
            </CardTitle>
            <CardDescription className="text-sm font-semibold">
              عرض تفصيلي للضريبة المحصلة من الدفعات المدفوعة.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2 no-print">
            {onBackToDashboard && (
              <Button variant="outline" size="sm" onClick={onBackToDashboard}>
                <ArrowRight className="ms-2 h-4 w-4" />
                العودة إلى لوحة التحكم
              </Button>
            )}
            <Button onClick={handlePrint} variant="outline" size="sm" disabled={taxReportData.length === 0}>
              <Printer className="me-2 h-4 w-4" />
              طباعة التقرير
            </Button>
            <Button onClick={handlePreview} variant="outline" size="sm" disabled={taxReportData.length === 0}>
              <Eye className="me-2 h-4 w-4" />
              معاينة
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-4 p-4 border rounded-md bg-muted/30 no-print">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
            <div className="space-y-1">
              <Label htmlFor="fromDate">من تاريخ استحقاق الدفعة</Label>
              <Popover open={isFromDateCalendarOpen} onOpenChange={setIsFromDateCalendarOpen}>
                <PopoverTrigger asChild>
                    <div className="relative">
                      <Input
                        id="fromDate"
                        placeholder="YYYY-MM-DD"
                        value={fromDate ? format(fromDate, 'yyyy-MM-dd') : ''}
                        onChange={(e) => {
                          const dateString = e.target.value;
                          try {
                            const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                            if (isValid(parsedDate)) { setFromDate(parsedDate); }
                            else if (dateString === '') { setFromDate(undefined); }
                          } catch { setFromDate(undefined); }
                        }}
                        className={cn("w-full justify-start text-left font-normal pe-10 bg-card text-center", !fromDate && "text-muted-foreground")}
                      />
                      <CalendarIcon
                        className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                        onClick={() => setIsFromDateCalendarOpen(prev => !prev)}
                      />
                    </div>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                    <Calendar 
                        mode="single" 
                        selected={fromDate} 
                        onSelect={(date) => {setFromDate(date); setIsFromDateCalendarOpen(false);}} 
                        captionLayout="dropdown-buttons"
                        fromYear={fromCalYear}
                        toYear={toCalYear}
                        defaultMonth={fromDate || new Date()}
                        initialFocus 
                        locale={arSA} 
                        dir="rtl" 
                    />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-1">
              <Label htmlFor="toDate">إلى تاريخ استحقاق الدفعة</Label>
              <Popover open={isToDateCalendarOpen} onOpenChange={setIsToDateCalendarOpen}>
                <PopoverTrigger asChild>
                    <div className="relative">
                      <Input
                        id="toDate"
                        placeholder="YYYY-MM-DD"
                        value={toDate ? format(toDate, 'yyyy-MM-dd') : ''}
                        onChange={(e) => {
                          const dateString = e.target.value;
                          try {
                            const parsedDate = parse(dateString, 'yyyy-MM-DD', new Date());
                            if (isValid(parsedDate) && (!fromDate || parsedDate >= fromDate)) { setToDate(parsedDate); }
                            else if (dateString === '') { setToDate(undefined); }
                          } catch { setToDate(undefined); }
                        }}
                        className={cn("w-full justify-start text-left font-normal pe-10 bg-card text-center", !toDate && "text-muted-foreground")}
                      />
                      <CalendarIcon
                        className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 cursor-pointer"
                        onClick={() => setIsToDateCalendarOpen(prev => !prev)}
                      />
                    </div>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                    <Calendar 
                        mode="single" 
                        selected={toDate} 
                        onSelect={(date) => {setToDate(date); setIsToDateCalendarOpen(false);}} 
                        disabled={(date) => (fromDate && date < fromDate)} 
                        captionLayout="dropdown-buttons"
                        fromYear={fromCalYear}
                        toYear={toCalYear}
                        defaultMonth={toDate || fromDate || new Date()}
                        initialFocus 
                        locale={arSA} 
                        dir="rtl" 
                    />
                </PopoverContent>
              </Popover>
            </div>
          </div>
           <p className="text-xs text-muted-foreground">يتم تصفية التقرير بناءً على تاريخ استحقاق الدفعات.</p>
        </div>

        <div id="tax-report-content">
          {taxReportData.length > 0 ? (
            <div className="overflow-x-auto rounded-md border">
              <Table>
                <TableCaption>تقرير الضريبة المحصلة من الدفعات المدفوعة.</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[80px]">رقم الدفعة</TableHead>
                    <TableHead className="min-w-[150px]">اسم المستأجر</TableHead>
                    <TableHead className="min-w-[150px]">اسم العقار</TableHead>
                    <TableHead className="min-w-[180px]">بيان الدفعة</TableHead>
                    <TableHead className="min-w-[100px] text-center">تاريخ الاستحقاق</TableHead>
                    <TableHead className="min-w-[110px] text-center">حالة الدفعة</TableHead>
                    <TableHead className="min-w-[130px] text-center">المبلغ المدفوع (شامل الضريبة)</TableHead>
                    <TableHead className="min-w-[100px] text-center">نسبة الضريبة</TableHead>
                    <TableHead className="min-w-[120px] text-center">مبلغ الضريبة</TableHead>
                    <TableHead className="min-w-[100px] text-center">تفاصيل</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {taxReportData.map((item) => {
                    const { displayStatusLabel, displayStatusVariant, displayStatusClassName, printBadgeClass } = getPaymentStatusDisplay(item.paymentStatus, item.originalPayment.dueDate);
                    return (
                      <TableRow key={item.paymentId}>
                        <TableCell>{item.paymentDisplayId}</TableCell>
                        <TableCell className="font-medium">{item.tenantName}</TableCell>
                        <TableCell>{item.propertyName}</TableCell>
                        <TableCell>{item.paymentDescription}</TableCell>
                        <TableCell className="text-center">{item.paymentDueDate}</TableCell>
                        <TableCell className="text-center">
                          <Badge variant={displayStatusVariant} className={cn(displayStatusClassName, 'badge-print', printBadgeClass)}>
                            {displayStatusLabel}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-center">{item.amountPaid.toLocaleString()} ريال</TableCell>
                        <TableCell className="text-center">{item.taxRate}%</TableCell>
                        <TableCell className="text-center font-semibold text-primary">{item.taxAmount.toLocaleString()} ريال</TableCell>
                        <TableCell className="text-center">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenPaymentDetailModal(item.originalPayment)}>
                            <Info className="h-4 w-4 text-blue-500" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
                <TableFooter className="total-row bg-muted/50">
                  <TableRow>
                    <TableCell colSpan={8} className="font-semibold text-lg">
                        <div className="flex items-center">
                            <Sigma className="h-5 w-5 me-2 text-primary" /> إجمالي مبلغ الضريبة المحصل
                        </div>
                    </TableCell>
                    <TableCell className="text-center font-semibold text-lg text-primary">
                      {totalTaxCollected.toLocaleString()} ريال
                    </TableCell>
                    <TableCell></TableCell>
                  </TableRow>
                </TableFooter>
              </Table>
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              لا توجد دفعات مدفوعة تطابق معايير التصفية لعرضها في تقرير الضريبة.
            </p>
          )}
        </div>
      </CardContent>
      {selectedPaymentForDetail && (
        <SimplePaymentDetailModal
          isOpen={isPaymentDetailModalOpen}
          onClose={() => setIsPaymentDetailModalOpen(false)}
          payment={selectedPaymentForDetail}
        />
      )}
    </Card>
  );
}
