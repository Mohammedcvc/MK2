
'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users as UsersIcon, UserPlus, User, Clock } from 'lucide-react';
import { useAppContext } from '@/contexts/app-context';
import type { User, UserFormValues, UserPermissions } from '@/types';
import { UsersTable } from '@/components/users-table';
import { AddEditUserModal } from '@/components/add-edit-user-modal';
import { DeleteUserDialog } from '@/components/delete-user-dialog';
import { useToast } from '@/hooks/use-toast';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

const universalFullPermissions: UserPermissions = {
  canDelete: true,
  canEdit: true,
  canAdd: true,
  canPrint: true,
};

export function UserManagementDashboard() {
  const { currentUser, allUsers, setAllUsers } = useAppContext();
  const { toast } = useToast();

  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);

  const [isDeleteDialogVisible, setIsDeleteDialogVisible] = useState(false);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);

  const canAddUsersGlobal = currentUser?.permissions?.canAdd ?? false;
  const canEditUsersGlobal = currentUser?.permissions?.canEdit ?? false;
  const canDeleteUsersGlobal = currentUser?.permissions?.canDelete ?? false;


  const handleOpenAddModal = () => {
    if (!canAddUsersGlobal) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية إضافة مستخدمين.", variant: "destructive"});
      return;
    }
    setEditingUser(null);
    setIsAddEditModalOpen(true);
  };

  const handleOpenEditModal = (user: User) => {
     if (!canEditUsersGlobal) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية تعديل المستخدمين.", variant: "destructive"});
      return;
    }
    setEditingUser(user);
    setIsAddEditModalOpen(true);
  };

  const handleOpenDeleteDialog = (userId: string) => {
    const user = allUsers.find(u => u.id === userId);
    if (user) {
      if (user.id === currentUser?.id) {
        toast({
          title: "خطأ",
          description: "لا يمكنك حذف المستخدم الحالي.",
          variant: "destructive",
        });
        return;
      }
      if (!canDeleteUsersGlobal) {
         toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف المستخدمين.", variant: "destructive"});
         return;
      }
      setUserToDelete(user);
      setIsDeleteDialogVisible(true);
    }
  };

  const closeModals = () => {
    setIsAddEditModalOpen(false);
    setEditingUser(null);
    setIsDeleteDialogVisible(false);
    setUserToDelete(null);
  };

  const handleSaveUser = async (data: UserFormValues, userIdToUpdate?: string) => {
    const finalPermissions: UserPermissions = { ...universalFullPermissions };
    const modifierUsername = currentUser?.username || 'system_user_mgmt';
    const modificationTimestamp = new Date().toISOString();

    const userDataToSave = {
      username: data.username,
      roles: data.roles,
      permissions: finalPermissions,
      lastModifiedBy: modifierUsername,
      lastModifiedAt: modificationTimestamp,
      ...(data.password && data.password.trim() !== '' && { password: data.password }),
    };

    if (userIdToUpdate) {
      setAllUsers(prevUsers =>
        prevUsers.map(u =>
          u.id === userIdToUpdate
            ? {
                ...u,
                ...userDataToSave,
                password: data.password && data.password.trim() !== '' ? data.password : u.password,
              }
            : u
        )
      );
      toast({ title: "تم تعديل المستخدم وحفظ التغييرات", description: `تم تحديث بيانات المستخدم "${data.username}".` });
    } else {
      if (!data.password || data.password.trim() === '') {
         toast({ title: "خطأ", description: "كلمة المرور مطلوبة للمستخدم الجديد.", variant: "destructive"});
         return;
      }
      const newUser: User = {
        id: `user_${Date.now()}`,
        ...userDataToSave,
        password: data.password,
      };
      setAllUsers(prevUsers => [...prevUsers, newUser]);
      toast({ title: "تمت إضافة المستخدم وحفظه", description: `تمت إضافة مستخدم جديد باسم "${data.username}".` });
    }
    closeModals();
  };

  const handleConfirmDeleteUser = async () => {
    if (userToDelete) {
      if (userToDelete.id === currentUser?.id) {
        toast({
          title: "خطأ",
          description: "لا يمكن حذف المستخدم المسجل دخوله حالياً.",
          variant: "destructive",
        });
        closeModals();
        return;
      }
       if (!canDeleteUsersGlobal) {
         toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف المستخدمين.", variant: "destructive"});
         closeModals();
         return;
      }
      setAllUsers(prevUsers => prevUsers.filter(u => u.id !== userToDelete.id));
      toast({ title: "تم حذف المستخدم وحفظ التغييرات", description: `تم حذف المستخدم "${userToDelete.username}" بشكل دائم.`, variant: "destructive" });
    }
    closeModals();
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="shadow-lg">
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <CardTitle className="text-lg flex items-center">
                <UsersIcon className="me-3 h-7 w-7 text-primary" />
                {'إدارة المستخدمين'}
              </CardTitle>
              <CardDescription className="text-sm font-semibold">
                {'إضافة مستخدمين جدد، تعديل معلومات المستخدمين الحاليين، أو حذفهم.'}
              </CardDescription>
            </div>
            <div className="flex flex-wrap gap-2 items-center">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span>
                        <Button onClick={handleOpenAddModal} size="sm" disabled={!canAddUsersGlobal}>
                          <UserPlus className="me-2 h-4 w-4" />
                          {'إضافة مستخدم جديد'}
                        </Button>
                      </span>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{canAddUsersGlobal ? 'إضافة مستخدم جديد للنظام' : 'ليس لديك صلاحية إضافة مستخدمين'}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <UsersTable
            users={allUsers}
            onEditUser={handleOpenEditModal}
            onDeleteUser={handleOpenDeleteDialog}
            currentUserId={currentUser?.id}
            canEdit={canEditUsersGlobal}
            canDelete={canDeleteUsersGlobal}
          />
        </CardContent>
      </Card>

      <AddEditUserModal
        isOpen={isAddEditModalOpen}
        onClose={closeModals}
        onSubmit={handleSaveUser}
        initialData={editingUser}
      />

      <DeleteUserDialog
        isOpen={isDeleteDialogVisible}
        onClose={closeModals}
        onConfirm={handleConfirmDeleteUser}
        username={userToDelete?.username}
      />
    </div>
  );
}

