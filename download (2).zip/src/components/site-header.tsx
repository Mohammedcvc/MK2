
'use client';

import { Landmark, LogIn, LogOut, Users, ShieldCheck, Home, Settings } from 'lucide-react';
import Link from 'next/link';
import { useAppContext } from '@/contexts/app-context';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useRouter, useSearchParams } from 'next/navigation';
import { cn } from '@/lib/utils';


export function SiteHeader() {
  const { currentUser, logout } = useAppContext();
  const router = useRouter();
  const searchParams = useSearchParams();
  const currentView = searchParams.get('view');

  const toggleMainView = () => {
    const newView = currentView === 'deceased' ? 'smart' : 'deceased';
    router.push(newView === 'deceased' ? '/?view=deceased' : '/');
  };


  return (
    <header className="bg-primary text-primary-foreground shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
           <Link href="/" className="flex items-center gap-2 text-primary-foreground hover:text-primary-foreground/90" aria-label="العقار الذكي">
              <Settings className="h-7 w-7" />
              <h1 className="text-xl font-bold hidden sm:block">العقار الذكي</h1>
            </Link>
        </div>

        <div className="flex-1 flex justify-center">
            <Button
                onClick={toggleMainView}
                className={cn(
                    "text-sm font-medium px-3 py-1.5 h-auto rounded-md transition-colors",
                    "bg-accent text-accent-foreground hover:bg-accent/90"
                )}
            >
                {currentView === 'deceased' ? (
                    <>
                        <Home className="me-2 h-4 w-4" />
                        عرض العقار الذكي
                    </>
                ) : (
                    <>
                        <Landmark className="me-2 h-4 w-4" />
                        عرض عقارات الورثة
                    </>
                )}
            </Button>
        </div>


        <div className="flex items-center gap-2 sm:gap-3">
          {currentUser ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 rounded-full p-0">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={`https://picsum.photos/seed/${currentUser.username}/40/40`} alt={currentUser.username} data-ai-hint="user avatar" />
                    <AvatarFallback>{currentUser.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align={"start"} forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{currentUser.username}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {currentUser.roles?.includes('admin') ? "مسؤول النظام" : "مستخدم"}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/admin/users" className="flex items-center w-full cursor-pointer">
                    <Users className="me-2 h-4 w-4" />
                    المستخدمين
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/admin/permissions" className="flex items-center w-full cursor-pointer">
                    <ShieldCheck className="me-2 h-4 w-4" />
                    صلاحيات المستخدمين
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="cursor-pointer text-destructive focus:text-destructive-foreground focus:bg-destructive">
                  <LogOut className="me-2 h-4 w-4" />
                  تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button asChild variant="secondary" className="text-sm">
              <Link href="/login">
                <LogIn className="me-2 h-5 w-5" />
                تسجيل الدخول
              </Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
