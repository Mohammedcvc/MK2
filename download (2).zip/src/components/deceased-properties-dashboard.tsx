
'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Landmark, Building, Users, Receipt, Banknote, LayoutGrid, FileText as FileTextIcon, TrendingUp, CalendarClock, AlertTriangle, ArrowRight, ListFilter, ChevronDown, BarChart3, Sigma as SigmaIcon, Settings, Printer as PrinterIcon, BarChartHorizontalBig } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useState } from 'react';
import { PropertyManagementDashboard } from '@/components/property-management-dashboard';
import { DeceasedDashboardContent } from '@/components/deceased-dashboard-content';
import { InheritorsDashboard } from '@/components/inheritors-dashboard';
import { DeceasedExpensesDashboard } from '@/components/deceased-expenses-dashboard';
import { BankTransactionsDashboard } from '@/components/bank-transactions-dashboard';
import { InheritorBalancesReport } from '@/components/inheritor-balances-report';
import { DeceasedExpensesDateRangeReport } from '@/components/deceased-expenses-date-range-report';
import { DeceasedRentSummaryReport } from '@/components/deceased-rent-summary-report';
import { DeceasedContractStatusReport } from '@/components/deceased-contract-status-report';
import { OverdueAndDuePaymentsReport } from '@/components/overdue-and-due-payments-report';
import { AccountStatementReport } from '@/components/account-statement-report';
import { TaxReport } from '@/components/tax-report';
import { ProfitAndLossReport } from '@/components/profit-and-loss-report';
import { ChartsReport } from '@/components/charts-report';
import { useAppContext } from '@/contexts/app-context';
import type { Property, DeceasedPropertyActiveView, InheritorTransaction } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import Link from 'next/link';
import { format } from 'date-fns';

interface NavItem {
  id: DeceasedPropertyActiveView;
  label: string;
  icon: React.ElementType;
  content?: React.ReactNode;
  component?: React.FC<any>;
  props?: any;
  isFullWidth?: boolean;
  isReport?: boolean;
  path?: string;
}

export function DeceasedPropertiesDashboard() {
  const [activeNavItemId, setActiveNavItemId] = useState<DeceasedPropertyActiveView>('deceased-dashboard');
  const {
    currentUser,
    deceasedProperties, setDeceasedProperties,
    deceasedTenants, setDeceasedTenants,
    deceasedPayments, setDeceasedPayments,
    deceasedExpenses,
    deceasedInheritors, // Added for charts report
    deceasedInheritorTransactions,
  } = useAppContext();
  const router = useRouter();
  const { toast } = useToast();

  const handleAddProperty = (newPropertyData: Omit<Property, 'id' | 'imageUrl' | 'lastModifiedBy' | 'lastModifiedAt'>) => {
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();
    const newProperty: Property = {
        ...newPropertyData,
        id: `d_prop_${Date.now()}`,
        imageUrl: `https://placehold.co/400x300.png`,
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
    }
    setDeceasedProperties(prev => [...prev, newProperty]);
    toast({ title: "تم إضافة عقار للورثة", description: `تم إضافة ${newProperty.name} بنجاح.` });
  };

  const handleUpdateProperty = (updatedProperty: Property) => {
    const modifierUsername = currentUser?.username || 'system_prop_edit';
    const modificationTimestamp = new Date().toISOString();
    const propertyWithUpdateInfo = {
        ...updatedProperty,
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
    };
    setDeceasedProperties(prev => prev.map(p => p.id === propertyWithUpdateInfo.id ? propertyWithUpdateInfo : p));
    toast({ title: "تم تحديث عقار للورثة", description: `تم تحديث ${updatedProperty.name} بنجاح.` });
  };

  const handleDeleteProperty = (propertyId: string) => {
    const propertyToDelete = deceasedProperties.find(p => p.id === propertyId);
    if (!propertyToDelete) return;

    const propertyName = propertyToDelete.name;

    setDeceasedProperties(prevProperties => prevProperties.filter(p => p.id !== propertyId));

    const relatedTenantIds = deceasedTenants
      .filter(t => t.propertyId === propertyId)
      .map(t => t.tenantId);

    setDeceasedTenants(prevTenants => prevTenants.filter(t => t.propertyId !== propertyId));

    setDeceasedPayments(prevPayments => prevPayments.filter(p => !relatedTenantIds.includes(p.tenantId)));

    toast({
      title: "تم حذف عقار للورثة",
      description: `تم حذف العقار "${propertyName}" وجميع بيانات المستأجرين والدفعات المرتبطة به من سجلات الورثة.`,
      variant: "destructive"
    });
  };

  const handleSelectProperty = (property: Property) => {
    router.push(`/properties/${property.id}?source=deceased`);
  };

  const handleBackToDeceasedDashboard = () => {
    setActiveNavItemId('deceased-dashboard');
  };

  const allNavItems: NavItem[] = [
     {
      id: 'deceased-dashboard',
      label: 'لوحة تحكم الورثة',
      icon: LayoutGrid,
      component: DeceasedDashboardContent,
      isFullWidth: false,
    },
    {
      id: 'deceased-properties-management',
      label: 'إدارة عقارات الورثة',
      icon: Building,
      component: PropertyManagementDashboard,
      props: {
        properties: deceasedProperties,
        onAddProperty: handleAddProperty,
        onUpdateProperty: handleUpdateProperty,
        onDeleteProperty: handleDeleteProperty,
        onSelectProperty: handleSelectProperty,
        owners: [],
      },
      isFullWidth: true,
    },
    {
      id: 'inheritors-shares',
      label: 'الورثة وأرصدتهم',
      icon: Users,
      component: InheritorsDashboard,
      isFullWidth: true,
    },
    {
      id: 'deceased-expenses',
      label: 'مصروفات الورثة',
      icon: Receipt,
      component: DeceasedExpensesDashboard,
      isFullWidth: true,
    },
    {
      id: 'bank-balances-cash',
      label: 'أرصدة البنوك والكاش للورثة',
      icon: Banknote,
      component: BankTransactionsDashboard,
      isFullWidth: true,
    },
    {
      id: 'inheritor-balances-report',
      label: 'تقرير أرصدة الورثة',
      icon: FileTextIcon,
      component: InheritorBalancesReport,
      props: { onBackToDashboard: handleBackToDeceasedDashboard },
      isFullWidth: true,
      isReport: true,
    },
    {
      id: 'deceased-expenses-report',
      label: 'تقرير مصروفات الورثة',
      icon: FileTextIcon,
      component: DeceasedExpensesDateRangeReport,
      props: { onBackToDashboard: handleBackToDeceasedDashboard },
      isFullWidth: true,
      isReport: true,
    },
     {
      id: 'deceased-rent-summary-report',
      label: 'تقرير إجمالي الإيجارات للورثة',
      icon: TrendingUp,
      component: DeceasedRentSummaryReport,
      props: { onBackToDashboard: handleBackToDeceasedDashboard },
      isFullWidth: true,
      isReport: true,
    },
    {
      id: 'deceased-contract-status-report',
      label: 'تقرير حالات عقود الورثة',
      icon: CalendarClock,
      component: DeceasedContractStatusReport,
      props: { onBackToDashboard: handleBackToDeceasedDashboard },
      isFullWidth: true,
      isReport: true,
    },
    {
      id: 'deceased-overdue-and-due-payments-report',
      label: 'تقرير الدفعات الهامة للورثة',
      icon: AlertTriangle,
      component: OverdueAndDuePaymentsReport,
      props: { properties: deceasedProperties, tenants: deceasedTenants, payments: deceasedPayments, reportTitleKey:"deceasedOverdueAndDuePaymentsReportTitle", onBackToDashboard: handleBackToDeceasedDashboard },
      isFullWidth: true,
      isReport: true,
    },
    {
      id: 'deceasedAccountStatementReport',
      label: 'كشف حساب مستأجري الورثة',
      icon: ListFilter,
      component: AccountStatementReport,
      props: { tenants: deceasedTenants, payments: deceasedPayments, properties: deceasedProperties, reportTitleKey:"accountStatementReportTitle", onBackToDashboard: handleBackToDeceasedDashboard },
      isFullWidth: true,
      isReport: true,
    },
    {
      id: 'taxReport',
      label: 'تقرير الضريبة (عقارات الورثة)',
      icon: BarChart3,
      component: TaxReport,
      props: { tenants: deceasedTenants, payments: deceasedPayments, properties: deceasedProperties, reportTitle:"تقرير الضريبة (عقارات الورثة)", onBackToDashboard: handleBackToDeceasedDashboard },
      isFullWidth: true,
      isReport: true,
    },
    {
      id: 'profitAndLossReport',
      label: 'تقرير الأرباح والخسائر (عقارات الورثة)',
      icon: SigmaIcon,
      component: ProfitAndLossReport,
      props: { payments: deceasedPayments, expenses: deceasedExpenses, reportTitle:"تقرير الأرباح والخسائر (عقارات الورثة)", onBackToDashboard: handleBackToDeceasedDashboard },
      isFullWidth: true,
      isReport: true,
    },
     {
      id: 'chartsReport',
      label: 'التقارير البيانية',
      icon: BarChartHorizontalBig,
      component: ChartsReport,
      props: {
        payments: deceasedPayments,
        expenses: deceasedExpenses,
        tenants: deceasedTenants,
        properties: deceasedProperties,
        inheritorTransactions: deceasedInheritorTransactions,
        deceasedInheritors: deceasedInheritors, // Pass inheritors data
        reportTitle:"التقارير البيانية (عقارات الورثة)",
        onBackToDashboard: handleBackToDeceasedDashboard
      },
      isFullWidth: true,
      isReport: true,
    },
    {
      id: 'deceased-consolidated-report',
      label: 'طباعة تقرير مجمع',
      icon: PrinterIcon,
      path: '/deceased-consolidated-report',
      isReport: true,
    },
  ];

  const mainNavItems = allNavItems.filter(item => !item.isReport);
  const reportNavItems = allNavItems.filter(item => item.isReport);

  const activeNavItem = allNavItems.find(item => item.id === activeNavItemId) || allNavItems[0];

  const renderContent = () => {
    if (activeNavItem.component) {
      const ComponentToRender = activeNavItem.component;
      return <ComponentToRender {...(activeNavItem.props || {})} />;
    }
    return activeNavItem.content;
  };


  return (
    <>
      <nav className="bg-card border-b shadow-sm sticky top-[calc(var(--header-height,60px)+1px)] z-40">
        <div className="container mx-auto px-4 py-2 flex items-center justify-center space-x-1 rtl:space-x-reverse overflow-x-auto">
          {mainNavItems.map((item) => (
            <Button
              key={item.id}
              variant={activeNavItemId === item.id ? 'default' : 'ghost'}
              onClick={() => setActiveNavItemId(item.id)}
              className="flex-shrink-0 px-3 py-2 text-sm font-semibold"
            >
              <item.icon className="me-2 h-4 w-4" />
              {item.label}
            </Button>
          ))}
          {reportNavItems.length > 0 && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex-shrink-0 px-3 py-2 text-sm font-semibold">
                  <FileTextIcon className="me-2 h-4 w-4" />
                  التقارير
                  <ChevronDown className="ms-2 h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {reportNavItems.map((reportItem) => (
                  <DropdownMenuItem
                    key={reportItem.id}
                    onClick={() => {
                      if (reportItem.path) {
                        router.push(reportItem.path);
                      } else {
                        setActiveNavItemId(reportItem.id);
                      }
                    }}
                    className={cn(activeNavItemId === reportItem.id && !reportItem.path && "bg-accent text-accent-foreground")}
                  >
                    <reportItem.icon className="me-2 h-4 w-4" />
                    {reportItem.label}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </nav>

      <main className="flex-1 p-4 md:p-6">
        {activeNavItem.isFullWidth ? (
          renderContent()
        ) : (
          <Card className="shadow-lg rounded-xl h-full">
            <CardHeader className="border-b pb-4">
              <div className="flex flex-row justify-between items-center">
                <CardTitle className="text-lg font-semibold flex items-center">
                  <activeNavItem.icon className="me-3 h-7 w-7 text-primary" />
                  {activeNavItem.label}
                </CardTitle>
                {activeNavItem.id !== 'deceased-dashboard' && (
                   <Button variant="outline" size="sm" onClick={handleBackToDeceasedDashboard}>
                     <ArrowRight className="ms-2 h-4 w-4" />
                     {'العودة إلى لوحة التحكم'}
                   </Button>
                )}
              </div>
              <CardDescription className="text-sm font-semibold">
                {'إدارة وعرض البيانات المتعلقة بـ "' + activeNavItem.label + '"'}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6 min-h-[calc(100vh-300px)]">
              {renderContent()}
            </CardContent>
          </Card>
        )}
      </main>
    </>
  );
}
