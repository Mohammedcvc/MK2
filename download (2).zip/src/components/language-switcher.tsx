
'use client';

import { useLanguage } from '@/contexts/language-context';
import { Button } from '@/components/ui/button';
import { Globe } from 'lucide-react';

export function LanguageSwitcher() {
  const { locale, setLocale, t } = useLanguage();

  const toggleLanguage = () => {
    setLocale(prevLocale => (prevLocale === 'ar' ? 'en' : 'ar'));
  };

  return (
    <Button variant="ghost" onClick={toggleLanguage} className="text-primary-foreground hover:bg-primary/80 hover:text-primary-foreground">
      <Globe className="me-2 h-5 w-5" />
      {t('toggleLanguage', locale === 'ar' ? 'Switch to English' : 'التحويل إلى العربية')}
    </Button>
  );
}
