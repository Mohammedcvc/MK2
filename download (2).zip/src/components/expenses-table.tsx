
'use client';

import type { Expense, Attachment } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableCaption
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Edit3, Trash2, UploadCloud, FileText, X, User, Clock } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { arSA } from 'date-fns/locale';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import React, { useRef } from 'react';
import { useAppContext } from '@/contexts/app-context';


interface ExpensesTableProps {
  expenses: Expense[];
  onEditExpense: (expense: Expense) => void;
  onDeleteExpense: (expense: Expense) => void;
  onAddAttachment: (expenseId: string, file: File) => Promise<void>;
  onDeleteAttachment: (expenseId: string, attachmentName: string) => Promise<void>;
  canEdit?: boolean;
  canDelete?: boolean;
}

export function ExpensesTable({ 
  expenses, 
  onEditExpense, 
  onDeleteExpense,
  onAddAttachment,
  onDeleteAttachment,
  canEdit,
  canDelete
}: ExpensesTableProps) {
  
  const fileInputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const { currentUser } = useAppContext();
  const canAddAttachment = currentUser?.permissions?.canAdd ?? false;

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>, expenseId: string) => {
    const file = event.target.files?.[0];
    if (file) {
      await onAddAttachment(expenseId, file);
      if (event.target) {
        event.target.value = ''; 
      }
    }
  };

  const triggerFileInput = (expenseId: string) => {
    fileInputRefs.current[expenseId]?.click();
  };

  const formatTimestamp = (isoString?: string) => {
    if (!isoString) return '-';
    try {
      return format(parseISO(isoString), 'yyyy/MM/dd HH:mm', { locale: arSA });
    } catch (e) {
      return 'تاريخ خاطئ';
    }
  };

  if (expenses.length === 0) {
    return <p className="text-center text-muted-foreground py-8">لا توجد مصروفات مسجلة لعرضها.</p>;
  }

  return (
    <div className="overflow-x-auto rounded-md border">
      <Table>
        <TableCaption>قائمة بجميع المصروفات المسجلة.</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="min-w-[180px]">اسم المصروف</TableHead>
            <TableHead className="min-w-[120px]">مبلغ المصروف</TableHead>
            <TableHead className="min-w-[120px]">تاريخ المصروف</TableHead>
            <TableHead className="min-w-[250px]">بيان المصروف</TableHead>
            <TableHead className="text-center min-w-[100px]">الإجراءات</TableHead>
            <TableHead className="min-w-[200px]">المرفقات</TableHead>
            <TableHead className="min-w-[150px]">آخر تعديل بواسطة</TableHead>
            <TableHead className="min-w-[170px]">وقت آخر تعديل</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {expenses.map((expense) => (
            <TableRow key={expense.id} className="hover:bg-muted/20 transition-colors">
              <TableCell className="font-medium">{expense.name}</TableCell>
              <TableCell>{expense.amount.toLocaleString()} ريال</TableCell>
              <TableCell>{format(parseISO(expense.date), 'yyyy/MM/dd', { locale: arSA })}</TableCell>
              <TableCell>{expense.description}</TableCell>
              <TableCell className="text-center">
                <TooltipProvider>
                  <div className="flex items-center justify-center space-x-1 space-x-reverse">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-primary hover:text-primary/90 h-8 w-8"
                          onClick={() => onEditExpense(expense)}
                          disabled={!canEdit}
                        >
                          <Edit3 className="h-4 w-4" />
                          <span className="sr-only">تعديل المصروف</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>{!canEdit ? "لا تملك صلاحية التعديل" : "تعديل المصروف"}</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:text-destructive/90 h-8 w-8"
                          onClick={() => onDeleteExpense(expense)}
                          disabled={!canDelete}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">حذف المصروف</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف المصروف"}</p></TooltipContent>
                    </Tooltip>
                  </div>
                </TooltipProvider>
              </TableCell>
              <TableCell>
                <div className="space-y-1">
                  {expense.attachments && expense.attachments.map(att => (
                    <div key={att.name} className="flex items-center justify-between text-xs group">
                      <Button variant="link" size="sm" asChild className="p-0 h-auto text-primary hover:underline flex-grow justify-start">
                        <a href={att.url} target="_blank" rel="noopener noreferrer" className="flex items-center">
                          <FileText className="h-3 w-3 me-1 flex-shrink-0" />
                          <span className="truncate" title={att.name}>{att.name}</span>
                        </a>
                      </Button>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-5 w-5 text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={() => onDeleteAttachment(expense.id, att.name)}
                              disabled={!canDelete}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="top"><p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف المرفق"}</p></TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  ))}
                  <input 
                    type="file" 
                    ref={el => fileInputRefs.current[expense.id] = el} 
                    style={{ display: 'none' }} 
                    onChange={(e) => handleFileChange(e, expense.id)}
                  />
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-1" 
                          onClick={() => triggerFileInput(expense.id)}
                          disabled={!canAddAttachment}
                        >
                          <UploadCloud className="h-3 w-3 me-1" /> إرفاق ملف
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent side="top"><p>{!canAddAttachment ? "لا تملك صلاحية الإضافة" : "إرفاق ملف جديد لهذا المصروف"}</p></TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                {(!expense.attachments || expense.attachments.length === 0) && <p className="text-xs text-muted-foreground text-center py-1">لا توجد مرفقات</p>}
              </TableCell>
              <TableCell>
                <div className="flex items-center text-xs text-muted-foreground">
                  <User className="h-3 w-3 me-1" /> {expense.lastModifiedBy || '-'}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex items-center text-xs text-muted-foreground">
                  <Clock className="h-3 w-3 me-1" /> {formatTimestamp(expense.lastModifiedAt)}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

