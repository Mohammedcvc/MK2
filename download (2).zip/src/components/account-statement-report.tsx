
'use client';

import { useState, useMemo } from 'react';
import type { Tenant, Property, Payment, PaymentStatus, Attachment } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption, TableFooter as ReportTableFooter } from '@/components/ui/table';
import { Printer, CalendarIcon, ArrowRight, FileText as FileTextIcon, Sigma } from 'lucide-react';
import { format, parse, parseISO, isWithinInterval, isValid, startOfDay, endOfDay, differenceInCalendarDays, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { PAYMENT_STATUSES, getLabelForValue as getConstantLabel, PAYMENT_STATUS_BADGE_VARIANT } from '@/lib/constants';
import { Badge, type BadgeProps } from '@/components/ui/badge';

interface AccountStatementReportProps {
  tenants: Tenant[];
  payments: Payment[];
  properties: Property[];
  reportTitleKey: string;
  onBackToDashboard?: () => void;
}

export function AccountStatementReport({
  tenants,
  payments,
  properties,
  reportTitleKey,
  onBackToDashboard,
}: AccountStatementReportProps) {
  const { toast } = useToast();

  const [selectedTenantId, setSelectedTenantId] = useState<string | undefined>(undefined);
  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);
  const [selectedStatuses, setSelectedStatuses] = useState<PaymentStatus[]>(PAYMENT_STATUSES.map(s => s.value));
  const [showReport, setShowReport] = useState(false);

  const [isFromDateCalendarOpen, setIsFromDateCalendarOpen] = useState(false);
  const [isToDateCalendarOpen, setIsToDateCalendarOpen] = useState(false);

  const handleStatusChange = (status: PaymentStatus, checked: boolean) => {
    setSelectedStatuses(prev =>
      checked ? [...prev, status] : prev.filter(s => s !== status)
    );
    setShowReport(false);
  };

  const filteredPayments = useMemo(() => {
    if (!selectedTenantId) return [];

    let dateFilteredPayments = payments.filter(p => p.tenantId === selectedTenantId);

    if (fromDate && toDate && isValid(fromDate) && isValid(toDate)) {
      const startDate = startOfDay(fromDate);
      const endDate = endOfDay(toDate);
      if (endDate >= startDate) {
        dateFilteredPayments = dateFilteredPayments.filter(payment => {
          try {
            const paymentDueDate = parseISO(payment.dueDate);
            return isWithinInterval(paymentDueDate, { start: startDate, end: endDate });
          } catch (e) {
            return false;
          }
        });
      }
    }

    return dateFilteredPayments.filter(payment => selectedStatuses.includes(payment.status));
  }, [payments, selectedTenantId, fromDate, toDate, selectedStatuses]);

  const reportTotals = useMemo(() => {
    const totalDue = filteredPayments.reduce((sum, p) => sum + p.amountDue, 0);
    const totalPaid = filteredPayments.reduce((sum, p) => sum + p.amountPaid, 0);
    const balance = totalDue - totalPaid;
    return { totalDue, totalPaid, balance };
  }, [filteredPayments]);

  const selectedTenantDetails = useMemo(() => {
    return tenants.find(t => t.tenantId === selectedTenantId);
  }, [tenants, selectedTenantId]);

  const handleViewReport = () => {
    if (!selectedTenantId) {
      toast({ title: 'خطأ', description: 'الرجاء اختيار مستأجر لعرض كشف الحساب.', variant: 'destructive' });
      return;
    }
    setShowReport(true);
  };

  const getPaymentStatusDisplay = (payment: Payment) => {
    const isEffectivelyPaid = (payment.amountDue - payment.amountPaid) === 0 && payment.amountDue > 0;
    const isMarkedAsPaid = payment.status === 'paid';
    const dueDateObj = parseISO(payment.dueDate);
    const now = new Date();
    const startOfDueDate = startOfDay(dueDateObj);
    const startOfNow = startOfDay(now);
    const daysDifference = differenceInCalendarDays(startOfDueDate, startOfNow);

    let displayStatusLabel: string;
    let displayStatusVariant: BadgeProps['variant'];
    let displayStatusClassName: string | undefined;

    if (isEffectivelyPaid || isMarkedAsPaid) {
      displayStatusLabel = getConstantLabel(PAYMENT_STATUSES, 'paid');
      displayStatusVariant = 'default';
      displayStatusClassName = "bg-green-500 hover:bg-green-600 text-primary-foreground border-transparent badge-paid";
    } else if (payment.status === 'due' || (daysDifference >= 0 && daysDifference <= 10)) {
      displayStatusLabel = payment.status === 'due' ? getConstantLabel(PAYMENT_STATUSES, 'due') : `مستحقة خلال ${daysDifference} يوم`;
      if(daysDifference === 0 && payment.status !== 'due') displayStatusLabel = 'مستحقة اليوم';
      displayStatusVariant = 'outline';
      displayStatusClassName = "border-orange-500 text-orange-700 bg-orange-100 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700 hover:bg-orange-200 dark:hover:bg-orange-800/40 badge-due-print";
    } else if (payment.status === 'overdue' || daysDifference < 0) {
      const daysOverdueCount = Math.abs(daysDifference);
      displayStatusLabel = payment.status === 'overdue' ? getConstantLabel(PAYMENT_STATUSES, 'overdue') : `متأخرة بـ ${daysOverdueCount} يوم`;
      displayStatusVariant = 'destructive';
      displayStatusClassName = "badge-overdue";
    } else {
      displayStatusLabel = getConstantLabel(PAYMENT_STATUSES, payment.status);
      displayStatusVariant = PAYMENT_STATUS_BADGE_VARIANT[payment.status] || 'outline';
      if (payment.status === 'pending') displayStatusClassName = "badge-pending";
    }
    return { displayStatusLabel, displayStatusVariant, displayStatusClassName };
  };


  const handlePrint = () => {
    if (!showReport || !selectedTenantDetails || filteredPayments.length === 0) {
        toast({ title: 'لا توجد بيانات', description: 'لا توجد دفعات تطابق معايير البحث المحددة.', variant: 'default' });
        return;
    }
    const printContentElement = document.getElementById('account-statement-print-area');
    const printContent = printContentElement ? printContentElement.innerHTML.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';

    if (printContent) {
        const printWindow = window.open('', '_blank');
        if (printWindow) {
            const selectedStatusesLabels = selectedStatuses.map(s => getConstantLabel(PAYMENT_STATUSES,s)).join(', ') || 'جميع الحالات';
            const reportTitleText = reportTitleKey === 'accountStatementReportTitle' ? 'كشف حساب المستأجر' : reportTitleKey;
            const reportTitleSafe = reportTitleText.replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
            const tenantNameSafe = selectedTenantDetails.tenantName.replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
            const fromDateSafe = fromDate ? format(fromDate, 'yyyy/MM/dd').replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';
            const toDateSafe = toDate ? format(toDate, 'yyyy/MM/dd').replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';

            const printHtml = `
            <html>
                <head>
                <title>${reportTitleSafe} - ${tenantNameSafe}</title>
                <style>
                    body { font-family: "Sakkal Majalla", var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
                    .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                    .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
                    .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
                    .filter-summary { margin-bottom: 15px; font-size: 12pt; font-weight: 500; }
                    .filter-summary p { margin: 3px 0; }
                    table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11pt; }
                    th, td { border: 1px solid #ddd; padding: 6px; text-align: right; font-weight: 500; }
                    th { background-color: #f2f2f2; font-weight: bold; }
                    .total-row td { font-weight: bold; background-color: #f9f9f9; }
                    .no-print { display: none !important; }
                    .badge-print { padding: 0.2em 0.6em; border-radius: 0.25rem; font-size: 0.9em; display: inline-block; border: 1px solid transparent; font-weight: 500; }
                    .badge-paid { background-color: #d4edda !important; color: #155724 !important; border-color: #c3e6cb !important; }
                    .badge-pending { background-color: #fff3cd !important; color: #856404 !important; border-color: #ffeeba !important; }
                    .badge-overdue { background-color: #f8d7da !important; color: #721c24 !important; border-color: #f5c6cb !important; }
                    .badge-due-print { background-color: #ffe8cc !important; color: #994d00 !important; border-color: #ffd1a3 !important; }
                    .attachments-list-print { list-style-type: none; padding: 0; margin: 0; }
                    .attachments-list-print li { font-size: 0.9em; }
                </style>
                </head>
                <body>
                <div class="print-header">
                    <h1>${reportTitleSafe}</h1>
                    <p>كشف حساب للمستأجر: ${tenantNameSafe}</p>
                    ${(fromDate && toDate) ? `<p>الفترة من: ${fromDateSafe} إلى: ${toDateSafe}</p>` : ''}
                    <p>حالات الدفع المضمنة: ${selectedStatusesLabels}</p>
                    <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
                </div>
                ${printContent.replace(/<button[^>]*>.*?<\/button>/gi, '')} 
                </body>
            </html>
            `;
            printWindow.document.write(printHtml);
            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => {
            printWindow.print();
            printWindow.close();
            }, 500);
        }
    }
  };

  const currentYear = getYear(new Date());
  const fromCalYear = subYears(new Date(), 10).getFullYear();
  const toCalYear = addYears(new Date(), 10).getFullYear();

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg font-semibold flex items-center"> 
              <FileTextIcon className="me-3 h-7 w-7 text-primary" />
              {reportTitleKey === 'accountStatementReportTitle' ? 'كشف حساب المستأجر' : reportTitleKey}
            </CardTitle>
            <CardDescription className="text-sm font-semibold">إنشاء كشف حساب تفصيلي للمستأجر بناءً على فترة وحالات دفع محددة.</CardDescription> 
          </div>
          {onBackToDashboard && (
            <Button variant="outline" size="sm" onClick={onBackToDashboard}>
              <ArrowRight className="ms-2 h-4 w-4" />العودة إلى لوحة التحكم
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-4 p-4 border rounded-md bg-muted/30">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 items-end">
            <div className="space-y-1">
              <Label htmlFor="tenantSelect">اختر المستأجر</Label>
              <Select value={selectedTenantId} onValueChange={id => {setSelectedTenantId(id); setShowReport(false);}}>
                <SelectTrigger id="tenantSelect">
                  <SelectValue placeholder="اختر المستأجر" />
                </SelectTrigger>
                <SelectContent>
                  {tenants.map(tenant => (
                    <SelectItem key={tenant.tenantId} value={tenant.tenantId}>
                      {tenant.tenantName} ({properties.find(p=>p.id === tenant.propertyId)?.name || 'N/A'})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label htmlFor="fromDate">من تاريخ</Label>
              <Popover open={isFromDateCalendarOpen} onOpenChange={setIsFromDateCalendarOpen}>
                <PopoverTrigger asChild>
                    <div className="relative">
                      <Input
                        id="fromDate"
                        placeholder="YYYY-MM-DD"
                        value={fromDate ? format(fromDate, 'yyyy-MM-dd') : ''}
                        onChange={(e) => {
                          const dateString = e.target.value;
                          try {
                            const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                            if (isValid(parsedDate)) { setFromDate(parsedDate); setShowReport(false); }
                            else if (dateString === '') { setFromDate(undefined); setShowReport(false); }
                          } catch { setFromDate(undefined); setShowReport(false); }
                        }}
                        onFocus={() => setIsFromDateCalendarOpen(true)}
                        className={cn("w-full justify-start text-left font-normal pe-10 text-center bg-card", !fromDate && "text-muted-foreground")}
                      />
                      <CalendarIcon
                        className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 opacity-50 cursor-pointer"
                        onClick={() => setIsFromDateCalendarOpen(prev => !prev)}
                      />
                    </div>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                    <Calendar 
                        mode="single" 
                        selected={fromDate} 
                        onSelect={(date) => {setFromDate(date); setShowReport(false); setIsFromDateCalendarOpen(false);}} 
                        captionLayout="dropdown-buttons"
                        fromYear={fromCalYear}
                        toYear={toCalYear}
                        defaultMonth={fromDate || new Date()}
                        initialFocus 
                        locale={arSA} 
                        dir="rtl" 
                    />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-1">
              <Label htmlFor="toDate">إلى تاريخ</Label>
              <Popover open={isToDateCalendarOpen} onOpenChange={setIsToDateCalendarOpen}>
                <PopoverTrigger asChild>
                    <div className="relative">
                      <Input
                        id="toDate"
                        placeholder="YYYY-MM-DD"
                        value={toDate ? format(toDate, 'yyyy-MM-dd') : ''}
                        onChange={(e) => {
                          const dateString = e.target.value;
                          try {
                            const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                            if (isValid(parsedDate) && (!fromDate || parsedDate >= fromDate)) { setToDate(parsedDate); setShowReport(false); }
                            else if (dateString === '') { setToDate(undefined); setShowReport(false); }
                          } catch { setToDate(undefined); setShowReport(false); }
                        }}
                        onFocus={() => setIsToDateCalendarOpen(true)}
                        className={cn("w-full justify-start text-left font-normal pe-10 text-center bg-card", !toDate && "text-muted-foreground")}
                      />
                      <CalendarIcon
                        className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 opacity-50 cursor-pointer"
                        onClick={() => setIsToDateCalendarOpen(prev => !prev)}
                      />
                    </div>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                    <Calendar 
                        mode="single" 
                        selected={toDate} 
                        onSelect={(date) => {setToDate(date); setShowReport(false); setIsToDateCalendarOpen(false);}} 
                        disabled={(date) => (fromDate && date < fromDate)} 
                        captionLayout="dropdown-buttons"
                        fromYear={fromCalYear}
                        toYear={toCalYear}
                        defaultMonth={toDate || fromDate || new Date()}
                        initialFocus 
                        locale={arSA} 
                        dir="rtl" 
                    />
                </PopoverContent>
              </Popover>
            </div>
          </div>
          <div className="space-y-2">
            <Label>اختر حالات الدفع:</Label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2">
              {PAYMENT_STATUSES.map(statusInfo => (
                <div key={statusInfo.value} className="flex items-center space-x-2 space-x-reverse">
                  <Checkbox
                    id={`status-${statusInfo.value}`}
                    checked={selectedStatuses.includes(statusInfo.value)}
                    onCheckedChange={(checked) => handleStatusChange(statusInfo.value, !!checked)}
                  />
                  <Label htmlFor={`status-${statusInfo.value}`} className="font-normal cursor-pointer">
                    {getConstantLabel(PAYMENT_STATUSES, statusInfo.value)}
                  </Label>
                </div>
              ))}
            </div>
          </div>
           <Button onClick={handleViewReport} className="w-full md:w-auto" disabled={!selectedTenantId}>
             عرض التقرير
           </Button>
        </div>

        {showReport && selectedTenantDetails && (
          <div id="account-statement-print-area" className="mt-6 space-y-4">
            <h3 className="text-xl font-semibold text-center">
              كشف حساب للمستأجر: {selectedTenantDetails.tenantName}
            </h3>
            {(fromDate && toDate) && (
              <p className="text-sm text-muted-foreground text-center">
                الفترة من: {format(fromDate, 'yyyy/MM/dd')} إلى: {format(toDate, 'yyyy/MM/dd')}
              </p>
            )}
            <p className="text-sm text-muted-foreground text-center">
              حالات الدفع المضمنة: {selectedStatuses.map(s => getConstantLabel(PAYMENT_STATUSES, s)).join(', ') || 'جميع الحالات'}
            </p>

            {filteredPayments.length > 0 ? (
              <div className="overflow-x-auto rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[100px]">التاريخ</TableHead>
                      <TableHead className="min-w-[180px]">البيان</TableHead>
                      <TableHead className="min-w-[110px] text-center">المبلغ المستحق</TableHead>
                      <TableHead className="min-w-[110px] text-center">المبلغ المدفوع</TableHead>
                      <TableHead className="min-w-[110px] text-center">الرصيد</TableHead>
                      <TableHead className="min-w-[110px] text-center">الحالة</TableHead>
                      <TableHead className="min-w-[150px] text-center">المرفقات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPayments.map(payment => {
                       const { displayStatusLabel, displayStatusVariant, displayStatusClassName } = getPaymentStatusDisplay(payment);
                      return (
                        <TableRow key={payment.paymentId}>
                          <TableCell>{format(parseISO(payment.dueDate), 'yyyy/MM/dd', { locale: arSA })}</TableCell>
                          <TableCell className="font-medium">{payment.description}</TableCell>
                          <TableCell className="text-center">{payment.amountDue.toLocaleString()} ريال</TableCell>
                          <TableCell className="text-center">{payment.amountPaid.toLocaleString()} ريال</TableCell>
                          <TableCell className="text-center">{(payment.amountDue - payment.amountPaid).toLocaleString()} ريال</TableCell>
                          <TableCell className="text-center">
                            <Badge variant={displayStatusVariant} className={cn(displayStatusClassName, 'badge-print')}>
                              {displayStatusLabel}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-center">
                            {payment.paymentAttachments && payment.paymentAttachments.length > 0 ? (
                              <ul className="attachments-list-print">
                                {payment.paymentAttachments.map((att, idx) => (
                                  <li key={idx}><a href={att.url} target="_blank" rel="noopener noreferrer">{att.name}</a></li>
                                ))}
                              </ul>
                            ) : (
                              <span className="text-xs text-muted-foreground">لا توجد مرفقات</span>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                  <ReportTableFooter className="total-row bg-muted/50">
                    <TableRow>
                      <TableCell colSpan={2} className="font-bold text-lg"><Sigma className="inline h-5 w-5 me-2 text-primary" />الإجماليات</TableCell>
                      <TableCell className="text-center font-bold text-lg">{reportTotals.totalDue.toLocaleString()} ريال</TableCell>
                      <TableCell className="text-center font-bold text-lg">{reportTotals.totalPaid.toLocaleString()} ريال</TableCell>
                      <TableCell className="text-center font-bold text-lg">{reportTotals.balance.toLocaleString()} ريال</TableCell>
                      <TableCell colSpan={2}></TableCell>
                    </TableRow>
                  </ReportTableFooter>
                </Table>
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">لا توجد دفعات تطابق معايير البحث المحددة.</p>
            )}
            <div className="text-center mt-4 no-print">
                <Button onClick={handlePrint} disabled={filteredPayments.length === 0}><Printer className="me-2 h-4 w-4"/>طباعة التقرير</Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
