
'use client';

import type { BankTransaction, Attachment } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableCaption,
  TableFooter
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Edit3, Trash2, UploadCloud, FileText, X, Sigma, User, Clock } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { arSA } from 'date-fns/locale';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import React, { useRef, useMemo } from 'react';
import { useAppContext } from '@/contexts/app-context';


interface BankTransactionsTableProps {
  transactions: BankTransaction[];
  onEditTransaction: (transaction: BankTransaction) => void;
  onDeleteTransaction: (transaction: BankTransaction) => void;
  onAddAttachment: (transactionId: string, file: File) => Promise<void>;
  onDeleteAttachment: (transactionId: string, attachmentName: string) => Promise<void>;
  canEdit?: boolean;
  canDelete?: boolean;
}

const highlightKeywords = (text: string) => {
  const keywords = ["سحب نقدي", "تحويل بنكي"];
  let result: (string | JSX.Element)[] = [text];

  keywords.forEach(keyword => {
    const newResult: (string | JSX.Element)[] = [];
    result.forEach(segment => {
      if (typeof segment === 'string') {
        const parts = segment.split(new RegExp(`(${keyword})`, 'gi'));
        parts.forEach((part, index) => {
          if (part.toLowerCase() === keyword.toLowerCase()) {
            newResult.push(<span key={`${keyword}-${index}-${Math.random()}`} className="text-red-500 font-semibold">{part}</span>);
          } else {
            newResult.push(part);
          }
        });
      } else {
        newResult.push(segment);
      }
    });
    result = newResult;
  });

  return result.filter(item => (typeof item === 'string' ? item.length > 0 : true)).map((item, idx) => <React.Fragment key={idx}>{item}</React.Fragment>);
};


export function BankTransactionsTable({ 
  transactions, 
  onEditTransaction, 
  onDeleteTransaction,
  onAddAttachment,
  onDeleteAttachment,
  canEdit,
  canDelete
}: BankTransactionsTableProps) {
  
  const fileInputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const { currentUser } = useAppContext();
  const canAddAttachment = currentUser?.permissions?.canAdd ?? false;

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>, transactionId: string) => {
    const file = event.target.files?.[0];
    if (file) {
      await onAddAttachment(transactionId, file);
      if (event.target) {
        event.target.value = ''; 
      }
    }
  };

  const triggerFileInput = (transactionId: string) => {
    fileInputRefs.current[transactionId]?.click();
  };

  const totals = useMemo(() => {
    const totalIncoming = transactions.reduce((sum, t) => sum + (t.amountIncoming || 0), 0);
    const totalOutgoing = transactions.reduce((sum, t) => sum + (t.amountOutgoing || 0), 0);
    const netBalance = totalIncoming - totalOutgoing;
    return { totalIncoming, totalOutgoing, netBalance };
  }, [transactions]);

  const formatTimestamp = (isoString?: string) => {
    if (!isoString) return '-';
    try {
      return format(parseISO(isoString), 'yyyy/MM/dd HH:mm', { locale: arSA });
    } catch (e) {
      return 'تاريخ خاطئ';
    }
  };

  if (transactions.length === 0) {
    return <p className="text-center text-muted-foreground py-8">لا توجد عمليات بنكية مسجلة.</p>;
  }

  return (
    <div className="overflow-x-auto rounded-md border">
      <Table>
        <TableCaption>قائمة بجميع العمليات البنكية المسجلة للتركة.</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="min-w-[100px]">رقم العملية</TableHead>
            <TableHead className="min-w-[120px]">التاريخ</TableHead>
            <TableHead className="min-w-[200px]">البيان</TableHead>
            <TableHead className="min-w-[150px] text-green-600">مبلغ وارد (ريال)</TableHead>
            <TableHead className="min-w-[150px] text-destructive">مبلغ صادر (ريال)</TableHead>
            <TableHead className="text-center min-w-[100px]">الإجراءات</TableHead>
            <TableHead className="min-w-[180px]">المرفقات</TableHead>
            <TableHead className="min-w-[150px]">آخر تعديل بواسطة</TableHead>
            <TableHead className="min-w-[170px]">وقت آخر تعديل</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions.map((transaction, index) => (
            <TableRow key={transaction.id} className="hover:bg-muted/20 transition-colors">
              <TableCell className="font-mono text-xs">{1001 + index}</TableCell>
              <TableCell>{format(parseISO(transaction.date), 'yyyy/MM/dd', { locale: arSA })}</TableCell>
              <TableCell className="font-medium">{highlightKeywords(transaction.description)}</TableCell>
              <TableCell className="text-green-600">
                {transaction.amountIncoming ? transaction.amountIncoming.toLocaleString() : '-'}
              </TableCell>
              <TableCell className="text-destructive">
                {transaction.amountOutgoing ? transaction.amountOutgoing.toLocaleString() : '-'}
              </TableCell>
              <TableCell className="text-center">
                <TooltipProvider>
                  <div className="flex items-center justify-center space-x-1 space-x-reverse">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-primary hover:text-primary/90 h-8 w-8"
                          onClick={() => onEditTransaction(transaction)}
                          disabled={!canEdit}
                        >
                          <Edit3 className="h-4 w-4" />
                          <span className="sr-only">تعديل العملية</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>{!canEdit ? "لا تملك صلاحية التعديل" : "تعديل العملية"}</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:text-destructive/90 h-8 w-8"
                          onClick={() => onDeleteTransaction(transaction)}
                          disabled={!canDelete}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">حذف العملية</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف العملية"}</p></TooltipContent>
                    </Tooltip>
                  </div>
                </TooltipProvider>
              </TableCell>
              <TableCell>
                <div className="space-y-1">
                  {transaction.attachments && transaction.attachments.map(att => (
                    <div key={att.name} className="flex items-center justify-between text-xs group">
                      <Button variant="link" size="sm" asChild className="p-0 h-auto text-primary hover:underline flex-grow justify-start">
                        <a href={att.url} target="_blank" rel="noopener noreferrer" className="flex items-center">
                          <FileText className="h-3 w-3 me-1 flex-shrink-0" />
                          <span className="truncate" title={att.name}>{att.name}</span>
                        </a>
                      </Button>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-5 w-5 text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={() => onDeleteAttachment(transaction.id, att.name)}
                              disabled={!canDelete}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="top"><p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف المرفق"}</p></TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  ))}
                  <input 
                    type="file" 
                    ref={el => fileInputRefs.current[transaction.id] = el} 
                    style={{ display: 'none' }} 
                    onChange={(e) => handleFileChange(e, transaction.id)}
                  />
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-1" 
                          onClick={() => triggerFileInput(transaction.id)}
                          disabled={!canAddAttachment}
                        >
                          <UploadCloud className="h-3 w-3 me-1" /> إرفاق ملف
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent side="top"><p>{!canAddAttachment ? "لا تملك صلاحية الإضافة" : "إرفاق ملف جديد لهذه العملية"}</p></TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                {(!transaction.attachments || transaction.attachments.length === 0) && <p className="text-xs text-muted-foreground text-center py-1">لا توجد مرفقات</p>}
              </TableCell>
              <TableCell>
                <div className="flex items-center text-xs text-muted-foreground">
                  <User className="h-3 w-3 me-1" /> {transaction.lastModifiedBy || '-'}
                </div>
              </TableCell>
              <TableCell>
                <div className="flex items-center text-xs text-muted-foreground">
                  <Clock className="h-3 w-3 me-1" /> {formatTimestamp(transaction.lastModifiedAt)}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
        <TableFooter className="bg-muted/50">
            <TableRow>
                <TableCell colSpan={3} className="font-semibold text-lg">
                    <div className="flex items-center">
                        <Sigma className="h-5 w-5 me-2 text-primary" /> الإجماليات
                    </div>
                </TableCell>
                <TableCell className="font-semibold text-lg text-green-600">
                    {totals.totalIncoming.toLocaleString()} ريال
                </TableCell>
                <TableCell className="font-semibold text-lg text-destructive">
                    {totals.totalOutgoing.toLocaleString()} ريال
                </TableCell>
                <TableCell colSpan={4} className="font-semibold text-lg text-right"> {/* Adjusted colSpan */}
                    الرصيد الصافي: <span className={totals.netBalance >= 0 ? 'text-primary' : 'text-destructive'}>{totals.netBalance.toLocaleString()} ريال</span>
                </TableCell>
            </TableRow>
        </TableFooter>
      </Table>
    </div>
  );
}

