
'use client';

import { useState, useMemo } from 'react';
import type { Payment, Expense } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Printer, ArrowRight, Sigma as SigmaIcon, TrendingUp, TrendingDown, CalendarIcon as CalendarIconLucide } from 'lucide-react';
import { format, parse, parseISO, isWithinInterval, isValid, startOfDay, endOfDay, getYear, subYears, addYears } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface ProfitAndLossReportProps {
  payments: Payment[];
  expenses: Expense[];
  reportTitle: string;
  onBackToDashboard?: () => void;
}

export function ProfitAndLossReport({
  payments,
  expenses,
  reportTitle,
  onBackToDashboard,
}: ProfitAndLossReportProps) {
  const { toast } = useToast();

  const [fromDate, setFromDate] = useState<Date | undefined>(() => {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth(), 1); // Default to start of current month
  });
  const [toDate, setToDate] = useState<Date | undefined>(() => new Date()); // Default to today
  const [isFromDateCalendarOpen, setIsFromDateCalendarOpen] = useState(false);
  const [isToDateCalendarOpen, setIsToDateCalendarOpen] = useState(false);

  const filteredData = useMemo(() => {
    if (!fromDate || !toDate || !isValid(fromDate) || !isValid(toDate)) {
      return { income: 0, expensesTotal: 0, net: 0, hasData: false };
    }

    const startDate = startOfDay(fromDate);
    const endDate = endOfDay(toDate);

    if (endDate < startDate) {
      return { income: 0, expensesTotal: 0, net: 0, hasData: false };
    }

    const currentPayments = payments || [];
    const currentExpenses = expenses || [];

    const income = currentPayments
      .filter(payment => {
        try {
          const paymentDueDate = parseISO(payment.dueDate);
          return isWithinInterval(paymentDueDate, { start: startDate, end: endDate });
        } catch (e) { return false; }
      })
      .reduce((sum, payment) => sum + payment.amountPaid, 0);

    const expensesTotal = currentExpenses
      .filter(expense => {
        try {
          const expenseDate = parseISO(expense.date);
          return isWithinInterval(expenseDate, { start: startDate, end: endDate });
        } catch (e) { return false; }
      })
      .reduce((sum, expense) => sum + expense.amount, 0);

    const net = income - expensesTotal;
    const hasData = currentPayments.length > 0 || currentExpenses.length > 0;

    return { income, expensesTotal, net, hasData };
  }, [payments, expenses, fromDate, toDate]);

  const handlePrint = () => {
    if (!fromDate || !toDate) {
      toast({ title: 'الرجاء تحديد نطاق التواريخ', variant: 'destructive' });
      return;
    }
     if (!filteredData.hasData && (filteredData.income === 0 && filteredData.expensesTotal === 0)) {
      toast({ title: 'لا توجد بيانات للفترة المحددة.', variant: 'default' });
      return;
    }

    const printContentElement = document.getElementById('profit-loss-report-content');
    const printContent = printContentElement ? printContentElement.innerHTML.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';
    const dateRangeStr = `من ${format(fromDate, 'yyyy/MM/dd')} إلى ${format(toDate, 'yyyy/MM/dd')}`;
    const reportTitleSafe = reportTitle.replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
    const dateRangeStrSafe = dateRangeStr.replace(/`/g, '\\`').replace(/\$\{/g, '\\${');


    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        const printHtml = `
          <html>
            <head>
              <title>${reportTitleSafe} (${dateRangeStrSafe})</title>
              <style>
                body { font-family: "Sakkal Majalla", var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
                .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
                .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
                .report-summary { padding: 15px; border: 1px solid #eee; border-radius: 8px; margin-top: 20px; }
                .summary-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dotted #eee; font-size: 11pt; }
                .summary-item:last-child { border-bottom: none; }
                .summary-item strong { font-weight: bold; color: #333; }
                .summary-item .value { font-weight: 500; }
                .income-value { color: green !important; }
                .expense-value { color: red !important; }
                .net-profit { color: blue !important; }
                .net-loss { color: orange !important; }
                .no-print { display: none !important; }
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>${reportTitleSafe}</h1>
                <p>${dateRangeStrSafe}</p>
                <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
              </div>
              <div class="report-summary">
                <div class="summary-item"><strong>إجمالي الإيرادات (من الدفعات):</strong> <span class="value income-value">${filteredData.income.toLocaleString()} ريال</span></div>
                <div class="summary-item"><strong>إجمالي المصروفات:</strong> <span class="value expense-value">${filteredData.expensesTotal.toLocaleString()} ريال</span></div>
                <div class="summary-item"><strong>صافي الربح/الخسارة:</strong> <span class="value ${filteredData.net >= 0 ? 'net-profit' : 'net-loss'}">${filteredData.net.toLocaleString()} ريال</span></div>
              </div>
            </body>
          </html>`;
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    }
  };

  const currentCalYear = getYear(new Date());
  const fromCalYear = subYears(new Date(), 10).getFullYear();
  const toCalYear = addYears(new Date(), 10).getFullYear();

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg font-semibold flex items-center">
              <SigmaIcon className="me-3 h-7 w-7 text-primary" />
              {reportTitle}
            </CardTitle>
            <CardDescription className="text-sm font-semibold">
              عرض ملخص للإيرادات والمصروفات وصافي الربح/الخسارة خلال فترة محددة.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2 no-print">
            {onBackToDashboard && (
              <Button variant="outline" size="sm" onClick={onBackToDashboard}>
                <ArrowRight className="ms-2 h-4 w-4" />
                العودة إلى لوحة التحكم
              </Button>
            )}
            <Button onClick={handlePrint} variant="outline" size="sm" disabled={!filteredData.hasData && (filteredData.income === 0 && filteredData.expensesTotal === 0)}>
              <Printer className="me-2 h-4 w-4" />
              طباعة التقرير
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-4 p-4 border rounded-md bg-muted/30">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
            <div className="space-y-1">
              <Label htmlFor="fromDatePnL">من تاريخ</Label>
              <Popover open={isFromDateCalendarOpen} onOpenChange={setIsFromDateCalendarOpen}>
                <PopoverTrigger asChild>
                    <div className="relative">
                      <Input
                        id="fromDatePnL"
                        placeholder="YYYY-MM-DD"
                        value={fromDate ? format(fromDate, 'yyyy-MM-dd') : ''}
                        onChange={(e) => {
                          const dateString = e.target.value;
                          try {
                            const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                            if (isValid(parsedDate)) { setFromDate(parsedDate); }
                            else if (dateString === '') { setFromDate(undefined); }
                          } catch { setFromDate(undefined); }
                        }}
                        className={cn("w-full justify-start text-left font-normal pe-10 bg-card text-center", !fromDate && "text-muted-foreground")}
                      />
                      <CalendarIconLucide
                        className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 opacity-50 cursor-pointer"
                        onClick={() => setIsFromDateCalendarOpen(prev => !prev)}
                      />
                    </div>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                    <Calendar
                        mode="single"
                        selected={fromDate}
                        onSelect={(date) => {setFromDate(date); setIsFromDateCalendarOpen(false);}}
                        captionLayout="dropdown-buttons"
                        fromYear={fromCalYear}
                        toYear={toCalYear}
                        defaultMonth={fromDate || new Date()}
                        initialFocus
                        locale={arSA}
                        dir="rtl"
                    />
                </PopoverContent>
              </Popover>
            </div>
            <div className="space-y-1">
              <Label htmlFor="toDatePnL">إلى تاريخ</Label>
              <Popover open={isToDateCalendarOpen} onOpenChange={setIsToDateCalendarOpen}>
                <PopoverTrigger asChild>
                     <div className="relative">
                      <Input
                        id="toDatePnL"
                        placeholder="YYYY-MM-DD"
                        value={toDate ? format(toDate, 'yyyy-MM-dd') : ''}
                        onChange={(e) => {
                          const dateString = e.target.value;
                          try {
                            const parsedDate = parse(dateString, 'yyyy-MM-dd', new Date());
                            if (isValid(parsedDate) && (!fromDate || parsedDate >= fromDate)) { setToDate(parsedDate); }
                            else if (dateString === '') { setToDate(undefined); }
                          } catch { setToDate(undefined); }
                        }}
                        className={cn("w-full justify-start text-left font-normal pe-10 bg-card text-center", !toDate && "text-muted-foreground")}
                      />
                      <CalendarIconLucide
                        className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 opacity-50 cursor-pointer"
                        onClick={() => setIsToDateCalendarOpen(prev => !prev)}
                      />
                    </div>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                    <Calendar
                        mode="single"
                        selected={toDate}
                        onSelect={(date) => {setToDate(date); setIsToDateCalendarOpen(false);}}
                        disabled={(date) => (fromDate && date < fromDate)}
                        captionLayout="dropdown-buttons"
                        fromYear={fromCalYear}
                        toYear={toCalYear}
                        defaultMonth={toDate || fromDate || new Date()}
                        initialFocus
                        locale={arSA}
                        dir="rtl"
                    />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </div>

        <div id="profit-loss-report-content" className="mt-6 space-y-4">
          {(!fromDate || !toDate) ? (
             <p className="text-center text-muted-foreground py-8">الرجاء تحديد نطاق التواريخ لعرض التقرير.</p>
          ): (filteredData.income === 0 && filteredData.expensesTotal === 0 && !filteredData.hasData) ? (
            <p className="text-center text-muted-foreground py-8">لا توجد بيانات مالية للفترة المحددة.</p>
          ) : (
            <div className="p-6 border rounded-lg shadow-sm bg-background report-summary">
              <div className="flex justify-between items-center py-3 border-b summary-item">
                <div className="flex items-center text-lg">
                  <TrendingUp className="h-6 w-6 me-3 text-green-600" />
                  <span className="font-semibold">إجمالي الإيرادات (من الدفعات):</span>
                </div>
                <span className="text-lg font-bold text-green-600 income-value">{filteredData.income.toLocaleString()} ريال</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b summary-item">
                <div className="flex items-center text-lg">
                  <TrendingDown className="h-6 w-6 me-3 text-red-600" />
                  <span className="font-semibold">إجمالي المصروفات:</span>
                </div>
                <span className="text-lg font-bold text-red-600 expense-value">{filteredData.expensesTotal.toLocaleString()} ريال</span>
              </div>
              <div className="flex justify-between items-center py-3 mt-2 summary-item">
                <div className="flex items-center text-xl">
                  <SigmaIcon className="h-7 w-7 me-3 text-primary" />
                  <span className="font-bold">صافي الربح/الخسارة:</span>
                </div>
                <span className={cn(
                  "text-xl font-extrabold",
                  filteredData.net >= 0 ? "text-blue-600 net-profit" : "text-orange-600 net-loss"
                )}>
                  {filteredData.net.toLocaleString()} ريال
                </span>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
