
'use client';

import { useMemo } from 'react';
import { useAppContext } from '@/contexts/app-context';
import type { Tenant, Property } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Printer, Eye, CalendarClock, ArrowRight } from 'lucide-react';
import { format, parseISO, differenceInDays, isPast as dateIsPast, isValid } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const ENDING_SOON_THRESHOLD_DAYS = 90;

interface CategorizedTenantInfo {
  tenantId: string;
  tenantName: string;
  propertyId: string;
  propertyName: string;
  contractEndDate: string; // Formatted date 'yyyy/MM/dd'
  contractEndDateObj: Date;
  status: 'endingSoon' | 'active' | 'expired';
  daysDiff: number; // Positive for remaining, negative for overdue (days since expiry for expired)
  contractIdentifier: string;
}

interface DeceasedContractStatusReportProps {
  onBackToDashboard?: () => void;
}

export function DeceasedContractStatusReport({ onBackToDashboard }: DeceasedContractStatusReportProps) {
  const { deceasedTenants, deceasedProperties } = useAppContext();
  const { toast } = useToast();

  const categorizedContracts = useMemo<CategorizedTenantInfo[]>(() => {
    const today = new Date();
    // Set time to 00:00:00 for accurate day difference, ignoring time component
    const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());

    return deceasedTenants
      .map(tenant => {
        if (!tenant.contractEndDate) return null;
        try {
          const endDateObj = parseISO(tenant.contractEndDate);
          if (!isValid(endDateObj)) return null;

          const startOfEndDate = new Date(endDateObj.getFullYear(), endDateObj.getMonth(), endDateObj.getDate());
          const property = deceasedProperties.find(p => p.id === tenant.propertyId);
          let status: CategorizedTenantInfo['status'];
          let daysDiff: number;

          if (dateIsPast(startOfEndDate)) {
            status = 'expired';
            daysDiff = differenceInDays(startOfToday, startOfEndDate); // Positive: how many days past
          } else {
            daysDiff = differenceInDays(startOfEndDate, startOfToday); // Positive: how many days remaining
            if (daysDiff <= ENDING_SOON_THRESHOLD_DAYS) {
              status = 'endingSoon';
            } else {
              status = 'active';
            }
          }

          return {
            tenantId: tenant.tenantId,
            tenantName: tenant.tenantName,
            propertyId: tenant.propertyId,
            propertyName: property?.name || 'غير محدد',
            contractEndDate: format(endDateObj, 'yyyy/MM/dd', { locale: arSA }),
            contractEndDateObj: endDateObj,
            status,
            daysDiff,
            contractIdentifier: tenant.contractIdentifier || tenant.tenantId,
          };
        } catch (e) {
          console.error("Error processing tenant contract for status report:", tenant.tenantId, e);
          return null;
        }
      })
      .filter(item => item !== null) as CategorizedTenantInfo[];
  }, [deceasedTenants, deceasedProperties]);

  const endingSoonContracts = categorizedContracts.filter(c => c.status === 'endingSoon').sort((a,b) => a.daysDiff - b.daysDiff);
  const activeContracts = categorizedContracts.filter(c => c.status === 'active').sort((a,b) => b.contractEndDateObj.getTime() - a.contractEndDateObj.getTime());
  const expiredContracts = categorizedContracts.filter(c => c.status === 'expired').sort((a,b) => b.contractEndDateObj.getTime() - a.contractEndDateObj.getTime());

  const handlePrint = () => {
    const printContentElement = document.getElementById('deceased-contract-status-report-content');
    const printContent = printContentElement ? printContentElement.innerHTML.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';
    
    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        const printHtml = `
          <html>
            <head>
              <title>تقرير حالات عقود الورثة</title>
              <style>
                body { font-family: "Sakkal Majalla", var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
                .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
                .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
                .section { margin-bottom: 20px; }
                .section-title { font-size: 13pt; font-weight: bold; margin-bottom: 10px; padding-bottom: 5px; border-bottom: 1px solid #eee; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11pt; }
                th, td { border: 1px solid #ddd; padding: 6px; text-align: right; font-weight: 500; }
                th { background-color: #f2f2f2; font-weight: bold; }
                .no-print { display: none !important; }
                .badge { display: inline-block; padding: .25em .6em; font-size: 75%; font-weight: 700; line-height: 1; text-align: center; white-space: nowrap; vertical-align: baseline; border-radius: .25rem; }
                .badge-endingSoon { color: #fff !important; background-color: #dc3545 !important; } /* Red */
                .badge-active { color: #fff !important; background-color: #28a745 !important; } /* Green */
                .badge-expired { color: #212529 !important; background-color: #ffc107 !important; } /* Yellow */
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>تقرير حالات عقود الورثة</h1>
                <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
              </div>
              ${printContent}
            </body>
          </html>`;
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    }
  };

  const handlePreview = () => {
    if (categorizedContracts.length === 0) {
        toast({
            title: "لا توجد بيانات",
            description: "لا توجد عقود لعرضها في المعاينة.",
            variant: "default",
        });
        return;
    }
    handlePrint(); // Using print as preview for simplicity
    toast({
      title: "معاينة التقرير",
      description: "سيتم عرض التقرير في نافذة طباعة.",
      variant: "default",
    });
  };

  const renderContractTable = (contracts: CategorizedTenantInfo[], title: string, caption: string) => (
    <div className="section">
      <h3 className="text-lg font-semibold mb-3 section-title">{title} ({contracts.length})</h3>
      {contracts.length > 0 ? (
        <div className="overflow-x-auto rounded-md border">
          <Table>
            <TableCaption>{caption}</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead className="min-w-[130px] text-center">اسم المستأجر</TableHead>
                <TableHead className="min-w-[130px] text-center">اسم العقار</TableHead>
                <TableHead className="min-w-[100px]">رقم العقد</TableHead>
                <TableHead className="min-w-[100px] text-center">تاريخ الانتهاء</TableHead>
                <TableHead className="min-w-[150px] text-center">الحالة / الأيام</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contracts.map((contract) => {
                let statusBadge: React.ReactNode;
                let daysText: string = '';

                if (contract.status === 'endingSoon') {
                  statusBadge = <Badge variant="destructive" className="badge badge-endingSoon">قريب الانتهاء</Badge>;
                  daysText = `(${contract.daysDiff} ${contract.daysDiff === 1 ? 'يوم متبقي' : 'أيام متبقية'})`;
                } else if (contract.status === 'active') {
                  statusBadge = <Badge variant="default" className="bg-green-600 hover:bg-green-700 text-white badge badge-active">ساري</Badge>;
                   daysText = `(${contract.daysDiff} ${contract.daysDiff === 1 ? 'يوم متبقي' : 'أيام متبقية'})`;
                } else { // expired
                  statusBadge = <Badge variant="secondary" className="bg-yellow-400 hover:bg-yellow-500 text-black badge badge-expired">منتهي</Badge>;
                  daysText = `(منذ ${contract.daysDiff} ${contract.daysDiff === 1 ? 'يوم' : 'أيام'})`;
                }

                return (
                  <TableRow key={contract.tenantId}>
                    <TableCell className="font-medium text-center">{contract.tenantName}</TableCell>
                    <TableCell className="text-center">{contract.propertyName}</TableCell>
                    <TableCell>{contract.contractIdentifier}</TableCell>
                    <TableCell className="text-center">{contract.contractEndDate}</TableCell>
                    <TableCell className="text-center">
                      <div className="flex flex-col items-center">
                        {statusBadge}
                        <span className="text-xs text-muted-foreground mt-1">{daysText}</span>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">لا توجد عقود ضمن هذه الفئة.</p>
      )}
    </div>
  );

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg flex items-center">
              <CalendarClock className="me-3 h-7 w-7 text-primary" />
              تقرير حالات عقود الورثة
            </CardTitle>
            <CardDescription className="text-sm font-semibold">
              عرض للعقود السارية، القريبة من الانتهاء، والمنتهية لعقارات الورثة.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2 no-print">
            {onBackToDashboard && (
              <Button variant="outline" size="sm" onClick={onBackToDashboard}>
                 <ArrowRight className="ms-2 h-4 w-4" />
                عودة
              </Button>
            )}
            <Button onClick={handlePrint} variant="outline" size="sm" disabled={categorizedContracts.length === 0}>
              <Printer className="me-2 h-4 w-4" />
              طباعة التقرير
            </Button>
            <Button onClick={handlePreview} variant="outline" size="sm" disabled={categorizedContracts.length === 0}>
              <Eye className="me-2 h-4 w-4" />
              معاينة
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div id="deceased-contract-status-report-content" className="space-y-6">
          {categorizedContracts.length === 0 ? (
             <p className="text-center text-muted-foreground py-8">
                لا توجد عقود مسجلة لعرض حالتها.
             </p>
          ) : (
            <>
              {renderContractTable(endingSoonContracts, "العقود القريبة من الانتهاء", "قائمة بالعقود التي ستنتهي خلال " + ENDING_SOON_THRESHOLD_DAYS + " يومًا.")}
              {renderContractTable(activeContracts, "العقود السارية", "قائمة بالعقود النشطة حالياً.")}
              {renderContractTable(expiredContracts, "العقود المنتهية", "قائمة بالعقود التي انتهت صلاحيتها.")}
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
