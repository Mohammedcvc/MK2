
'use client';

import type { Tenant, Property, Payment, TaxRate, RentType, PaymentStatus } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption, TableFooter as ReportTableFooter } from '@/components/ui/table';
import { Badge, type BadgeProps } from '@/components/ui/badge';
import { format, parseISO, isToday, isBefore, differenceInCalendarDays, isPast, isValid, differenceInCalendarMonths, intervalToDuration } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { getPaymentBalance } from '@/types';
import { RENT_TYPES, TAX_RATES, PAYMENT_STATUSES, PROPERTY_STATUSES, NUMBER_OF_INSTALLMENTS_OPTIONS, getLabelForValue, PAYMENT_STATUS_BADGE_VARIANT, getNumberOfInstallmentsLabel } from '@/lib/constants';
import { Printer, XIcon, User, Home, CalendarDays, WalletCards, Percent, TrendingUp, Landmark, ListChecks, FileText as FileTextIcon, Sigma, Phone, Mail, MapPin, Clock } from 'lucide-react';
import { useMemo } from 'react';
import { cn } from '@/lib/utils';
import React from 'react';

interface TenantReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenant: Tenant | null;
  property: Property | null;
  payments: Payment[];
}

export function DetailItem({ icon: Icon, label, value, className }: { icon: React.ElementType; label: string; value: React.ReactNode, className?: string }) {
  return (
    <div className={cn('flex items-start space-x-3 rtl:space-x-reverse py-2 border-b border-border/50 last:border-b-0 md:border-b-0 md:pb-0', className)}>
      <Icon className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
      <div className="flex-grow">
        <p className="text-sm text-muted-foreground">{label}</p>
        <div className="font-semibold text-sm">{value}</div>
      </div>
    </div>
  );
}

// For print version, simpler styling without icons
function DetailItemPrint({ label, value }: { label: string; value: React.ReactNode }) {
  // Ensure value is a string for safe HTML injection, or handle objects appropriately
  const printValue = (typeof value === 'object' && value !== null && !React.isValidElement(value))
    ? JSON.stringify(value).replace(/`/g, '\\`').replace(/\$\{/g, '\\${')
    : String(value).replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
  return (
    `<div class="detail-item-print"><span class="label">${label}:</span> <span class="value">${printValue}</span></div>`
  );
}


export function TenantReportModal({ isOpen, onClose, tenant, property, payments }: TenantReportModalProps) {
  if (!isOpen || !tenant) return null;

  const annualPreTaxRent = tenant.contractValue;
  const monthlyPreTaxRent = tenant.rentType === 'monthly' ? annualPreTaxRent / 12 : 0;

  const totalWithTaxForPeriod = tenant.rentType === 'monthly'
    ? monthlyPreTaxRent * (1 + tenant.taxRate / 100)
    : annualPreTaxRent * (1 + tenant.taxRate / 100);

  const getContractStatusLabel = (): string => {
    if (tenant.contractEndDate && isValid(parseISO(tenant.contractEndDate)) && isPast(parseISO(tenant.contractEndDate))) {
      return 'مغادر';
    }
    return 'نشط';
  };
  const contractStatusLabel = getContractStatusLabel();

  const paymentsForReport = payments; 

  const paymentTotalsForReport = useMemo(() => {
    const totalDue = paymentsForReport.reduce((sum, p) => sum + p.amountDue, 0);
    const totalPaid = paymentsForReport.reduce((sum, p) => sum + p.amountPaid, 0);
    const totalBalance = totalDue - totalPaid;
    return { totalDue, totalPaid, totalBalance };
  }, [paymentsForReport]);

  const totalPeriodValueForReport = useMemo(() => {
    if (!tenant.contractStartDate || !tenant.contractEndDate) return 0;
    try {
      const startDate = parseISO(tenant.contractStartDate);
      const endDate = parseISO(tenant.contractEndDate);
      if (!isValid(startDate) || !isValid(endDate) || endDate < startDate) return 0;

      const duration = intervalToDuration({ start: startDate, end: endDate });
      const years = duration.years || 0;
      const months = duration.months || 0;
      const days = duration.days || 0;

      const annualPreTaxRentLocal = tenant.contractValue;
      const taxRatePercentage = tenant.taxRate / 100;

      const valueForYears = annualPreTaxRentLocal * years;
      const valueForMonths = (annualPreTaxRentLocal / 12) * months;
      const valueForDays = (annualPreTaxRentLocal / 365.25) * days; 
      
      const totalPreTaxValueForExactPeriod = valueForYears + valueForMonths + valueForDays;
      return parseFloat(((totalPreTaxValueForExactPeriod) * (1 + taxRatePercentage)).toFixed(2));
    } catch (e) {
      console.error("Error calculating total period value for report:", e);
      return 0;
    }
  }, [tenant.contractStartDate, tenant.contractEndDate, tenant.contractValue, tenant.taxRate]);

  const formatTimestampForReport = (isoString?: string) => {
    if (!isoString) return '-';
    try {
      return format(parseISO(isoString), 'yyyy/MM/dd HH:mm', { locale: arSA });
    } catch (e) {
      return 'تاريخ خاطئ';
    }
  };

  const handlePrint = () => {
    const printContentsElement = document.getElementById('tenant-report-content');
    const printContents = printContentsElement ? printContentsElement.innerHTML.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';
    const tenantNameSafe = (tenant.tenantName || '').replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
    const propertyNameSafe = property?.name ? property.name.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : 'غير محدد';
    const propertyAddressSafe = property?.address ? property.address.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';

    if (printContents) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        const printHtml = `
          <html>
            <head>
              <title>تقرير المستأجر</title>
              <style>
                body { font-family: "Sakkal Majalla", var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
                .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
                .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
                .section-title { font-size: 13pt; font-weight: bold; margin-top: 15px; margin-bottom: 8px; border-bottom: 1px solid #eee; padding-bottom: 4px;}
                .details-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0 15px; margin-bottom: 15px; }
                .detail-item-print { display: block; padding: 5px 0; border-bottom: 1px dotted #eee; } /* Adjusted for print */
                .detail-item-print .label { font-weight: bold; min-width: 120px; color: #444; display: inline-block; font-size: 11pt;}
                .detail-item-print .value { color: #111; font-size: 11pt;}
                table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11pt; }
                th, td { border: 1px solid #ddd; padding: 6px; text-align: right; font-weight: 500;}
                th { background-color: #f2f2f2; font-weight: bold; }
                .total-row td { font-weight: bold; background-color: #f9f9f9; }
                .no-print { display: none; }
                .badge-print { padding: 0.2em 0.6em; border-radius: 0.25rem; font-size: 0.85em; display: inline-block; border: 1px solid transparent; }
                .badge-paid { background-color: #d4edda !important; color: #155724 !important; border-color: #c3e6cb !important; }
                .badge-pending { background-color: #e2e8f0 !important; color: #4a5568 !important; border-color: #cbd5e0 !important; }
                .badge-overdue { background-color: #f8d7da !important; color: #721c24 !important; border-color: #f5c6cb !important; }
                .badge-due-print { background-color: #ffe8cc !important; color: #994d00 !important; border-color: #ffd1a3 !important; }
                .badge-secondary-print { background-color: #fff3cd !important; color: #856404 !important; border-color: #ffeeba !important; }
                .footer-summary { margin-top: 20px; padding-top: 10px; border-top: 2px solid #ccc; text-align: left; }
                .footer-summary div { margin-bottom: 5px; font-size: 11pt;}
                .footer-summary strong { min-width: 150px; display: inline-block; }
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>تقرير المستأجر</h1>
                <p>المستأجر: ${tenantNameSafe}</p>
                <p>العقار: ${propertyNameSafe} (${propertyAddressSafe})</p>
                <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
              </div>
              <div id="print-content-inner">
                ${printContents}
              </div>
            </body>
          </html>`;
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    }
  };


  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col bg-card"> {/* Increased width and added bg-card */}
        <DialogHeader className="border-b pb-4">
          <DialogTitle className="text-lg text-primary">تقرير المستأجر: {tenant.tenantName}</DialogTitle>
          {property && <DialogDescription>العقار: {property.name} ({property.address})</DialogDescription>}
        </DialogHeader>

        <ScrollArea className="flex-grow overflow-y-auto p-1 -mx-1">
          <div id="tenant-report-content" className="p-4 space-y-6">
            <section>
               <h3 className="text-base font-semibold mb-3 text-foreground border-b pb-2 section-title">بيانات العقد</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-4 gap-y-0 details-grid">
                  <DetailItem icon={FileTextIcon} label="رقم العقد" value={tenant.contractIdentifier || tenant.tenantId} />
                  <DetailItem icon={User} label="اسم المستأجر" value={tenant.tenantName} />
                  <DetailItem icon={Home} label="العقار" value={property?.name || 'غير محدد'} />
                  {tenant.tenantPhoneNumber && <DetailItem icon={Phone} label="رقم هاتف المستأجر" value={tenant.tenantPhoneNumber} />}
                  {tenant.tenantEmail && <DetailItem icon={Mail} label="البريد الإلكتروني" value={tenant.tenantEmail} />}
                  {tenant.tenantAddress && <DetailItem icon={MapPin} label="عنوان المستأجر" value={tenant.tenantAddress} className="lg:col-span-3 md:col-span-2" />}
                  <DetailItem icon={CalendarDays} label="تاريخ بداية العقد" value={tenant.contractStartDate ? format(parseISO(tenant.contractStartDate), 'yyyy/MM/dd', { locale: arSA }) : '-'} />
                  <DetailItem icon={CalendarDays} label="تاريخ نهاية العقد" value={tenant.contractEndDate ? format(parseISO(tenant.contractEndDate), 'yyyy/MM/dd', { locale: arSA }) : '-'} />
                  <DetailItem icon={WalletCards} label="قيمة العقد السنوية (قبل الضريبة)" value={`${annualPreTaxRent.toLocaleString()} ريال`} />
                   {tenant.rentType === 'monthly' && (
                        <DetailItem
                            icon={WalletCards}
                            label="القيمة الشهرية (محسوبة, قبل الضريبة)"
                            value={`${monthlyPreTaxRent.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ريال`}
                        />
                    )}
                  <DetailItem icon={Percent} label="نسبة الضريبة" value={getLabelForValue(TAX_RATES, tenant.taxRate as TaxRate)} />
                  <DetailItem
                    icon={TrendingUp}
                    label={tenant.rentType === 'monthly' ? "الإجمالي الشهري مع الضريبة" : "الإجمالي السنوي مع الضريبة"}
                    value={`${totalWithTaxForPeriod.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال`}
                  />
                  <DetailItem
                    icon={TrendingUp}
                    label="اجمالي الفتره (مع الضريبة)"
                    value={`${totalPeriodValueForReport.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ريال`}
                  />
                  <DetailItem icon={Landmark} label="نوع الإيجار" value={getLabelForValue(RENT_TYPES, tenant.rentType as RentType)} />
                  <DetailItem icon={ListChecks} label={"دورة سداد الايجار"} value={getNumberOfInstallmentsLabel(tenant.numberOfInstallments)} />
                  <DetailItem
                    icon={FileTextIcon}
                    label="حالة العقد"
                    value={<Badge variant={contractStatusLabel === 'نشط' ? 'default' : 'secondary'} className={cn(contractStatusLabel === 'نشط' ? 'bg-green-500 hover:bg-green-600 badge-print badge-paid' : 'badge-print badge-secondary-print')}>{contractStatusLabel}</Badge>}
                  />
                  {tenant.lastModifiedBy && (
                    <DetailItem icon={User} label="آخر تعديل للعقد بواسطة" value={tenant.lastModifiedBy} />
                  )}
                  {tenant.lastModifiedAt && (
                    <DetailItem icon={Clock} label="وقت آخر تعديل للعقد" value={formatTimestampForReport(tenant.lastModifiedAt)} />
                  )}
                </div>
            </section>

            <section>
              <h3 className="text-base font-semibold mb-3 text-foreground border-b pb-2 section-title">جدول الدفعات</h3>
              {paymentsForReport.length > 0 ? (
                <div className="overflow-x-auto rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="min-w-[80px]">الرقم</TableHead>
                        <TableHead className="min-w-[120px]">تاريخ الاستحقاق</TableHead>
                        <TableHead className="min-w-[100px]">مبلغ الاستحقاق</TableHead>
                        <TableHead className="min-w-[100px]">المدفوع</TableHead>
                        <TableHead className="min-w-[100px]">الرصيد</TableHead>
                        <TableHead className="min-w-[100px]">الحالة</TableHead>
                        <TableHead className="min-w-[150px]">البيان</TableHead>
                        <TableHead className="min-w-[150px]">آخر تعديل بواسطة</TableHead>
                        <TableHead className="min-w-[170px]">وقت آخر تعديل</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {paymentsForReport.map((payment, index) => {
                        const balance = getPaymentBalance(payment);
                        const isEffectivelyPaid = balance === 0 && payment.amountDue > 0;
                        const isMarkedAsPaid = payment.status === 'paid';
                        const dueDateObj = parseISO(payment.dueDate);

                        const now = new Date();
                        const startOfDueDate = new Date(dueDateObj.getFullYear(), dueDateObj.getMonth(), dueDateObj.getDate());
                        const startOfNow = new Date(now.getFullYear(), now.getMonth(), now.getDate());
                        const daysDifference = differenceInCalendarDays(startOfDueDate, startOfNow);

                        let displayStatusLabel: string;
                        let displayStatusVariant: BadgeProps['variant'];
                        let displayStatusClassName: string | undefined;
                        let printBadgeClass: string = '';


                        if (isEffectivelyPaid || isMarkedAsPaid) {
                          displayStatusLabel = getLabelForValue(PAYMENT_STATUSES, 'paid');
                          displayStatusVariant = 'default';
                          displayStatusClassName = "bg-green-500 hover:bg-green-600 text-primary-foreground border-transparent";
                          printBadgeClass = "badge-paid";
                        } else if (payment.status === 'pending') {
                          displayStatusLabel = getLabelForValue(PAYMENT_STATUSES, 'pending');
                          displayStatusVariant = 'secondary';
                          displayStatusClassName = "bg-gray-200 text-gray-700 border-gray-300";
                          printBadgeClass = "badge-pending";
                        } else if (payment.status === 'due') {
                            displayStatusLabel = getLabelForValue(PAYMENT_STATUSES, 'due');
                            displayStatusVariant = 'outline';
                            displayStatusClassName = "border-orange-500 text-orange-700 bg-orange-100 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700 hover:bg-orange-200 dark:hover:bg-orange-800/40";
                            printBadgeClass = "badge-due-print";
                        } else if (daysDifference >= 0 && daysDifference <= 10) {
                          displayStatusLabel = "دفعه مستحقه";
                          displayStatusVariant = 'outline';
                          displayStatusClassName = "border-orange-500 text-orange-700 bg-orange-100 dark:bg-orange-900/30 dark:text-orange-300 dark:border-orange-700 hover:bg-orange-200 dark:hover:bg-orange-800/40";
                          printBadgeClass = "badge-due-print";
                        } else if (daysDifference < 0) {
                          const daysOverdueCount = Math.abs(daysDifference);
                          displayStatusLabel = `متأخرة (${daysOverdueCount} ${daysOverdueCount === 1 ? 'يوم' : 'أيام'})`;
                          displayStatusVariant = 'destructive';
                          printBadgeClass = "badge-overdue";
                        } else {
                          displayStatusLabel = getLabelForValue(PAYMENT_STATUSES, payment.status);
                          displayStatusVariant = PAYMENT_STATUS_BADGE_VARIANT[payment.status] || 'outline';
                          // No specific class for default 'outline' of other types, will inherit.
                        }

                        return (
                          <TableRow key={payment.paymentId}>
                            <TableCell>{101 + index}</TableCell>
                            <TableCell>{format(dueDateObj, 'yyyy/MM/dd', { locale: arSA })}</TableCell>
                            <TableCell>{payment.amountDue.toLocaleString()} ريال</TableCell>
                            <TableCell>{payment.amountPaid.toLocaleString()} ريال</TableCell>
                            <TableCell>{balance.toLocaleString()} ريال</TableCell>
                            <TableCell>
                              <Badge variant={displayStatusVariant} className={cn(displayStatusClassName, 'badge-print', printBadgeClass)}>
                                {displayStatusLabel}
                              </Badge>
                            </TableCell>
                            <TableCell>{payment.description}</TableCell>
                            <TableCell className="text-xs text-muted-foreground">{payment.lastModifiedBy || '-'}</TableCell>
                            <TableCell className="text-xs text-muted-foreground">{formatTimestampForReport(payment.lastModifiedAt)}</TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                    <ReportTableFooter className="total-row">
                      <TableRow>
                        <TableCell colSpan={2} className="font-semibold">الإجماليات</TableCell>
                        <TableCell className="font-semibold">{paymentTotalsForReport.totalDue.toLocaleString()} ريال</TableCell>
                        <TableCell className="font-semibold">{paymentTotalsForReport.totalPaid.toLocaleString()} ريال</TableCell>
                        <TableCell className="font-semibold">
                          {paymentTotalsForReport.totalBalance.toLocaleString()} ريال
                          {paymentTotalsForReport.totalBalance !== 0 && (
                             <span className={paymentTotalsForReport.totalBalance < 0 ? 'text-green-600' : 'text-destructive'}>
                                {paymentTotalsForReport.totalBalance < 0 ? ' (لكم رصيد إضافي)' : ' (عليكم)'}
                             </span>
                          )}
                        </TableCell>
                        <TableCell colSpan={4}></TableCell>
                      </TableRow>
                    </ReportTableFooter>
                    <TableCaption>جدول الدفعات التفصيلي.</TableCaption>
                  </Table>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">لا توجد دفعات لعرضها في هذا التقرير.</p>
              )}
            </section>
            <section className="footer-summary">
                <h3 className="text-base font-semibold mb-3 text-foreground border-b pb-2 section-title">ملخص مالي</h3>
                <div><strong>قيمة العقد السنوية (قبل الضريبة):</strong> {annualPreTaxRent.toLocaleString()} ريال</div>
                {tenant.rentType === 'monthly' &&
                  <div><strong>القيمة الشهرية (محسوبة, قبل الضريبة):</strong> {monthlyPreTaxRent.toLocaleString(undefined, {minimumFractionDigits:2, maximumFractionDigits:2})} ريال</div>
                }
                <div><strong>{tenant.rentType === 'monthly' ? 'الإجمالي الشهري مع الضريبة' : 'الإجمالي السنوي مع الضريبة'}:</strong> {totalWithTaxForPeriod.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})} ريال</div>
                <div><strong>اجمالي الفتره (مع الضريبة):</strong> {totalPeriodValueForReport.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ريال</div>
                <div><strong>إجمالي المدفوعات (من جميع الدفعات):</strong> <span className="text-green-600">{paymentTotalsForReport.totalPaid.toLocaleString()} ريال</span></div>
                <div><strong>الرصيد النهائي المستحق (من جميع الدفعات):</strong>
                    <span className={paymentTotalsForReport.totalBalance >= 0 ? (paymentTotalsForReport.totalBalance === 0 ? 'text-green-600' : 'text-destructive') : 'text-green-600'}>
                        {paymentTotalsForReport.totalBalance.toLocaleString()} ريال
                        {paymentTotalsForReport.totalBalance < 0 ? ' (لكم رصيد إضافي)' : paymentTotalsForReport.totalBalance > 0 ? ' (عليكم)' : ' (مسدد بالكامل)'}
                    </span>
                </div>
            </section>
          </div>
        </ScrollArea>

        <DialogFooter className="pt-4 border-t no-print">
          <Button variant="outline" onClick={onClose}>
            <XIcon className="me-2 h-4 w-4" /> إغلاق
          </Button>
          <Button onClick={handlePrint}>
            <Printer className="me-2 h-4 w-4" /> طباعة التقرير
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
