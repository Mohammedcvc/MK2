
'use client';

import { useMemo } from 'react';
import { useAppContext } from '@/contexts/app-context';
import type { Tenant, Property, Payment } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption, TableFooter } from '@/components/ui/table';
import { Printer, FileText as FileTextIcon, Eye, Download, Sigma, TrendingUp, ArrowRight } from 'lucide-react';
import { format, parseISO, isPast } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

interface TenantRentSummary {
  tenantId: string;
  tenantName: string;
  propertyId: string;
  propertyName: string;
  totalContractValueWithTax: number;
  totalPaid: number;
  remainingBalance: number;
}

interface DeceasedRentSummaryReportProps {
  onBackToDashboard?: () => void;
}

export function DeceasedRentSummaryReport({ onBackToDashboard }: DeceasedRentSummaryReportProps) {
  const { deceasedTenants, deceasedPayments, deceasedProperties } = useAppContext();
  const { toast } = useToast();

  const rentSummaries = useMemo<TenantRentSummary[]>(() => {
    return deceasedTenants
      .filter(tenant => {
        // Only include tenants with active or future contracts for summary purposes
        if (!tenant.contractEndDate) return false; // Or handle as per business logic
        try {
          return !isPast(parseISO(tenant.contractEndDate));
        } catch {
          return false;
        }
      })
      .map(tenant => {
        const property = deceasedProperties.find(p => p.id === tenant.propertyId);
        const tenantPayments = deceasedPayments.filter(p => p.tenantId === tenant.tenantId);

        const totalContractValueWithTax = tenant.contractValue * (1 + tenant.taxRate / 100);
        const totalPaid = tenantPayments.reduce((sum, p) => sum + p.amountPaid, 0);
        const remainingBalance = totalContractValueWithTax - totalPaid;

        return {
          tenantId: tenant.tenantId,
          tenantName: tenant.tenantName,
          propertyId: tenant.propertyId,
          propertyName: property?.name || 'غير محدد',
          totalContractValueWithTax,
          totalPaid,
          remainingBalance,
        };
      });
  }, [deceasedTenants, deceasedPayments, deceasedProperties]);

  const overallTotals = useMemo(() => {
    const totalContractValue = rentSummaries.reduce((sum, rs) => sum + rs.totalContractValueWithTax, 0);
    const totalPaid = rentSummaries.reduce((sum, rs) => sum + rs.totalPaid, 0);
    const totalRemaining = rentSummaries.reduce((sum, rs) => sum + rs.remainingBalance, 0);
    return { totalContractValue, totalPaid, totalRemaining };
  }, [rentSummaries]);

  const handlePrint = () => {
    const printContentElement = document.getElementById('deceased-rent-summary-report-content');
    const printContent = printContentElement ? printContentElement.innerHTML.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';

    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        const printHtml = `
          <html>
            <head>
              <title>تقرير إجمالي الإيجارات (عقارات الورثة)</title>
              <style>
                body { font-family: "Sakkal Majalla", var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
                .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
                .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11pt; }
                th, td { border: 1px solid #ddd; padding: 6px; text-align: right; font-weight: 500; }
                th { background-color: #f2f2f2; font-weight: bold; }
                .total-row td { font-weight: bold; background-color: #f9f9f9; }
                .amount-positive { color: green !important; }
                .amount-negative { color: red !important; }
                .amount-neutral { color: initial !important; }
                .no-print { display: none; }
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>تقرير إجمالي الإيجارات (عقارات الورثة)</h1>
                <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
              </div>
              ${printContent}
            </body>
          </html>`;
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    }
  };

  const handlePreview = () => {
    if (rentSummaries.length === 0) {
        toast({
            title: "لا توجد بيانات",
            description: "لا توجد بيانات إيجارات لعرضها في المعاينة.",
            variant: "default",
        });
        return;
    }
    handlePrint();
    toast({
      title: "معاينة التقرير",
      description: "سيتم عرض التقرير في نافذة طباعة.",
      variant: "default",
    });
  };

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg flex items-center">
              <TrendingUp className="me-3 h-7 w-7 text-primary" />
              تقرير إجمالي الإيجارات (عقارات الورثة)
            </CardTitle>
            <CardDescription className="text-sm font-semibold">
              ملخص شامل للإيجارات المستحقة، المبالغ المدفوعة، والأرصدة المتبقية للمستأجرين النشطين في عقارات الورثة.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2">
             {onBackToDashboard && (
              <Button variant="outline" size="sm" onClick={onBackToDashboard}>
                 <ArrowRight className="ms-2 h-4 w-4" />
                عودة
              </Button>
            )}
            <Button onClick={handlePrint} variant="outline" size="sm" disabled={rentSummaries.length === 0}>
              <Printer className="me-2 h-4 w-4" />
              طباعة التقرير
            </Button>
            <Button onClick={handlePreview} variant="outline" size="sm" disabled={rentSummaries.length === 0}>
              <Eye className="me-2 h-4 w-4" />
              معاينة
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div id="deceased-rent-summary-report-content">
          {rentSummaries.length > 0 ? (
            <div className="overflow-x-auto rounded-md border">
              <Table>
                <TableCaption>ملخص إيجارات عقارات الورثة (للعقود النشطة).</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[150px]">اسم المستأجر</TableHead>
                    <TableHead className="min-w-[150px]">اسم العقار</TableHead>
                    <TableHead className="min-w-[150px] text-center">إجمالي العقد (بالضريبة)</TableHead>
                    <TableHead className="min-w-[130px] text-center">إجمالي المدفوع</TableHead>
                    <TableHead className="min-w-[130px] text-center">الرصيد المتبقي</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rentSummaries.map((summary) => (
                    <TableRow key={summary.tenantId}>
                      <TableCell className="font-medium">{summary.tenantName}</TableCell>
                      <TableCell>{summary.propertyName}</TableCell>
                      <TableCell className="text-center">
                        {summary.totalContractValueWithTax.toLocaleString()} ريال
                      </TableCell>
                      <TableCell className="text-center amount-positive">
                        {summary.totalPaid.toLocaleString()} ريال
                      </TableCell>
                      <TableCell
                        className={`text-center font-semibold ${
                          summary.remainingBalance === 0 ? 'amount-neutral' :
                          summary.remainingBalance < 0 ? 'amount-positive' : 'amount-negative'
                        }`}
                      >
                         <Badge variant={summary.remainingBalance === 0 ? 'default' : (summary.remainingBalance < 0 ? 'secondary' : 'destructive')}
                            className={summary.remainingBalance === 0 ? "bg-green-500 hover:bg-green-600 text-primary-foreground" : ""}>
                            {Math.abs(summary.remainingBalance).toLocaleString()} ريال
                            {summary.remainingBalance < 0 ? ' (زيادة)' : summary.remainingBalance > 0 ? ' (مستحق)' : ''}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
                <TableFooter className="total-row bg-muted/50">
                  <TableRow>
                    <TableCell colSpan={2} className="font-bold text-lg">
                        <div className="flex items-center">
                            <Sigma className="h-5 w-5 me-2 text-primary" /> الإجماليات
                        </div>
                    </TableCell>
                    <TableCell className="text-center font-bold text-lg">
                      {overallTotals.totalContractValue.toLocaleString()} ريال
                    </TableCell>
                    <TableCell className="text-center font-bold text-lg amount-positive">
                      {overallTotals.totalPaid.toLocaleString()} ريال
                    </TableCell>
                    <TableCell
                      className={`text-center font-bold text-lg ${
                        overallTotals.totalRemaining === 0 ? 'amount-neutral' :
                        overallTotals.totalRemaining < 0 ? 'amount-positive' : 'amount-negative'
                      }`}
                    >
                      {overallTotals.totalRemaining.toLocaleString()} ريال
                    </TableCell>
                  </TableRow>
                </TableFooter>
              </Table>
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              لا توجد بيانات إيجارات لعرضها في هذا التقرير.
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
