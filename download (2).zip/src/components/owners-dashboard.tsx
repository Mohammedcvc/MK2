
'use client';

import type { Owner, OwnerTransaction, Attachment } from '@/types';
import { useAppContext } from '@/contexts/app-context';
import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { OwnerTransactionsTable } from '@/components/owner-transactions-table';
import { AddEditOwnerTransactionModal, OwnerTransactionFormValues } from '@/components/add-edit-owner-transaction-modal';
import { DeleteOwnerTransactionDialog } from '@/components/delete-owner-transaction-dialog';
import { OwnerReportModal } from '@/components/owner-report-modal';
import { useToast } from '@/hooks/use-toast';
import { PlusCircle, FileText, Sigma, UsersRound, User, Clock } from 'lucide-react';
import { format } from 'date-fns';

export function OwnersDashboard() {
  const { owners, setOwners, ownerTransactions, setOwnerTransactions, currentUser } = useAppContext();
  const { toast } = useToast();

  const [selectedOwnerId, setSelectedOwnerId] = useState<string>(owners[0]?.id || '');
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<OwnerTransaction | null>(null);
  const [isDeleteDialogVisible, setIsDeleteDialogVisible] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState<OwnerTransaction | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  const canEditTransactions = currentUser?.permissions?.canEdit ?? false;
  const canAddTransactions = currentUser?.permissions?.canAdd ?? false;
  const canDeleteTransactions = currentUser?.permissions?.canDelete ?? false;

  const selectedOwner = useMemo(() => owners.find(o => o.id === selectedOwnerId), [owners, selectedOwnerId]);

  const filteredTransactions = useMemo(() => {
    return ownerTransactions.filter(t => t.ownerId === selectedOwnerId);
  }, [ownerTransactions, selectedOwnerId]);

  const openAddTransactionModal = () => {
    if (!canAddTransactions) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية إضافة حركات مالية للمالك.", variant: "destructive"});
      return;
    }
    if (!selectedOwnerId) {
        toast({ title: "خطأ", description: "الرجاء اختيار مالك أولاً.", variant: "destructive" });
        return;
    }
    setEditingTransaction(null);
    setIsAddEditModalOpen(true);
  };

  const openEditTransactionModal = (transaction: OwnerTransaction) => {
    if (!canEditTransactions) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية تعديل الحركات المالية للمالك.", variant: "destructive"});
      return;
    }
    setEditingTransaction(transaction);
    setIsAddEditModalOpen(true);
  };

  const openDeleteTransactionDialog = (transaction: OwnerTransaction) => {
     if (!canDeleteTransactions) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف الحركات المالية للمالك.", variant: "destructive"});
      return;
    }
    setTransactionToDelete(transaction);
    setIsDeleteDialogVisible(true);
  };

  const closeModals = () => {
    setIsAddEditModalOpen(false);
    setEditingTransaction(null);
    setIsDeleteDialogVisible(false);
    setTransactionToDelete(null);
    setIsReportModalOpen(false);
  };

  const handleSaveTransaction = async (data: OwnerTransactionFormValues, transactionIdToUpdate?: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();

    if (transactionIdToUpdate) {
      setOwnerTransactions(prevTransactions =>
        prevTransactions.map(t =>
          t.id === transactionIdToUpdate
            ? { ...t, ...data, date: format(data.date, 'yyyy-MM-dd'), lastModifiedBy: modifierUsername, lastModifiedAt: modificationTimestamp }
            : t
        )
      );
      toast({ title: "تم تعديل الحركة", description: `تم تحديث بيانات الحركة "${data.description}".` });
    } else {
      const newTransaction: OwnerTransaction = {
        id: `owntrans_${Date.now()}`,
        ownerId: selectedOwnerId,
        ...data,
        date: format(data.date, 'yyyy-MM-dd'),
        attachments: [],
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
      };
      setOwnerTransactions(prevTransactions => [...prevTransactions, newTransaction]);
      toast({ title: "تمت إضافة الحركة", description: `تمت إضافة حركة جديدة ببيان "${data.description}".` });
    }
    closeModals();
  };

  const handleConfirmDeleteTransaction = async () => {
    if (!canDeleteTransactions) {
        toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف الحركات المالية للمالك.", variant: "destructive"});
        closeModals();
        return;
    }
    await new Promise(resolve => setTimeout(resolve, 500));
    if (transactionToDelete) {
      setOwnerTransactions(prevTransactions => prevTransactions.filter(t => t.id !== transactionToDelete.id));
      toast({ title: "تم حذف الحركة", description: `تم حذف الحركة "${transactionToDelete.description}" بشكل دائم.`, variant: "destructive" });
    }
    closeModals();
  };

  const handleAddAttachment = async (transactionId: string, file: File) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const newAttachment: Attachment = {
      name: file.name,
      url: `#mock-url-for-${file.name}`,
    };
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();

    setOwnerTransactions(prevTransactions =>
      prevTransactions.map(t => {
        if (t.id === transactionId) {
          return {
            ...t,
            attachments: [...(t.attachments || []), newAttachment],
            lastModifiedBy: modifierUsername,
            lastModifiedAt: modificationTimestamp,
          };
        }
        return t;
      })
    );
    toast({ title: "تم إرفاق الملف", description: `تم إرفاق "${file.name}" بنجاح.` });
  };

  const handleDeleteAttachment = async (transactionId: string, attachmentName: string) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();
    setOwnerTransactions(prevTransactions =>
      prevTransactions.map(t => {
        if (t.id === transactionId) {
          return {
            ...t,
            attachments: t.attachments?.filter(att => att.name !== attachmentName) || [],
            lastModifiedBy: modifierUsername,
            lastModifiedAt: modificationTimestamp,
          };
        }
        return t;
      })
    );
    toast({ title: "تم حذف المرفق", description: `تم حذف المرفق "${attachmentName}".`, variant: "destructive" });
  };

  const totalAmountForSelectedOwner = useMemo(() => {
    return filteredTransactions.reduce((sum, transaction) => sum + transaction.amount, 0);
  }, [filteredTransactions]);

  const handleViewReport = () => {
    if (!selectedOwner) {
        toast({ title: "خطأ", description: "الرجاء اختيار مالك لعرض التقرير.", variant: "destructive" });
        return;
    }
    if (filteredTransactions.length === 0) {
      toast({
        title: "لا توجد حركات مالية",
        description: "لا يمكن إنشاء تقرير لأنه لا توجد حركات مالية مسجلة لهذا المالك.",
        variant: "default"
      });
      return;
    }
    setIsReportModalOpen(true);
  };
  
  if (owners.length === 0) {
    return (
        <Card className="shadow-lg rounded-xl">
            <CardHeader><CardTitle>إدارة الملاك</CardTitle></CardHeader>
            <CardContent><p className="text-muted-foreground">لا يوجد ملاك معرفون في النظام.</p></CardContent>
        </Card>
    )
  }

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg flex items-center"><UsersRound className="me-3 h-7 w-7 text-primary"/>إدارة حسابات الملاك</CardTitle>
            <CardDescription className="text-sm font-semibold">عرض وإدارة الحركات المالية للملاك.</CardDescription>
          </div>
          <div className="flex flex-wrap gap-2 items-center">
            <Select value={selectedOwnerId} onValueChange={setSelectedOwnerId}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="اختر المالك" />
              </SelectTrigger>
              <SelectContent>
                {owners.map(owner => (
                  <SelectItem key={owner.id} value={owner.id}>
                    {owner.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={openAddTransactionModal} size="sm" disabled={!selectedOwnerId || !canAddTransactions}>
              <PlusCircle className="me-2 h-4 w-4" />
              إضافة حركة مالية
            </Button>
            <Button onClick={handleViewReport} variant="outline" size="sm" disabled={!selectedOwnerId || filteredTransactions.length === 0}>
              <FileText className="me-2 h-4 w-4" />
              عرض تقرير المالك
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {selectedOwnerId ? (
            <OwnerTransactionsTable
                transactions={filteredTransactions}
                onEditTransaction={openEditTransactionModal}
                onDeleteTransaction={openDeleteTransactionDialog}
                onAddAttachment={handleAddAttachment}
                onDeleteAttachment={handleDeleteAttachment}
                canEdit={canEditTransactions}
                canDelete={canDeleteTransactions}
             />
        ) : (
            <p className="text-center text-muted-foreground py-8">الرجاء اختيار مالك لعرض حركاته المالية.</p>
        )}
      </CardContent>
      {selectedOwnerId && (
        <CardFooter className="border-t p-6">
            <div className="flex items-center w-full justify-between">
            <div className="flex items-center text-lg font-semibold">
                <Sigma className="me-2 h-5 w-5 text-primary" />
                <span>إجمالي رصيد المالك ({selectedOwner?.name}):</span>
            </div>
            <span className={`text-lg font-bold ${totalAmountForSelectedOwner >= 0 ? 'text-green-600' : 'text-destructive'}`}>
                {totalAmountForSelectedOwner.toLocaleString()} ريال
            </span>
            </div>
        </CardFooter>
      )}

      {selectedOwnerId && (
        <AddEditOwnerTransactionModal
            isOpen={isAddEditModalOpen}
            onClose={closeModals}
            onSubmit={handleSaveTransaction}
            initialData={editingTransaction}
            ownerId={selectedOwnerId}
        />
      )}

      <DeleteOwnerTransactionDialog
        isOpen={isDeleteDialogVisible}
        onClose={closeModals}
        onConfirm={handleConfirmDeleteTransaction}
        transactionDescription={transactionToDelete?.description}
      />
      
      {selectedOwner && (
        <OwnerReportModal
            isOpen={isReportModalOpen}
            onClose={closeModals}
            owner={selectedOwner}
            transactions={filteredTransactions}
            totalAmount={totalAmountForSelectedOwner}
        />
      )}
    </Card>
  );
}

