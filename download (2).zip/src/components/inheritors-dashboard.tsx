
'use client';

import type { Inheritor, InheritorTransaction, Attachment, InheritorOperationType, BankTransaction } from '@/types';
import { useAppContext } from '@/contexts/app-context';
import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { InheritorTransactionsTable } from '@/components/inheritor-transactions-table';
import { AddEditInheritorTransactionModal } from '@/components/add-edit-inheritor-transaction-modal';
import { DeleteInheritorTransactionDialog } from '@/components/delete-inheritor-transaction-dialog';
import { InheritorReportModal } from '@/components/inheritor-report-modal';
import { useToast } from '@/hooks/use-toast';
import { PlusCircle, FileText, Sigma, UsersRound, Percent, User, Clock } from 'lucide-react';
import { format } from 'date-fns';
import { INHERITOR_OPERATION_TYPES } from '@/lib/constants'; 

export function InheritorsDashboard() {
  const { 
    currentUser,
    deceasedInheritors, 
    setDeceasedInheritors, // Added for potential future use (e.g., editing inheritor details)
    deceasedInheritorTransactions, 
    setDeceasedInheritorTransactions,
    setBankTransactions 
  } = useAppContext();
  const { toast } = useToast();

  const [selectedInheritorId, setSelectedInheritorId] = useState<string>(deceasedInheritors[0]?.id || '');
  const [isAddEditModalOpen, setIsAddEditModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<InheritorTransaction | null>(null);
  const [isDeleteDialogVisible, setIsDeleteDialogVisible] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState<InheritorTransaction | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  const canEditTransactions = currentUser?.permissions?.canEdit ?? false;
  const canAddTransactions = currentUser?.permissions?.canAdd ?? false;
  const canDeleteTransactions = currentUser?.permissions?.canDelete ?? false;

  const selectedInheritor = useMemo(() => deceasedInheritors.find(i => i.id === selectedInheritorId), [deceasedInheritors, selectedInheritorId]);

  const filteredTransactions = useMemo(() => {
    return deceasedInheritorTransactions.filter(t => t.inheritorId === selectedInheritorId);
  }, [deceasedInheritorTransactions, selectedInheritorId]);

  const openAddTransactionModal = () => {
    if (!canAddTransactions) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية إضافة حركات مالية للورثة.", variant: "destructive"});
      return;
    }
    if (!selectedInheritorId) {
        toast({ title: "خطأ", description: "الرجاء اختيار وريث أولاً.", variant: "destructive" });
        return;
    }
    setEditingTransaction(null);
    setIsAddEditModalOpen(true);
  };

  const openEditTransactionModal = (transaction: InheritorTransaction) => {
    if (!canEditTransactions) {
      toast({ title: "غير مصرح به", description: "ليس لديك صلاحية تعديل الحركات المالية للورثة.", variant: "destructive"});
      return;
    }
    setEditingTransaction(transaction);
    setIsAddEditModalOpen(true);
  };

  const openDeleteTransactionDialog = (transaction: InheritorTransaction) => {
    if (!canDeleteTransactions) {
        toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف الحركات المالية للورثة.", variant: "destructive"});
        return;
    }
    setTransactionToDelete(transaction);
    setIsDeleteDialogVisible(true);
  };

  const closeModals = () => {
    setIsAddEditModalOpen(false);
    setEditingTransaction(null);
    setIsDeleteDialogVisible(false);
    setTransactionToDelete(null);
    setIsReportModalOpen(false);
  };

  const createBankTransactionForInheritorPayout = (inheritorTransaction: InheritorTransaction, inheritorName: string) => {
    if (inheritorTransaction.amount < 0 && (inheritorTransaction.operationType === 'cashWithdrawal' || inheritorTransaction.operationType === 'bankTransfer')) {
      const operationTypeLabel = inheritorTransaction.operationType === 'cashWithdrawal' ? "سحب نقدي" : "تحويل بنكي";
      const modifierUsername = currentUser?.username || 'system_bank_trans_payout';
      const modificationTimestamp = new Date().toISOString();
      const newBankTransaction: BankTransaction = {
        id: `bank_trans_inh_${Date.now()}_${inheritorTransaction.id}`,
        date: inheritorTransaction.date,
        description: `${operationTypeLabel} للوارث ${inheritorName}: ${inheritorTransaction.description}`,
        amountOutgoing: Math.abs(inheritorTransaction.amount),
        amountIncoming: 0,
        attachments: [],
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
      };
      setBankTransactions(prev => [...prev, newBankTransaction]);
      toast({
        title: "تم إنشاء عملية بنكية",
        description: `تم تسجيل عملية صرف بنكية تلقائية بقيمة ${newBankTransaction.amountOutgoing?.toLocaleString()} ريال لحركة الوارث.`,
      });
    }
  };

  const handleSaveTransaction = async (data: Pick<InheritorTransaction, 'date' | 'amount' | 'description' | 'operationType'>, transactionIdToUpdate?: string) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    let processedTransaction: InheritorTransaction;
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();

    if (transactionIdToUpdate) {
      let originalTransaction: InheritorTransaction | undefined;
      setDeceasedInheritorTransactions(prevTransactions =>
        prevTransactions.map(t => {
          if (t.id === transactionIdToUpdate) {
            originalTransaction = t; 
            processedTransaction = { 
                ...t, 
                ...data, 
                operationType: data.operationType || t.operationType,
                lastModifiedBy: modifierUsername,
                lastModifiedAt: modificationTimestamp,
              };
            return processedTransaction;
          }
          return t;
        })
      );
      toast({ title: "تم تعديل الحركة", description: `تم تحديث بيانات الحركة "${data.description}".` });
      if (processedTransaction! && selectedInheritor) {
         createBankTransactionForInheritorPayout(processedTransaction, selectedInheritor.name);
      }
    } else {
      processedTransaction = {
        id: `inh_trans_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`, 
        inheritorId: selectedInheritorId,
        ...data,
        operationType: data.operationType || INHERITOR_OPERATION_TYPES[0].value, 
        attachments: [],
        lastModifiedBy: modifierUsername,
        lastModifiedAt: modificationTimestamp,
      };
      setDeceasedInheritorTransactions(prevTransactions => [...prevTransactions, processedTransaction]);
      toast({ title: "تمت إضافة الحركة", description: `تمت إضافة حركة جديدة ببيان "${data.description}".` });
      if (selectedInheritor) {
        createBankTransactionForInheritorPayout(processedTransaction, selectedInheritor.name);
      }
    }
    closeModals();
  };

  const handleConfirmDeleteTransaction = async () => {
    if (!canDeleteTransactions) {
        toast({ title: "غير مصرح به", description: "ليس لديك صلاحية حذف الحركات المالية للورثة.", variant: "destructive"});
        closeModals();
        return;
    }
    await new Promise(resolve => setTimeout(resolve, 500));
    if (transactionToDelete) {
      setDeceasedInheritorTransactions(prevTransactions => prevTransactions.filter(t => t.id !== transactionToDelete.id));
      toast({ title: "تم حذف الحركة", description: `تم حذف الحركة "${transactionToDelete.description}" بشكل دائم. (لم يتم عكس أي عمليات بنكية مرتبطة)`, variant: "destructive" });
    }
    closeModals();
  };

  const handleAddAttachment = async (transactionId: string, file: File) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const newAttachment: Attachment = {
      name: file.name,
      url: `#mock-url-for-${file.name}`,
    };
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();

    setDeceasedInheritorTransactions(prevTransactions =>
      prevTransactions.map(t => {
        if (t.id === transactionId) {
          return {
            ...t,
            attachments: [...(t.attachments || []), newAttachment],
            lastModifiedBy: modifierUsername,
            lastModifiedAt: modificationTimestamp,
          };
        }
        return t;
      })
    );
    toast({ title: "تم إرفاق الملف", description: `تم إرفاق "${file.name}" بنجاح.` });
  };

  const handleDeleteAttachment = async (transactionId: string, attachmentName: string) => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const modifierUsername = currentUser?.username || 'system';
    const modificationTimestamp = new Date().toISOString();
    setDeceasedInheritorTransactions(prevTransactions =>
      prevTransactions.map(t => {
        if (t.id === transactionId) {
          return {
            ...t,
            attachments: t.attachments?.filter(att => att.name !== attachmentName) || [],
            lastModifiedBy: modifierUsername,
            lastModifiedAt: modificationTimestamp,
          };
        }
        return t;
      })
    );
    toast({ title: "تم حذف المرفق", description: `تم حذف المرفق "${attachmentName}".`, variant: "destructive" });
  };

  const totalAmountForSelectedInheritor = useMemo(() => {
    return filteredTransactions.reduce((sum, transaction) => sum + transaction.amount, 0);
  }, [filteredTransactions]);

  const handleViewReport = () => {
    if (!selectedInheritor) {
        toast({ title: "خطأ", description: "الرجاء اختيار وريث لعرض التقرير.", variant: "destructive" });
        return;
    }
    if (filteredTransactions.length === 0) {
      toast({
        title: "لا توجد حركات مالية",
        description: "لا يمكن إنشاء تقرير لأنه لا توجد حركات مالية مسجلة لهذا الوارث.",
        variant: "default"
      });
      return;
    }
    setIsReportModalOpen(true);
  };
  
  if (deceasedInheritors.length === 0) {
    return (
        <Card className="shadow-lg rounded-xl">
            <CardHeader><CardTitle>إدارة حسابات الورثة</CardTitle></CardHeader>
            <CardContent><p className="text-muted-foreground">لا يوجد ورثة معرفون في النظام.</p></CardContent>
        </Card>
    )
  }

  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg flex items-center"><UsersRound className="me-3 h-7 w-7 text-primary"/>إدارة حسابات الورثة</CardTitle>
            <CardDescription className="text-sm font-semibold">عرض وإدارة الحركات المالية للورثة ونسبهم.</CardDescription>
          </div>
          <div className="flex flex-wrap gap-2 items-center">
            <Select value={selectedInheritorId} onValueChange={setSelectedInheritorId}>
              <SelectTrigger className="w-full md:w-[200px]">
                <SelectValue placeholder="اختر الوارث" />
              </SelectTrigger>
              <SelectContent>
                {deceasedInheritors.map(inheritor => (
                  <SelectItem key={inheritor.id} value={inheritor.id}>
                    {inheritor.name} {inheritor.sharePercentage !== undefined ? `(${inheritor.sharePercentage}%)` : ''}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={openAddTransactionModal} size="sm" disabled={!selectedInheritorId || !canAddTransactions}>
              <PlusCircle className="me-2 h-4 w-4" />
              إضافة حركة مالية
            </Button>
            <Button onClick={handleViewReport} variant="outline" size="sm" disabled={!selectedInheritorId || filteredTransactions.length === 0}>
              <FileText className="me-2 h-4 w-4" />
              عرض تقرير الوارث
            </Button>
          </div>
        </div>
        {selectedInheritor && selectedInheritor.sharePercentage !== undefined && (
             <div className="mt-2 text-sm text-muted-foreground flex items-center">
                <Percent className="me-2 h-4 w-4 text-primary" />
                <span>حصة الوارث المحدد ({selectedInheritor.name}): <strong>{selectedInheritor.sharePercentage}%</strong></span>
            </div>
        )}
      </CardHeader>
      <CardContent className="p-6">
        {selectedInheritorId ? (
            <InheritorTransactionsTable
                transactions={filteredTransactions}
                onEditTransaction={openEditTransactionModal}
                onDeleteTransaction={openDeleteTransactionDialog}
                onAddAttachment={handleAddAttachment}
                onDeleteAttachment={handleDeleteAttachment}
                canEdit={canEditTransactions}
                canDelete={canDeleteTransactions}
             />
        ) : (
            <p className="text-center text-muted-foreground py-8">الرجاء اختيار وريث لعرض حركاته المالية.</p>
        )}
      </CardContent>
      {selectedInheritorId && (
        <CardFooter className="border-t p-6">
            <div className="flex items-center w-full justify-between">
            <div className="flex items-center text-lg font-semibold">
                <Sigma className="me-2 h-5 w-5 text-primary" />
                <span>إجمالي رصيد الوارث ({selectedInheritor?.name}):</span>
            </div>
            <span className={`text-lg font-bold ${totalAmountForSelectedInheritor >= 0 ? 'text-green-600' : 'text-destructive'}`}>
                {totalAmountForSelectedInheritor.toLocaleString()} ريال
            </span>
            </div>
        </CardFooter>
      )}

      {selectedInheritorId && (
        <AddEditInheritorTransactionModal
            isOpen={isAddEditModalOpen}
            onClose={closeModals}
            onSubmit={handleSaveTransaction}
            initialData={editingTransaction}
            inheritorId={selectedInheritorId}
        />
      )}

      <DeleteInheritorTransactionDialog
        isOpen={isDeleteDialogVisible}
        onClose={closeModals}
        onConfirm={handleConfirmDeleteTransaction}
        transactionDescription={transactionToDelete?.description}
      />
      
      {selectedInheritor && (
        <InheritorReportModal
            isOpen={isReportModalOpen}
            onClose={closeModals}
            inheritor={selectedInheritor}
            transactions={filteredTransactions}
            totalAmount={totalAmountForSelectedInheritor}
        />
      )}
    </Card>
  );
}

