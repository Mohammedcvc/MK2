
'use client';

import type { Payment, Attachment } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format, parseISO } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { XIcon, FileText as FileTextIcon, CalendarDays, Wallet, FilePenLine } from 'lucide-react';
import { DetailItem } from './tenant-report-modal'; // Re-using DetailItem

interface SimplePaymentDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  payment: Payment | null;
}

export function SimplePaymentDetailModal({ isOpen, onClose, payment }: SimplePaymentDetailModalProps) {
  if (!isOpen || !payment) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg bg-card">
        <DialogHeader className="border-b pb-4">
          <DialogTitle className="text-lg text-primary flex items-center">
            <FilePenLine className="me-2 h-5 w-5" />
            تفاصيل الدفعة
          </DialogTitle>
          <DialogDescription>عرض معلومات الدفعة المحددة.</DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh] p-1 -mx-1">
          <div className="p-4 space-y-3">
            <DetailItem
              icon={FilePenLine}
              label="البيان"
              value={payment.description}
            />
            <DetailItem
              icon={CalendarDays}
              label="تاريخ الاستحقاق"
              value={format(parseISO(payment.dueDate), 'yyyy/MM/dd', { locale: arSA })}
            />
            <DetailItem
              icon={Wallet}
              label="المبلغ المدفوع"
              value={`${payment.amountPaid.toLocaleString()} ريال`}
            />
            <DetailItem
              icon={Wallet}
              label="المبلغ المستحق"
              value={`${payment.amountDue.toLocaleString()} ريال`}
            />
            {payment.paymentAttachments && payment.paymentAttachments.length > 0 && (
              <DetailItem
                icon={FileTextIcon}
                label="المرفقات"
                value={
                  <ul className="list-none p-0 m-0 space-y-1">
                    {payment.paymentAttachments.map(att => (
                      <li key={att.name}>
                        <Button variant="link" asChild className="p-0 h-auto text-sm">
                          <a href={att.url} target="_blank" rel="noopener noreferrer" className="flex items-center text-primary hover:underline">
                            <FileTextIcon className="h-4 w-4 me-1.5 flex-shrink-0" /> {att.name}
                          </a>
                        </Button>
                      </li>
                    ))}
                  </ul>
                }
              />
            )}
            {(!payment.paymentAttachments || payment.paymentAttachments.length === 0) && (
                 <DetailItem
                    icon={FileTextIcon}
                    label="المرفقات"
                    value={<span className="text-xs text-muted-foreground">لا توجد مرفقات</span>}
                />
            )}
          </div>
        </ScrollArea>

        <DialogFooter className="pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            <XIcon className="me-2 h-4 w-4" /> إغلاق
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
