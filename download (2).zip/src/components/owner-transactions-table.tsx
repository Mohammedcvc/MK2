
'use client';

import type { OwnerTransaction, Attachment } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  TableCaption
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Edit3, Trash2, UploadCloud, FileText, X, User, Clock } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { arSA } from 'date-fns/locale';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import React, { useRef } from 'react';
import { useAppContext } from '@/contexts/app-context';


interface OwnerTransactionsTableProps {
  transactions: OwnerTransaction[];
  onEditTransaction: (transaction: OwnerTransaction) => void;
  onDeleteTransaction: (transaction: OwnerTransaction) => void;
  onAddAttachment: (transactionId: string, file: File) => Promise<void>;
  onDeleteAttachment: (transactionId: string, attachmentName: string) => Promise<void>;
  canEdit?: boolean;
  canDelete?: boolean;
}

export function OwnerTransactionsTable({ 
  transactions, 
  onEditTransaction, 
  onDeleteTransaction,
  onAddAttachment,
  onDeleteAttachment,
  canEdit,
  canDelete
}: OwnerTransactionsTableProps) {
  
  const fileInputRefs = useRef<Record<string, HTMLInputElement | null>>({});
  const { currentUser } = useAppContext();
  const canAddAttachment = currentUser?.permissions?.canAdd ?? false;

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>, transactionId: string) => {
    const file = event.target.files?.[0];
    if (file) {
      await onAddAttachment(transactionId, file);
      if (event.target) {
        event.target.value = ''; 
      }
    }
  };

  const triggerFileInput = (transactionId: string) => {
    fileInputRefs.current[transactionId]?.click();
  };

  const formatTimestamp = (isoString?: string) => {
    if (!isoString) return '-';
    try {
      return format(parseISO(isoString), 'yyyy/MM/dd HH:mm', { locale: arSA });
    } catch (e) {
      return 'تاريخ خاطئ';
    }
  };

  if (transactions.length === 0) {
    return <p className="text-center text-muted-foreground py-8">لا توجد حركات مالية مسجلة لهذا المالك.</p>;
  }

  return (
    <div className="overflow-x-auto rounded-md border">
      <Table>
        <TableCaption>قائمة بالحركات المالية للمالك المحدد.</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="min-w-[120px] text-center">التاريخ</TableHead>
            <TableHead className="min-w-[200px] text-center">البيان</TableHead>
            <TableHead className="min-w-[120px] text-center">لكم مبلغ (ريال)</TableHead>
            <TableHead className="min-w-[120px] text-center">عليكم مبلغ (ريال)</TableHead>
            <TableHead className="min-w-[120px] text-center">الرصيد (ريال)</TableHead>
            <TableHead className="text-center min-w-[100px]">الإجراءات</TableHead>
            <TableHead className="min-w-[200px] text-center">المرفقات</TableHead>
            <TableHead className="min-w-[150px] text-center">آخر تعديل بواسطة</TableHead>
            <TableHead className="min-w-[170px] text-center">وقت آخر تعديل</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions.map((transaction) => (
            <TableRow key={transaction.id} className="hover:bg-muted/20 transition-colors">
              <TableCell className="text-center">{format(parseISO(transaction.date), 'yyyy/MM/dd', { locale: arSA })}</TableCell>
              <TableCell className="font-medium text-center">{transaction.description}</TableCell>
              <TableCell className={`text-center ${transaction.amount > 0 ? 'text-green-600' : ''}`}>
                {transaction.amount > 0 ? transaction.amount.toLocaleString() : '-'}
              </TableCell>
              <TableCell className={`text-center ${transaction.amount < 0 ? 'text-destructive' : ''}`}>
                {transaction.amount < 0 ? Math.abs(transaction.amount).toLocaleString() : '-'}
              </TableCell>
              <TableCell className={`text-center ${transaction.amount >= 0 ? 'text-green-600' : 'text-destructive'}`}>
                {transaction.amount.toLocaleString()} 
              </TableCell>
              <TableCell className="text-center">
                <TooltipProvider>
                  <div className="flex items-center justify-center space-x-1 rtl:space-x-reverse">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-primary hover:text-primary/90 h-8 w-8"
                          onClick={() => onEditTransaction(transaction)}
                          disabled={!canEdit}
                        >
                          <Edit3 className="h-4 w-4" />
                          <span className="sr-only">تعديل الحركة</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>{!canEdit ? "لا تملك صلاحية التعديل" : "تعديل الحركة"}</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive hover:text-destructive/90 h-8 w-8"
                          onClick={() => onDeleteTransaction(transaction)}
                          disabled={!canDelete}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">حذف الحركة</span>
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent><p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف الحركة"}</p></TooltipContent>
                    </Tooltip>
                  </div>
                </TooltipProvider>
              </TableCell>
              <TableCell className="text-center">
                <div className="space-y-1">
                  {transaction.attachments && transaction.attachments.map(att => (
                    <div key={att.name} className="flex items-center justify-between text-xs group">
                      <Button variant="link" size="sm" asChild className="p-0 h-auto text-primary hover:underline flex-grow justify-start">
                        <a href={att.url} target="_blank" rel="noopener noreferrer" className="flex items-center">
                          <FileText className="h-3 w-3 me-1 flex-shrink-0" />
                          <span className="truncate" title={att.name}>{att.name}</span>
                        </a>
                      </Button>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-5 w-5 text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={() => onDeleteAttachment(transaction.id, att.name)}
                              disabled={!canDelete}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent side="top"><p>{!canDelete ? "لا تملك صلاحية الحذف" : "حذف المرفق"}</p></TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  ))}
                  <input 
                    type="file" 
                    ref={el => fileInputRefs.current[transaction.id] = el} 
                    style={{ display: 'none' }} 
                    onChange={(e) => handleFileChange(e, transaction.id)}
                  />
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="w-full mt-1" 
                          onClick={() => triggerFileInput(transaction.id)}
                          disabled={!canAddAttachment}
                        >
                          <UploadCloud className="h-3 w-3 me-1" /> إرفاق ملف
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent side="top"><p>{!canAddAttachment ? "لا تملك صلاحية الإضافة" : "إرفاق ملف جديد لهذه الحركة"}</p></TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
                {(!transaction.attachments || transaction.attachments.length === 0) && <p className="text-xs text-muted-foreground text-center py-1">لا توجد مرفقات</p>}
              </TableCell>
              <TableCell className="text-center">
                <div className="flex items-center justify-center text-xs text-muted-foreground">
                  <User className="h-3 w-3 me-1" /> {transaction.lastModifiedBy || '-'}
                </div>
              </TableCell>
              <TableCell className="text-center">
                <div className="flex items-center justify-center text-xs text-muted-foreground">
                  <Clock className="h-3 w-3 me-1" /> {formatTimestamp(transaction.lastModifiedAt)}
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

