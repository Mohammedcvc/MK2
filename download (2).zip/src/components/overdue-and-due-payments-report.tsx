
'use client';

import { useMemo, useState } from 'react';
import type { Property, Tenant, Payment } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Printer, AlertTriangle, CalendarCheck2, CalendarClock, Info, ArrowRight, Filter } from 'lucide-react';
import { format, parseISO, differenceInDays, isPast, isToday, isValid } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

const DUE_SOON_THRESHOLD_DAYS = 20;
type CriticalStatus = 'overdue' | 'dueSoon' | 'dueToday';

interface PaymentInfo {
  tenantId: string;
  tenantName: string;
  paymentId: string;
  paymentDescription: string;
  dueDate: string; // Formatted date 'yyyy/MM/dd'
  dueDateObj: Date;
  amountDue: number;
  amountPaid: number;
  balance: number;
  status: CriticalStatus;
  daysDiffText: string; // e.g., "Overdue by 5 days", "Due in 3 days", "Due Today"
}

interface PropertyPaymentsInfo {
  propertyId: string;
  propertyName: string;
  address: string;
  payments: PaymentInfo[];
}

interface OverdueAndDuePaymentsReportProps {
  properties: Property[];
  tenants: Tenant[];
  payments: Payment[];
  reportTitleKey: string;
  onBackToDashboard?: () => void;
}

const STATUS_FILTER_OPTIONS: { value: CriticalStatus; label: string }[] = [
  { value: 'overdue', label: 'متأخرة' },
  { value: 'dueSoon', label: 'مستحقة قريباً' },
  { value: 'dueToday', label: 'مستحقة اليوم' },
];

export function OverdueAndDuePaymentsReport({ properties, tenants, payments, reportTitleKey, onBackToDashboard }: OverdueAndDuePaymentsReportProps) {
  const { toast } = useToast();
  const [selectedStatuses, setSelectedStatuses] = useState<CriticalStatus[]>(['overdue', 'dueSoon', 'dueToday']);

  const handleStatusChange = (status: CriticalStatus, checked: boolean) => {
    setSelectedStatuses(prev =>
      checked ? [...prev, status] : prev.filter(s => s !== status)
    );
  };

  const reportData = useMemo<PropertyPaymentsInfo[]>(() => {
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());

    return properties.map(property => {
      const propertyTenants = tenants.filter(tenant => tenant.propertyId === property.id);
      let criticalPayments: PaymentInfo[] = [];

      propertyTenants.forEach(tenant => {
        const tenantPayments = payments.filter(p => p.tenantId === tenant.tenantId);

        tenantPayments.forEach(payment => {
          if (payment.amountPaid >= payment.amountDue) return;
          if (!payment.dueDate || !isValid(parseISO(payment.dueDate))) return;

          const dueDateObj = parseISO(payment.dueDate);
          const dueDateStart = new Date(dueDateObj.getFullYear(), dueDateObj.getMonth(), dueDateObj.getDate());

          let status: CriticalStatus | null = null;
          let daysDiffText = '';

          if (isPast(dueDateStart) && !isToday(dueDateStart)) {
            status = 'overdue';
            const daysOverdue = differenceInDays(todayStart, dueDateStart);
            daysDiffText = `متأخرة بـ ${daysOverdue} يوم`;
          } else {
            const daysUntilDue = differenceInDays(dueDateStart, todayStart);
            if (daysUntilDue === 0) {
              status = 'dueToday';
              daysDiffText = 'مستحقة اليوم';
            } else if (daysUntilDue > 0 && daysUntilDue <= DUE_SOON_THRESHOLD_DAYS) {
              status = 'dueSoon';
              daysDiffText = `مستحقة خلال ${daysUntilDue} يوم`;
            }
          }

          if (status) {
            criticalPayments.push({
              tenantId: tenant.tenantId,
              tenantName: tenant.tenantName,
              paymentId: payment.paymentId,
              paymentDescription: payment.description,
              dueDate: format(dueDateObj, 'yyyy/MM/dd', { locale: arSA }),
              dueDateObj,
              amountDue: payment.amountDue,
              amountPaid: payment.amountPaid,
              balance: payment.amountDue - payment.amountPaid,
              status,
              daysDiffText,
            });
          }
        });
      });

      // Filter by selected statuses
      const filteredPayments = criticalPayments.filter(p => selectedStatuses.includes(p.status));

      filteredPayments.sort((a, b) => {
        if (a.status === 'overdue' && b.status !== 'overdue') return -1;
        if (a.status !== 'overdue' && b.status === 'overdue') return 1;
        return a.dueDateObj.getTime() - b.dueDateObj.getTime();
      });

      return {
        propertyId: property.id,
        propertyName: property.name,
        address: property.address,
        payments: filteredPayments,
      };
    }).filter(p => p.payments.length > 0);
  }, [properties, tenants, payments, selectedStatuses]);

  const handlePrint = () => {
    const baseReportTitle = reportTitleKey === 'deceasedOverdueAndDuePaymentsReportTitle' ? 'تقرير الدفعات الهامة (عقارات الورثة)' : 'تقرير الدفعات الهامة (العقار الذكي)';
    let reportTitleWithFilters = baseReportTitle;
    if (selectedStatuses.length < STATUS_FILTER_OPTIONS.length) {
        const selectedLabels = selectedStatuses.map(s => STATUS_FILTER_OPTIONS.find(opt => opt.value === s)?.label).filter(Boolean).join('، ');
        reportTitleWithFilters += ` - الفلتر: ${selectedLabels}`;
    }

    const printContent = document.getElementById('overdue-due-payments-report-content')?.innerHTML;
    if (printContent) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(
          `<html>
            <head>
              <title>${reportTitleWithFilters}</title>
              <style>
                body { font-family: "Sakkal Majalla", var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
                .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
                .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
                .property-section { margin-bottom: 25px; padding: 15px; border: 1px solid #eee; border-radius: 8px; page-break-inside: avoid; }
                .property-title { font-size: 13pt; font-weight: bold; margin-bottom: 5px; color: #125A6A; }
                .property-address { font-size: 11pt; color: #555; margin-bottom: 10px; }
                table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 11pt; }
                th, td { border: 1px solid #ddd; padding: 6px; text-align: right; font-weight: 500; }
                th { background-color: #f2f2f2; font-weight: bold; }
                .no-print { display: none !important; }
                .badge-print { display: inline-block; padding: .25em .6em; font-size: 85%; font-weight: 700; line-height: 1; text-align: center; white-space: nowrap; vertical-align: baseline; border-radius: .25rem; border: 1px solid transparent; }
                .badge-overdue { background-color: #f8d7da !important; color: #721c24 !important; border-color: #f5c6cb !important; }
                .badge-dueSoon { background-color: #fff3cd !important; color: #856404 !important; border-color: #ffeeba !important; }
                .badge-dueToday { background-color: #ffe8cc !important; color: #994d00 !important; border-color: #ffd1a3 !important; }
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>${reportTitleWithFilters}</h1>
                <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
              </div>
              ${printContent}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    } else {
      toast({
        title: 'خطأ',
        description: 'لم يتم العثور على محتوى للطباعة.',
        variant: 'destructive',
      });
    }
  };

  const getStatusBadge = (status: PaymentInfo['status']) => {
    switch (status) {
      case 'overdue':
        return <Badge variant="destructive" className="badge-print badge-overdue">متأخرة</Badge>;
      case 'dueSoon':
        return <Badge variant="outline" className="border-amber-500 text-amber-700 bg-amber-100 badge-print badge-dueSoon">مستحقة قريباً</Badge>;
      case 'dueToday':
        return <Badge variant="outline" className="border-orange-500 text-orange-700 bg-orange-100 badge-print badge-dueToday">مستحقة اليوم</Badge>;
      default:
        return null;
    }
  };


  return (
    <Card className="shadow-lg rounded-xl">
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg font-semibold flex items-center">
              <AlertTriangle className="me-3 h-7 w-7 text-primary" />
              {reportTitleKey === 'deceasedOverdueAndDuePaymentsReportTitle' ? 'تقرير الدفعات الهامة (عقارات الورثة)' : 'تقرير الدفعات الهامة (العقار الذكي)'}
            </CardTitle>
            <CardDescription className="text-sm font-semibold">
              عرض للدفعات المتأخرة والمستحقة قريباً لكل عقار.
            </CardDescription>
          </div>
          <div className="flex flex-wrap items-center gap-2 no-print">
             {onBackToDashboard && (
              <Button variant="outline" size="sm" onClick={onBackToDashboard}>
                <ArrowRight className="ms-2 h-4 w-4" />
                عودة
              </Button>
            )}
            <Button onClick={handlePrint} variant="outline" size="sm" disabled={reportData.length === 0}>
              <Printer className="me-2 h-4 w-4" />
              طباعة التقرير
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="space-y-4 p-4 border rounded-md bg-muted/30 no-print">
          <Label className="flex items-center text-md font-semibold"><Filter className="me-2 h-5 w-5 text-primary" />فلترة حسب الحالة:</Label>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-2">
            {STATUS_FILTER_OPTIONS.map(statusInfo => (
              <div key={statusInfo.value} className="flex items-center space-x-2 space-x-reverse">
                <Checkbox
                  id={`status-filter-${statusInfo.value}`}
                  checked={selectedStatuses.includes(statusInfo.value)}
                  onCheckedChange={(checked) => handleStatusChange(statusInfo.value, !!checked)}
                />
                <Label htmlFor={`status-filter-${statusInfo.value}`} className="font-normal cursor-pointer">
                  {statusInfo.label}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <div id="overdue-due-payments-report-content">
          {reportData.length === 0 ? (
             <div className="text-center text-muted-foreground py-12">
                <CalendarCheck2 className="mx-auto h-16 w-16 text-green-500 mb-4" />
                <p className="text-xl font-semibold">لا توجد دفعات متأخرة أو مستحقة قريباً تطابق الفلتر</p>
                <p className="text-sm">جميع الدفعات الحالية مسددة أو غير مستحقة بعد، أو لا تطابق معايير الفلترة الحالية.</p>
             </div>
          ) : (
            reportData.map(propertyInfo => (
              <section key={propertyInfo.propertyId} className="mb-8 property-section">
                <h3 className="property-title">{propertyInfo.propertyName}</h3>
                <p className="text-xs text-muted-foreground property-address">{propertyInfo.address}</p>
                {propertyInfo.payments.length > 0 ? (
                  <div className="overflow-x-auto rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="min-w-[130px]">اسم المستأجر</TableHead>
                          <TableHead className="min-w-[150px]">بيان الدفعة</TableHead>
                          <TableHead className="min-w-[100px] text-center">تاريخ الاستحقاق</TableHead>
                          <TableHead className="min-w-[100px] text-center">المبلغ المستحق</TableHead>
                           <TableHead className="min-w-[100px] text-center">المدفوع</TableHead>
                          <TableHead className="min-w-[100px] text-center">الرصيد</TableHead>
                          <TableHead className="min-w-[150px] text-center">الحالة / الملاحظات</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {propertyInfo.payments.map((payment) => (
                          <TableRow key={payment.paymentId}>
                            <TableCell className="font-medium">{payment.tenantName}</TableCell>
                            <TableCell>{payment.paymentDescription}</TableCell>
                            <TableCell className="text-center">{payment.dueDate}</TableCell>
                            <TableCell className="text-center">{payment.amountDue.toLocaleString()} ريال</TableCell>
                            <TableCell className="text-center">{payment.amountPaid.toLocaleString()} ريال</TableCell>
                            <TableCell className="text-center font-semibold text-destructive">{payment.balance.toLocaleString()} ريال</TableCell>
                            <TableCell className="text-center">
                                {getStatusBadge(payment.status)}
                                <span className="block text-xs text-muted-foreground mt-1">{payment.daysDiffText}</span>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground py-4">لا توجد دفعات تطابق الفلتر الحالي لهذا العقار.</p>
                )}
              </section>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}

