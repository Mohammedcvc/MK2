
'use client';

import type { User, UserFormValues, UserPermissions } from '@/types';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm, SubmitHandler, Controller } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Eye, EyeOff } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

const availableRoles = [
  { id: 'admin', label: 'مسؤول' },
  { id: 'user', label: 'مستخدم عادي' },
];

const permissionsSchema = z.object({
  canDelete: z.boolean().default(true),
  canEdit: z.boolean().default(true),
  canAdd: z.boolean().default(true),
  canPrint: z.boolean().default(true),
}).default({ canDelete: true, canEdit: true, canAdd: true, canPrint: true });


const userFormSchema = z.object({
  username: z.string().min(3, { message: 'اسم المستخدم يجب أن لا يقل عن 3 أحرف.' }),
  password: z.string().optional(),
  roles: z.array(z.string()).min(1, { message: 'يجب اختيار دور واحد على الأقل.' }),
  permissions: permissionsSchema,
}).superRefine((data, ctx) => {
  if (data.password && data.password.length > 0 && data.password.length < 6) {
    ctx.addIssue({
      code: z.ZodIssueCode.too_small,
      minimum: 6,
      type: 'string',
      inclusive: true,
      message: 'كلمة المرور يجب أن لا تقل عن 6 أحرف إذا تم إدخالها.',
      path: ['password'],
    });
  }
});

interface AddEditUserModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: UserFormValues, userIdToUpdate?: string) => Promise<void>;
  initialData?: User | null;
}

export function AddEditUserModal({ isOpen, onClose, onSubmit, initialData }: AddEditUserModalProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const form = useForm<UserFormValues>({
    resolver: zodResolver(userFormSchema),
    defaultValues: initialData
      ? {
          username: initialData.username,
          password: '',
          roles: initialData.roles || ['user'],
          permissions: initialData.permissions || permissionsSchema.parse({})
        }
      : {
          username: '',
          password: '',
          roles: ['user'],
          permissions: permissionsSchema.parse({})
        },
  });

  useEffect(() => {
    if (isOpen) {
      form.reset(
        initialData
          ? {
              username: initialData.username,
              password: '',
              roles: initialData.roles || ['user'],
              permissions: initialData.permissions || permissionsSchema.parse({})
            }
          : {
              username: '',
              password: '',
              roles: ['user'],
              permissions: permissionsSchema.parse({})
            }
      );
      setShowPassword(false);
    }
  }, [isOpen, initialData, form]);


  const handleSubmitForm: SubmitHandler<UserFormValues> = async (data) => {
    setIsSubmitting(true);
    const dataToSend: UserFormValues = { ...data };

    if (initialData && (!data.password || data.password.trim() === '')) {
      delete dataToSend.password;
    }

    await onSubmit(dataToSend, initialData?.id);
    setIsSubmitting(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{initialData ? 'تعديل بيانات المستخدم' : 'إضافة مستخدم جديد'}</DialogTitle>
          <DialogDescription>
            {initialData ? 'قم بتحديث معلومات المستخدم.' : 'إضافة مستخدم جديد للنظام.'}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmitForm)} className="space-y-4 py-2 max-h-[70vh] overflow-y-auto px-1">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{'اسم المستخدم'}</FormLabel>
                  <FormControl>
                    <Input placeholder={'مثال: user123'} {...field} className={cn('bg-card', 'text-center')} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{initialData ? 'كلمة المرور (اتركها فارغة لعدم التغيير)' : 'كلمة المرور'}</FormLabel>
                  <div className="relative">
                    <FormControl>
                      <Input
                        type={showPassword ? "text" : "password"}
                        placeholder={'********'}
                        {...field}
                        className={cn("pe-10", "bg-card", "text-center")}
                      />
                    </FormControl>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 text-muted-foreground hover:text-foreground"
                      onClick={() => setShowPassword(!showPassword)}
                      aria-label={showPassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </Button>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="roles"
              render={() => (
                <FormItem>
                  <FormLabel>{'الأدوار'}</FormLabel>
                  {availableRoles.map((role) => (
                    <FormField
                      key={role.id}
                      control={form.control}
                      name="roles"
                      render={({ field }) => {
                        return (
                          <FormItem
                            key={role.id}
                            className="flex flex-row items-start space-x-3 space-x-reverse space-y-0 mt-2"
                          >
                            <FormControl>
                              <Checkbox
                                checked={field.value?.includes(role.id)}
                                onCheckedChange={(checked) => {
                                  return checked
                                    ? field.onChange([...(field.value || []), role.id])
                                    : field.onChange(
                                        (field.value || []).filter(
                                          (value) => value !== role.id
                                        )
                                      );
                                }}
                              />
                            </FormControl>
                            <FormLabel className="font-normal cursor-pointer">
                              {role.label}
                            </FormLabel>
                          </FormItem>
                        );
                      }}
                    />
                  ))}
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter className="pt-6">
              <Button type="button" variant="outline" onClick={onClose} disabled={isSubmitting}>
                {'إلغاء'}
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="me-2 h-4 w-4 animate-spin" />}
                {initialData ? 'حفظ التغييرات' : 'إضافة المستخدم'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
