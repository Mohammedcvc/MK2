
'use client';

import type { Owner, OwnerTransaction, Attachment } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption, TableFooter as ReportTableFooter } from '@/components/ui/table';
import { format, parseISO } from 'date-fns';
import { arSA } from 'date-fns/locale';
import { Printer, XIcon, FileText as FileTextIcon, Sigma, User, Briefcase, Clock } from 'lucide-react';

interface OwnerReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  owner: Owner;
  transactions: OwnerTransaction[];
  totalAmount: number; 
}

export function OwnerReportModal({ isOpen, onClose, owner, transactions, totalAmount }: OwnerReportModalProps) {
  if (!isOpen) return null;

  const totalCredit = transactions.filter(t => t.amount > 0).reduce((sum, t) => sum + t.amount, 0);
  const totalDebit = transactions.filter(t => t.amount < 0).reduce((sum, t) => sum + Math.abs(t.amount), 0);

  const formatTimestampForReport = (isoString?: string) => {
    if (!isoString) return '-';
    try {
      return format(parseISO(isoString), 'yyyy/MM/dd HH:mm', { locale: arSA });
    } catch (e) {
      return 'تاريخ خاطئ';
    }
  };

  const handlePrint = () => {
    const printContentsElement = document.getElementById('owner-report-content');
    const printContents = printContentsElement ? printContentsElement.innerHTML.replace(/`/g, '\\`').replace(/\$\{/g, '\\${') : '';
    const ownerNameSafe = owner.name.replace(/`/g, '\\`').replace(/\$\{/g, '\\${');
    
    if (printContents) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        const printHtml = `
          <html>
            <head>
              <title>تقرير المالك: ${ownerNameSafe}</title>
              <style>
                body { font-family: "Sakkal Majalla", var(--font-geist-sans), Arial, Helvetica, sans-serif; direction: rtl; margin: 20px; font-size: 12pt; }
                .print-header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                .print-header h1 { font-size: 14pt; color: #333; margin-bottom: 5px; font-weight: bold; }
                .print-header p { font-size: 12pt; color: #666; margin: 2px 0; font-weight: 500; }
                .section-title { font-size: 13pt; font-weight: bold; margin-top: 15px; margin-bottom: 8px; border-bottom: 1px solid #eee; padding-bottom: 4px;}
                table { width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 11pt; }
                th, td { border: 1px solid #ddd; padding: 6px; text-align: right; font-weight: 500;}
                th { background-color: #f2f2f2; font-weight: bold; }
                .total-row td { font-weight: bold; background-color: #f9f9f9; }
                .amount-positive { color: green !important; }
                .amount-negative { color: red !important; }
                .no-print { display: none; }
                .attachments-list { list-style-type: none; padding: 0; margin: 0; }
                .attachments-list li { font-size: 0.9em; }
                .footer-summary { margin-top: 20px; padding-top: 10px; border-top: 2px solid #ccc; text-align: left; }
                .footer-summary div { margin-bottom: 5px; font-size: 11pt;}
                .footer-summary strong { min-width: 150px; display: inline-block; }
              </style>
            </head>
            <body>
              <div class="print-header">
                <h1>تقرير حساب المالك</h1>
                <p>المالك: ${ownerNameSafe}</p>
                <p>تاريخ الطباعة: ${format(new Date(), 'yyyy/MM/dd HH:mm', { locale: arSA })}</p>
              </div>
              <div id="print-content-inner">
                ${printContents}
              </div>
            </body>
          </html>`;
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 500);
      }
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col bg-card">
        <DialogHeader className="border-b pb-4">
          <DialogTitle className="text-lg text-primary flex items-center"><User className="me-2"/> تقرير حساب المالك: {owner.name}</DialogTitle>
          <DialogDescription>عرض تفصيلي للحركات المالية للمالك.</DialogDescription>
        </DialogHeader>

        <ScrollArea className="flex-grow overflow-y-auto p-1 -mx-1">
          <div id="owner-report-content" className="p-4 space-y-6">
            <section>
              <h3 className="text-base font-semibold mb-3 text-foreground border-b pb-2 section-title">جدول الحركات المالية</h3>
              {transactions.length > 0 ? (
                <div className="overflow-x-auto rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="min-w-[100px]">التاريخ</TableHead>
                        <TableHead className="min-w-[180px]">البيان</TableHead>
                        <TableHead className="min-w-[110px]">لكم مبلغ (ريال)</TableHead>
                        <TableHead className="min-w-[110px]">عليكم مبلغ (ريال)</TableHead>
                        <TableHead className="min-w-[110px]">صافي الحركة (ريال)</TableHead>
                        <TableHead className="min-w-[150px]">المرفقات</TableHead>
                        <TableHead className="min-w-[130px]">آخر تعديل بواسطة</TableHead>
                        <TableHead className="min-w-[150px]">وقت آخر تعديل</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {transactions.map((transaction) => (
                        <TableRow key={transaction.id}>
                          <TableCell>{format(parseISO(transaction.date), 'yyyy/MM/dd', { locale: arSA })}</TableCell>
                          <TableCell className="font-medium">{transaction.description}</TableCell>
                          <TableCell className="amount-positive">
                            {transaction.amount > 0 ? transaction.amount.toLocaleString() : '-'}
                          </TableCell>
                          <TableCell className="amount-negative">
                             {transaction.amount < 0 ? Math.abs(transaction.amount).toLocaleString() : '-'}
                          </TableCell>
                          <TableCell className={transaction.amount >= 0 ? 'amount-positive' : 'amount-negative'}>
                            {transaction.amount.toLocaleString()}
                          </TableCell>
                          <TableCell>
                            {transaction.attachments && transaction.attachments.length > 0 ? (
                              <ul className="attachments-list">
                                {transaction.attachments.map(att => (
                                  <li key={att.name}>
                                    <FileTextIcon className="h-3 w-3 me-1 inline-block" />
                                    {att.name}
                                  </li>
                                ))}
                              </ul>
                            ) : (
                              <span className="text-xs text-muted-foreground">لا توجد مرفقات</span>
                            )}
                          </TableCell>
                           <TableCell className="text-xs text-muted-foreground">{transaction.lastModifiedBy || '-'}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{formatTimestampForReport(transaction.lastModifiedAt)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                    <ReportTableFooter className="total-row">
                       <TableRow>
                        <TableCell colSpan={2} className="font-bold">الإجمالي</TableCell>
                        <TableCell className="font-bold amount-positive">{totalCredit.toLocaleString()} ريال</TableCell>
                        <TableCell className="font-bold amount-negative">{totalDebit.toLocaleString()} ريال</TableCell>
                        <TableCell className={`font-bold ${totalAmount >= 0 ? 'amount-positive' : 'amount-negative'}`}>
                            {totalAmount.toLocaleString()} ريال
                        </TableCell>
                        <TableCell colSpan={3}></TableCell> {/* Adjusted colSpan */}
                      </TableRow>
                    </ReportTableFooter>
                     <TableCaption>إجمالي رصيد المالك {owner.name}: {totalAmount.toLocaleString()} ريال</TableCaption>
                  </Table>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">لا توجد حركات مالية مسجلة لهذا المالك.</p>
              )}
            </section>
            
            <section className="footer-summary">
                <div className="flex items-center justify-end text-xl font-bold">
                    <Sigma className="me-2 h-6 w-6 text-primary no-print" />
                    <span>الرصيد الإجمالي للمالك:</span>
                    <span className={`ms-2 ${totalAmount >=0 ? 'text-primary amount-positive' : 'text-destructive amount-negative'}`}>{totalAmount.toLocaleString()} ريال</span>
                </div>
            </section>
          </div>
        </ScrollArea>

        <DialogFooter className="pt-4 border-t no-print">
          <Button variant="outline" onClick={onClose}>
            <XIcon className="me-2 h-4 w-4" /> إغلاق
          </Button>
          <Button onClick={handlePrint} disabled={transactions.length === 0}>
            <Printer className="me-2 h-4 w-4" /> طباعة التقرير
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
