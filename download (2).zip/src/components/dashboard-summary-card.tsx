
'use client';

import type { LucideIcon } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface DashboardSummaryCardProps {
  title: string;
  value: number;
  icon: LucideIcon;
  description?: string;
  currency?: string;
  iconBgColor?: string;
  iconColor?: string;
  valueClassName?: string;
  textAlignment?: 'left' | 'right' | 'center';
}

export function DashboardSummaryCard({
  title,
  value,
  icon: Icon,
  description,
  currency: currencyProp,
  iconBgColor = 'bg-primary-100',
  iconColor = 'text-primary',
  valueClassName,
  textAlignment: textAlignmentProp,
}: DashboardSummaryCardProps) {
  const currency = currencyProp || 'ريال';
  const textAlignment = textAlignmentProp || 'right'; // Default to RTL

  const alignmentClass = textAlignment === 'left' ? 'text-left' : textAlignment === 'center' ? 'text-center' : 'text-right';
  
  return (
    <Card className="shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className={cn("flex flex-row items-center justify-between space-y-0 pb-2", alignmentClass)}>
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <div className={cn("p-2 rounded-full", iconBgColor, 'mr-auto' )}> {/* Default to LTR icon placement */}
          <Icon className={cn("h-5 w-5", iconColor)} />
        </div>
      </CardHeader>
      <CardContent className={alignmentClass}>
        <div className={cn("text-2xl font-bold", valueClassName)}>
          {value.toLocaleString('ar-SA')} {currency}
        </div>
        {description && (
          <p className="text-xs text-muted-foreground pt-1">{description}</p>
        )}
      </CardContent>
    </Card>
  );
}
